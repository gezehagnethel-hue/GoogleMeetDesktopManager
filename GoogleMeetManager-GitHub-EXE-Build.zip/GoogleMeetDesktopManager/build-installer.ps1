# Google Meet Desktop Manager - Windows Installer Packaging Script (PowerShell)
# Requires JDK 17+ and WiX Toolset 3.11+ (for EXE/MSI generation)

Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host " Google Meet Desktop Manager - Windows 10 & 11 Installer Packager" -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Prerequisite verification
$javac = Get-Command javac -ErrorAction SilentlyContinue
if (-not $javac) {
    Write-Error "JDK compiler (javac) not found in PATH. Install JDK 17+ from https://adoptium.net/"
    exit 1
}

$jpackage = Get-Command jpackage -ErrorAction SilentlyContinue
if (-not $jpackage) {
    Write-Error "jpackage utility not found. Ensure JAVA_HOME points to JDK 17+ and %JAVA_HOME%\bin is in PATH."
    exit 1
}

# 2. Build Maven JAR
Write-Host "[1/3] Building shaded executable JAR with Maven..." -ForegroundColor Yellow
mvn clean package -DskipTests=false
if ($LASTEXITCODE -ne 0) {
    Write-Error "Maven build or unit tests failed!"
    exit $LASTEXITCODE
}

# 3. Setup Dist Directory
Write-Host "[2/3] Preparing dist folder..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path "dist" | Out-Null
New-Item -ItemType Directory -Force -Path "installer-output" | Out-Null
Copy-Item "target/google-meet-desktop-manager-1.0.0.jar" -Destination "dist/google-meet-desktop-manager.jar" -Force

# 4. Packaging with jpackage
Write-Host "[3/3] Packaging Windows EXE installer with bundled runtime..." -ForegroundColor Yellow

$jpackageArgs = @(
    "--input", "dist",
    "--name", "GoogleMeetDesktopManager",
    "--main-jar", "google-meet-desktop-manager.jar",
    "--main-class", "com.example.meetmanager.Main",
    "--type", "exe",
    "--app-version", "1.0.0",
    "--vendor", "Independent Launcher",
    "--description", "Google Meet Desktop Manager - Permanent Meeting Link Launcher",
    "--win-menu",
    "--win-menu-group", "Google Meet Desktop Manager",
    "--win-shortcut",
    "--win-dir-chooser",
    "--dest", "installer-output"
)

& jpackage $jpackageArgs

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "=========================================================================" -ForegroundColor Green
    Write-Host "[SUCCESS] Windows Installer created successfully in: installer-output/" -ForegroundColor Green
    Write-Host "=========================================================================" -ForegroundColor Green
} else {
    Write-Warning "EXE generation with WiX failed or WiX is not installed. Building standalone portable app-image directory instead..."
    $appImageArgs = @(
        "--input", "dist",
        "--name", "GoogleMeetDesktopManager",
        "--main-jar", "google-meet-desktop-manager.jar",
        "--main-class", "com.example.meetmanager.Main",
        "--type", "app-image",
        "--app-version", "1.0.0",
        "--vendor", "Independent Launcher",
        "--dest", "installer-output"
    )
    & jpackage $appImageArgs
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[SUCCESS] Standalone Windows application folder created at: installer-output/GoogleMeetDesktopManager/" -ForegroundColor Green
    }
}
