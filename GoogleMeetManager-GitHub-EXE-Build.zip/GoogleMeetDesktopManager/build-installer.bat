@echo off
setlocal enabledelayedexpansion
title Google Meet Desktop Manager - Windows Installer Builder

echo =========================================================================
echo   Google Meet Desktop Manager - Native Windows Installer Packaging
echo   Target: Windows 10 & 11 (64-bit)
echo =========================================================================
echo.

:: 1. Verify Java 17+
where javac >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] 'javac' compiler was not found in PATH.
    echo Please install JDK 17 or higher (e.g. Eclipse Temurin from https://adoptium.net/)
    pause
    exit /b 1
)

:: 2. Verify jpackage
where jpackage >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] 'jpackage' tool was not found in PATH.
    echo Make sure JAVA_HOME points to a full JDK 17+ and %%JAVA_HOME%%\bin is in PATH.
    pause
    exit /b 1
)

:: 3. Verify WiX Toolset for EXE / MSI installers
where candle.exe >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [NOTICE] WiX Toolset 3.11+ is required by jpackage for building .exe / .msi on Windows.
    echo If building fails, download WiX 3.11 from https://wixtoolset.org/releases/
    echo and add its bin folder to PATH.
    echo.
)

:: 4. Build Shaded Fat JAR with Maven
echo [STEP 1/3] Compiling and packaging shaded JAR with Maven...
call mvn clean package -DskipTests=false
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Maven build or unit tests failed!
    pause
    exit /b %ERRORLEVEL%
)

:: 5. Prepare output directories and copy JAR
echo.
echo [STEP 2/3] Preparing installer target directories...
if not exist "dist" mkdir "dist"
if not exist "installer-output" mkdir "installer-output"

if exist "target\google-meet-desktop-manager.jar" (
    copy /y "target\google-meet-desktop-manager.jar" "dist\google-meet-desktop-manager.jar" >nul
) else if exist "target\google-meet-desktop-manager-1.0.0.jar" (
    copy /y "target\google-meet-desktop-manager-1.0.0.jar" "dist\google-meet-desktop-manager.jar" >nul
) else (
    echo [ERROR] Could not find compiled target JAR in target\ directory!
    pause
    exit /b 1
)

:: 6. Run jpackage to create native Windows installer with bundled JRE
echo.
echo [STEP 3/3] Running jpackage to package Windows Application Installer...
echo This bundles a self-contained Java runtime so client PCs do not require Java installed.
echo.

jpackage ^
  --input dist ^
  --name "GoogleMeetDesktopManager" ^
  --main-jar "google-meet-desktop-manager.jar" ^
  --main-class com.example.meetmanager.Main ^
  --type exe ^
  --app-version "1.0.0" ^
  --vendor "Independent Launcher" ^
  --description "Google Meet Desktop Manager - Permanent Meeting Link Launcher" ^
  --win-menu ^
  --win-menu-group "Google Meet Desktop Manager" ^
  --win-shortcut ^
  --win-dir-chooser ^
  --dest installer-output

if %ERRORLEVEL% equ 0 (
    echo.
    echo =========================================================================
    echo [SUCCESS] Windows Installer (.exe) successfully generated!
    echo Location: %cd%\installer-output\GoogleMeetDesktopManager-1.0.0.exe
    echo =========================================================================
) else (
    echo.
    echo [WARNING] jpackage with '--type exe' encountered an issue (commonly missing WiX toolset).
    echo Generating portable standalone Windows application package (--type app-image)...
    
    jpackage ^
      --input dist ^
      --name "GoogleMeetDesktopManager" ^
      --main-jar "google-meet-desktop-manager.jar" ^
      --main-class com.example.meetmanager.Main ^
      --type app-image ^
      --app-version "1.0.0" ^
      --vendor "Independent Launcher" ^
      --dest installer-output
      
    if %ERRORLEVEL% equ 0 (
        echo.
        echo [SUCCESS] Portable Windows application image created at:
        echo %cd%\installer-output\GoogleMeetDesktopManager\GoogleMeetDesktopManager.exe
    ) else (
        echo [ERROR] Packaging failed. Check console error messages above.
    )
)

pause
