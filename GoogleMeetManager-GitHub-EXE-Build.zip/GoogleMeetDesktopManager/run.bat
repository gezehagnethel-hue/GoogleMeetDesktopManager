@echo off
setlocal enabledelayedexpansion
title Google Meet Desktop Manager - Development Runner

echo =======================================================
echo  Google Meet Desktop Manager (Windows 10 / 11)
echo =======================================================
echo.

:: 1. Check Java 17+
where java >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Java was not found in PATH!
    echo Please install JDK 17 or higher from https://adoptium.net/
    pause
    exit /b 1
)

:: 2. Check Maven
where mvn >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo Compiling and starting via Maven Exec Plugin...
    mvn compile exec:java
    if %ERRORLEVEL% equ 0 exit /b 0
)

:: 3. Fallback: Launch pre-packaged fat JAR if present
if exist "target\google-meet-desktop-manager.jar" (
    echo Launching packaged fat JAR...
    java -jar "target\google-meet-desktop-manager.jar"
    exit /b %ERRORLEVEL%
)

if exist "target\google-meet-desktop-manager-1.0.0.jar" (
    echo Launching packaged fat JAR...
    java -jar "target\google-meet-desktop-manager-1.0.0.jar"
    exit /b %ERRORLEVEL%
)

echo.
echo [ERROR] Could not start application.
echo Please ensure Maven or a compiled target JAR is available.
echo Run 'mvn clean package' to build the runnable JAR.
pause
