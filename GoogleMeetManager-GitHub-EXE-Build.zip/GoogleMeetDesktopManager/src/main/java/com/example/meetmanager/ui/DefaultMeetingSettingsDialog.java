package com.example.meetmanager.ui;

import com.example.meetmanager.model.DefaultMeetingConfig;
import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.UrlValidationService;
import com.example.meetmanager.util.BrowserUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

/**
 * Dedicated modal dialog for configuring and updating the 1-Click Instant "JOIN MEETING NOW" URL.
 */
public class DefaultMeetingSettingsDialog extends JDialog {

    private final MeetingService meetingService;
    private final JTextField titleField;
    private final JTextField urlField;
    private final JLabel validationStatusLabel;
    private final JComboBox<MeetingItem> quickSelectCombo;

    private static class MeetingItem {
        final Meeting meeting;

        MeetingItem(Meeting meeting) {
            this.meeting = meeting;
        }

        @Override
        public String toString() {
            if (meeting == null) {
                return "-- Or choose from saved meetings --";
            }
            return meeting.getName() + " (" + meeting.getUrl() + ")";
        }
    }

    public DefaultMeetingSettingsDialog(Frame parent, MeetingService meetingService) {
        super(parent, "Meeting Settings • Default One-Click Meeting", true);
        this.meetingService = meetingService;

        setSize(560, 420);
        setLocationRelativeTo(parent);
        setResizable(false);

        DefaultMeetingConfig current = meetingService.getDefaultMeeting();

        JPanel root = new JPanel(new BorderLayout(0, 16));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Configure Default One-Click Meeting");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(32, 33, 36));

        JLabel descLabel = new JLabel("Set the permanent Google Meet link for the prominent 'JOIN MEETING NOW' button.");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(new Color(95, 99, 104));
        descLabel.setBorder(new EmptyBorder(4, 0, 8, 0));

        headerPanel.add(titleLabel);
        headerPanel.add(descLabel);
        root.add(headerPanel, BorderLayout.NORTH);

        // Form fields
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setOpaque(false);

        // Quick Select from existing
        List<Meeting> savedList = meetingService.getAllMeetings();
        quickSelectCombo = new JComboBox<>();
        quickSelectCombo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        quickSelectCombo.addItem(new MeetingItem(null));
        for (Meeting m : savedList) {
            quickSelectCombo.addItem(new MeetingItem(m));
        }
        quickSelectCombo.addActionListener(e -> {
            MeetingItem selected = (MeetingItem) quickSelectCombo.getSelectedItem();
            if (selected != null && selected.meeting != null) {
                titleField.setText(selected.meeting.getName());
                urlField.setText(selected.meeting.getUrl());
                validateUrlLive();
            }
        });

        if (!savedList.isEmpty()) {
            JPanel quickSelectRow = new JPanel(new BorderLayout(8, 0));
            quickSelectRow.setOpaque(false);
            JLabel qsLabel = new JLabel("Quick Select:");
            qsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            qsLabel.setForeground(new Color(95, 99, 104));
            quickSelectRow.add(qsLabel, BorderLayout.WEST);
            quickSelectRow.add(quickSelectCombo, BorderLayout.CENTER);
            quickSelectRow.setBorder(new EmptyBorder(0, 0, 12, 0));
            formPanel.add(quickSelectRow);
        }

        // Title Field
        JLabel nameLabel = new JLabel("Meeting Title / Room Label:");
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        nameLabel.setForeground(new Color(60, 64, 67));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        titleField = new JTextField(current.getTitle());
        titleField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        titleField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        titleField.setAlignmentX(Component.LEFT_ALIGNMENT);

        formPanel.add(nameLabel);
        formPanel.add(Box.createVerticalStrut(4));
        formPanel.add(titleField);
        formPanel.add(Box.createVerticalStrut(12));

        // URL Field
        JLabel urlLabel = new JLabel("Google Meet URL (HTTPS):");
        urlLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        urlLabel.setForeground(new Color(60, 64, 67));
        urlLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        urlField = new JTextField(current.getUrl());
        urlField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        urlField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        urlField.setAlignmentX(Component.LEFT_ALIGNMENT);
        urlField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                validateUrlLive();
            }
        });

        formPanel.add(urlLabel);
        formPanel.add(Box.createVerticalStrut(4));
        formPanel.add(urlField);
        formPanel.add(Box.createVerticalStrut(6));

        // Validation status
        validationStatusLabel = new JLabel(" ");
        validationStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        validationStatusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(validationStatusLabel);

        root.add(formPanel, BorderLayout.CENTER);

        // Action Buttons Row
        JPanel actionsRow = new JPanel(new BorderLayout());
        actionsRow.setOpaque(false);
        actionsRow.setBorder(new EmptyBorder(12, 0, 0, 0));

        JButton testBtn = new JButton("Test Launch in Browser");
        testBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        testBtn.addActionListener(e -> testLaunch());
        actionsRow.add(testBtn, BorderLayout.WEST);

        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightButtons.setOpaque(false);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cancelBtn.addActionListener(e -> dispose());

        JButton saveBtn = new JButton("Save Default Meeting");
        saveBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        saveBtn.setBackground(new Color(26, 115, 232));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFocusPainted(false);
        saveBtn.addActionListener(e -> saveDefaultMeeting());

        rightButtons.add(cancelBtn);
        rightButtons.add(saveBtn);
        actionsRow.add(rightButtons, BorderLayout.EAST);

        root.add(actionsRow, BorderLayout.SOUTH);

        setContentPane(root);
        validateUrlLive();
    }

    private void validateUrlLive() {
        String input = urlField.getText().trim();
        if (input.isEmpty()) {
            validationStatusLabel.setText("No meeting link configured. Enter https://meet.google.com/xxx-yyyy-zzz");
            validationStatusLabel.setForeground(new Color(128, 134, 139));
            return;
        }

        UrlValidationService.ValidationResult res = meetingService.getUrlValidationService().validate(input);
        if (res.isValid()) {
            validationStatusLabel.setText("✓ Valid Google Meet link (" + res.getNormalizedUrl() + ")");
            validationStatusLabel.setForeground(new Color(24, 134, 75));
        } else {
            validationStatusLabel.setText("✕ " + res.getMessage());
            validationStatusLabel.setForeground(new Color(217, 48, 37));
        }
    }

    private void testLaunch() {
        String input = urlField.getText().trim();
        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a Google Meet link first.",
                    "No Link Entered",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        UrlValidationService.ValidationResult res = meetingService.getUrlValidationService().validate(input);
        if (!res.isValid()) {
            JOptionPane.showMessageDialog(this,
                    "Invalid Google Meet link:\n" + res.getMessage(),
                    "Invalid URL",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            BrowserUtil.openUrl(res.getNormalizedUrl());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not launch browser: " + ex.getMessage(),
                    "Launch Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDefaultMeeting() {
        String title = titleField.getText().trim();
        String urlInput = urlField.getText().trim();

        if (urlInput.isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to clear the default Google Meet URL?\n" +
                    "The 'JOIN MEETING NOW' button will prompt to configure a link.",
                    "Clear Default Link?",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                meetingService.saveDefaultMeeting(title.isEmpty() ? "Primary Google Meet" : title, "");
                dispose();
            }
            return;
        }

        UrlValidationService.ValidationResult res = meetingService.getUrlValidationService().validate(urlInput);
        if (!res.isValid()) {
            JOptionPane.showMessageDialog(this,
                    "Cannot save invalid Google Meet URL:\n" + res.getMessage(),
                    "Invalid URL",
                    JOptionPane.ERROR_MESSAGE);
            urlField.requestFocusInWindow();
            return;
        }

        meetingService.saveDefaultMeeting(title.isEmpty() ? "Primary Google Meet" : title, res.getNormalizedUrl());
        dispose();
    }
}
