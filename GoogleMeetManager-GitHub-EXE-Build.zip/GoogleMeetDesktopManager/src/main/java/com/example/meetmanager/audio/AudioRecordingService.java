package com.example.meetmanager.audio;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Service orchestrating consent-based Windows audio recording with dual-stream loopback mixing.
 */
public class AudioRecordingService {

    public interface RecordingListener {
        void onStateChanged(AudioRecordingState state, String message);
        void onTimeUpdate(long elapsedMs, String formattedTime);
        void onPeakLevels(float micLevel, float sysLevel);
        void onError(String errorMessage);
    }

    private static final int SAMPLE_RATE = 44100;
    private static final int BITS_PER_SAMPLE = 16;
    private static final int CHANNELS = 1; // 1 channel PCM for reliable cross-stream mixing
    private static final long MIN_DISK_SPACE_BYTES = 100 * 1024 * 1024; // 100 MB

    private final AudioDeviceManager deviceManager;
    private final File recordingsDirectory;
    private final List<RecordingListener> listeners = new CopyOnWriteArrayList<>();

    private volatile AudioRecordingState currentState = AudioRecordingState.IDLE;
    private final AtomicBoolean isRecordingActive = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);

    private WavFileWriter wavWriter;
    private TargetDataLine micLine;
    private TargetDataLine sysLine;
    private Thread captureThread;

    private RecordingSession activeSession;
    private long sessionStartTime;
    private long totalElapsedMs = 0;
    private long pauseStartTime = 0;

    public AudioRecordingService() {
        this(resolveDefaultRecordingsDirectory());
    }

    public AudioRecordingService(File recordingsDirectory) {
        this.deviceManager = new AudioDeviceManager();
        this.recordingsDirectory = recordingsDirectory;
        if (!this.recordingsDirectory.exists()) {
            this.recordingsDirectory.mkdirs();
        }
    }

    private static File resolveDefaultRecordingsDirectory() {
        String userProfile = System.getProperty("user.home");
        File docs = new File(userProfile, "Documents");
        if (docs.exists() && docs.canWrite()) {
            return new File(docs, "GoogleMeetRecordings");
        }
        String appData = System.getenv("APPDATA");
        if (appData != null && !appData.isEmpty()) {
            return new File(appData, "GoogleMeetDesktopManager/recordings");
        }
        return new File(userProfile, "GoogleMeetRecordings");
    }

    public File getRecordingsDirectory() {
        return recordingsDirectory;
    }

    public AudioDeviceManager getDeviceManager() {
        return deviceManager;
    }

    public AudioRecordingState getCurrentState() {
        return currentState;
    }

    public RecordingSession getActiveSession() {
        return activeSession;
    }

    public void addListener(RecordingListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeListener(RecordingListener listener) {
        listeners.remove(listener);
    }

    /**
     * Initiates a consent-verified audio recording session.
     */
    public synchronized void startRecording(String meetingTitle, boolean consentConfirmed) throws IOException, LineUnavailableException {
        if (!consentConfirmed) {
            throw new IllegalStateException("Recording cannot proceed without explicit participant consent confirmation.");
        }
        if (currentState == AudioRecordingState.RECORDING || currentState == AudioRecordingState.PAUSED) {
            throw new IllegalStateException("A recording session is already active.");
        }

        // Verify available disk space
        long freeSpace = recordingsDirectory.getFreeSpace();
        if (freeSpace > 0 && freeSpace < MIN_DISK_SPACE_BYTES) {
            throw new IOException("Insufficient disk space. At least 100 MB free space is required to record safely.");
        }

        // Determine recording mode (dual-stream mixed or mic-only)
        boolean hasLoopback = deviceManager.isSystemLoopbackAvailable();
        RecordingMode mode = hasLoopback ? RecordingMode.DUAL_STREAM_MIXED : RecordingMode.MIC_ONLY;

        // Generate timestamped filename
        String safeTitle = sanitizeFilename(meetingTitle);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String filename = String.format("GoogleMeet_%s_%s.wav", safeTitle, timestamp);
        File outputFile = new File(recordingsDirectory, filename);

        // Prevent accidental overwriting
        int counter = 1;
        while (outputFile.exists()) {
            filename = String.format("GoogleMeet_%s_%s_%d.wav", safeTitle, timestamp, counter++);
            outputFile = new File(recordingsDirectory, filename);
        }

        // Create WAV Writer
        wavWriter = new WavFileWriter(outputFile, SAMPLE_RATE, CHANNELS, BITS_PER_SAMPLE);

        // Open Microphone Line
        AudioFormat format = new AudioFormat(SAMPLE_RATE, BITS_PER_SAMPLE, CHANNELS, true, false);
        DataLine.Info micLineInfo = new DataLine.Info(TargetDataLine.class, format);

        Mixer.Info micMixer = deviceManager.getMicrophoneMixerInfo();
        if (micMixer != null) {
            micLine = (TargetDataLine) AudioSystem.getMixer(micMixer).getLine(micLineInfo);
        } else {
            micLine = (TargetDataLine) AudioSystem.getLine(micLineInfo);
        }
        micLine.open(format);
        micLine.start();

        // Open Loopback Line if available
        if (hasLoopback) {
            try {
                Mixer.Info loopMixer = deviceManager.getLoopbackMixerInfo();
                if (loopMixer != null) {
                    sysLine = (TargetDataLine) AudioSystem.getMixer(loopMixer).getLine(micLineInfo);
                    sysLine.open(format);
                    sysLine.start();
                }
            } catch (Exception e) {
                // Graceful fallback to mic-only if loopback initialization fails
                sysLine = null;
                mode = RecordingMode.MIC_ONLY;
            }
        }

        // Initialize session metadata
        sessionStartTime = System.currentTimeMillis();
        totalElapsedMs = 0;
        isRecordingActive.set(true);
        isPaused.set(false);

        activeSession = new RecordingSession(
                UUID.randomUUID().toString(),
                (meetingTitle != null && !meetingTitle.isBlank()) ? meetingTitle : "Google Meet Session",
                filename,
                outputFile.getAbsolutePath(),
                sessionStartTime,
                0L,
                0L,
                mode,
                consentConfirmed
        );

        setState(AudioRecordingState.RECORDING, "Recording started: " + mode.getLabel());

        // Spawn capture and mixing thread
        final RecordingMode finalMode = mode;
        captureThread = new Thread(() -> runAudioCaptureLoop(finalMode), "GoogleMeet-AudioCapture");
        captureThread.setDaemon(true);
        captureThread.start();
    }

    /**
     * Pauses the active recording session.
     */
    public synchronized void pauseRecording() {
        if (currentState != AudioRecordingState.RECORDING) return;
        isPaused.set(true);
        pauseStartTime = System.currentTimeMillis();
        setState(AudioRecordingState.PAUSED, "Recording paused");
    }

    /**
     * Resumes the paused recording session.
     */
    public synchronized void resumeRecording() {
        if (currentState != AudioRecordingState.PAUSED) return;
        if (pauseStartTime > 0) {
            pauseStartTime = 0;
        }
        isPaused.set(false);
        setState(AudioRecordingState.RECORDING, "Recording resumed");
    }

    /**
     * Finalizes and closes the active recording session.
     */
    public synchronized RecordingSession stopRecording() {
        if (!isRecordingActive.get()) {
            return activeSession;
        }

        setState(AudioRecordingState.FINALIZING, "Finalizing audio recording...");
        isRecordingActive.set(false);
        isPaused.set(false);

        if (captureThread != null) {
            try {
                captureThread.join(1500);
            } catch (InterruptedException ignored) {
            }
        }

        closeLines();

        if (wavWriter != null) {
            try {
                wavWriter.close();
            } catch (IOException e) {
                notifyError("Error finalizing WAV file: " + e.getMessage());
            }
        }

        if (activeSession != null) {
            File savedFile = new File(activeSession.getFilePath());
            activeSession.setDurationMs(totalElapsedMs);
            activeSession.setFileSizeBytes(savedFile.exists() ? savedFile.length() : 0L);
        }

        RecordingSession finished = activeSession;
        setState(AudioRecordingState.STOPPED, "Recording saved: " + (finished != null ? finished.getFilename() : ""));
        currentState = AudioRecordingState.IDLE;
        return finished;
    }

    private void runAudioCaptureLoop(RecordingMode mode) {
        AudioMixer mixer = new AudioMixer(0.9f, 0.9f);
        byte[] micBuffer = new byte[2048];
        byte[] sysBuffer = new byte[2048];
        long lastTimerTick = System.currentTimeMillis();

        while (isRecordingActive.get()) {
            long now = System.currentTimeMillis();

            if (!isPaused.get()) {
                totalElapsedMs += (now - lastTimerTick);
            }
            lastTimerTick = now;

            notifyTimeUpdate(totalElapsedMs);

            int micRead = 0;
            if (micLine != null && micLine.isOpen()) {
                int avail = micLine.available();
                if (avail > 0) {
                    micRead = micLine.read(micBuffer, 0, Math.min(avail, micBuffer.length));
                }
            }

            int sysRead = 0;
            if (sysLine != null && sysLine.isOpen()) {
                int avail = sysLine.available();
                if (avail > 0) {
                    sysRead = sysLine.read(sysBuffer, 0, Math.min(avail, sysBuffer.length));
                }
            }

            float micLevel = AudioMixer.calculatePeakLevel(micBuffer, micRead);
            float sysLevel = AudioMixer.calculatePeakLevel(sysBuffer, sysRead);
            notifyPeakLevels(micLevel, sysLevel);

            if (!isPaused.get() && (micRead > 0 || sysRead > 0)) {
                try {
                    if (mode == RecordingMode.DUAL_STREAM_MIXED && sysLine != null) {
                        byte[] mixed = mixer.mixPcmBuffers(micBuffer, micRead, sysBuffer, sysRead);
                        wavWriter.writeSamples(mixed, 0, mixed.length);
                    } else if (micRead > 0) {
                        wavWriter.writeSamples(micBuffer, 0, micRead);
                    }
                } catch (IOException e) {
                    notifyError("Disk write error: " + e.getMessage());
                    break;
                }
            }

            try {
                Thread.sleep(25);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    private void closeLines() {
        if (micLine != null) {
            try {
                micLine.stop();
                micLine.close();
            } catch (Exception ignored) {
            }
            micLine = null;
        }
        if (sysLine != null) {
            try {
                sysLine.stop();
                sysLine.close();
            } catch (Exception ignored) {
            }
            sysLine = null;
        }
    }

    private void setState(AudioRecordingState state, String message) {
        this.currentState = state;
        for (RecordingListener l : listeners) {
            try {
                l.onStateChanged(state, message);
            } catch (Exception ignored) {
            }
        }
    }

    private void notifyTimeUpdate(long elapsedMs) {
        long totalSeconds = elapsedMs / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        long hours = minutes / 60;
        minutes = minutes % 60;
        String formatted = (hours > 0)
                ? String.format("%02d:%02d:%02d", hours, minutes, seconds)
                : String.format("%02d:%02d", minutes, seconds);

        for (RecordingListener l : listeners) {
            try {
                l.onTimeUpdate(elapsedMs, formatted);
            } catch (Exception ignored) {
            }
        }
    }

    private void notifyPeakLevels(float micLevel, float sysLevel) {
        for (RecordingListener l : listeners) {
            try {
                l.onPeakLevels(micLevel, sysLevel);
            } catch (Exception ignored) {
            }
        }
    }

    private void notifyError(String error) {
        for (RecordingListener l : listeners) {
            try {
                l.onError(error);
            } catch (Exception ignored) {
            }
        }
    }

    private String sanitizeFilename(String input) {
        if (input == null || input.isBlank()) return "Meeting";
        return input.replaceAll("[^a-zA-Z0-9_-]", "_").replaceAll("_+", "_");
    }
}
