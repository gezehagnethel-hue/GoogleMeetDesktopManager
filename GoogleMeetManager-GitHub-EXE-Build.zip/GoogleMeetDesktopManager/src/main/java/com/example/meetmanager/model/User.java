package com.example.meetmanager.model;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

/**
 * Represents an authenticated user (Administrator or Client) in Google Meet Manager.
 */
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String email;
    private String displayName;
    private UserRole role;
    private String passwordHash;
    private String salt;
    private long createdAt;
    private long lastLoginAt;

    public User() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = System.currentTimeMillis();
        this.role = UserRole.CLIENT;
    }

    public User(String email, String displayName, UserRole role, String passwordHash, String salt) {
        this(UUID.randomUUID().toString(), email, displayName, role, passwordHash, salt, System.currentTimeMillis(), 0L);
    }

    public User(String id, String email, String displayName, UserRole role, String passwordHash, String salt, long createdAt, long lastLoginAt) {
        this.id = id != null ? id : UUID.randomUUID().toString();
        this.email = email != null ? email.trim().toLowerCase() : "";
        this.displayName = displayName != null ? displayName.trim() : "";
        this.role = role != null ? role : UserRole.CLIENT;
        this.passwordHash = passwordHash != null ? passwordHash : "";
        this.salt = salt != null ? salt : "";
        this.createdAt = createdAt > 0 ? createdAt : System.currentTimeMillis();
        this.lastLoginAt = lastLoginAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email != null ? email.trim().toLowerCase() : "";
    }

    public String getDisplayName() {
        return displayName != null && !displayName.isEmpty() ? displayName : email;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role != null ? role : UserRole.CLIENT;
    }

    public boolean isAdmin() {
        return role == UserRole.ADMIN;
    }

    public boolean isClient() {
        return role == UserRole.CLIENT;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(long lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return displayName + " (" + email + ") [" + role.name() + "]";
    }
}
