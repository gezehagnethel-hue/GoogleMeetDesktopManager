package com.example.meetmanager.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Configuration model for the 1-Click Instant "JOIN MEETING NOW" launcher.
 * Persisted in local SQLite database between application restarts.
 */
public class DefaultMeetingConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private String title;
    private String url;
    private long lastJoinedAt;
    private int joinCount;

    public DefaultMeetingConfig() {
        this("Primary Google Meet", "", 0L, 0);
    }

    public DefaultMeetingConfig(String title, String url) {
        this(title, url, 0L, 0);
    }

    public DefaultMeetingConfig(String title, String url, long lastJoinedAt, int joinCount) {
        this.title = (title != null && !title.trim().isEmpty()) ? title.trim() : "Primary Google Meet";
        this.url = (url != null) ? url.trim() : "";
        this.lastJoinedAt = lastJoinedAt;
        this.joinCount = joinCount;
    }

    public boolean isConfigured() {
        return url != null && !url.trim().isEmpty();
    }

    public String getFormattedCode() {
        if (url == null || url.trim().isEmpty()) {
            return "";
        }
        try {
            java.net.URI uri = java.net.URI.create(url.trim());
            String path = uri.getPath();
            if (path != null) {
                if (path.startsWith("/")) {
                    path = path.substring(1);
                }
                int queryIdx = path.indexOf('?');
                if (queryIdx >= 0) {
                    path = path.substring(0, queryIdx);
                }
                return path;
            }
        } catch (Exception ignored) {
        }
        return url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = (title != null && !title.trim().isEmpty()) ? title.trim() : "Primary Google Meet";
    }

    public String getUrl() {
        return url != null ? url.trim() : "";
    }

    public void setUrl(String url) {
        this.url = url != null ? url.trim() : "";
    }

    public long getLastJoinedAt() {
        return lastJoinedAt;
    }

    public void setLastJoinedAt(long lastJoinedAt) {
        this.lastJoinedAt = lastJoinedAt;
    }

    public int getJoinCount() {
        return joinCount;
    }

    public void setJoinCount(int joinCount) {
        this.joinCount = joinCount;
    }

    public void incrementJoinCount() {
        this.joinCount++;
        this.lastJoinedAt = System.currentTimeMillis();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DefaultMeetingConfig that = (DefaultMeetingConfig) o;
        return Objects.equals(title, that.title) && Objects.equals(url, that.url);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, url);
    }

    @Override
    public String toString() {
        return "DefaultMeetingConfig{" +
                "title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", joinCount=" + joinCount +
                '}';
    }
}
