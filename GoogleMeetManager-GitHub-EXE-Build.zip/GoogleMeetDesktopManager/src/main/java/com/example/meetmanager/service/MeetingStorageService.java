package com.example.meetmanager.service;

import com.example.meetmanager.audio.RecordingMode;
import com.example.meetmanager.audio.RecordingSession;
import com.example.meetmanager.model.DefaultMeetingConfig;
import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.model.User;
import com.example.meetmanager.model.UserRole;
import com.example.meetmanager.util.PasswordSecurityUtil;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Handles persistent transactional local storage of meeting records using SQLite via JDBC,
 * as well as shared cross-platform JSON backup/restore with schema versioning.
 */
public class MeetingStorageService {

    private static final Logger LOGGER = Logger.getLogger(MeetingStorageService.class.getName());
    public static final String APP_DIR_NAME = "GoogleMeetDesktopManager";
    public static final String DB_FILE_NAME = "meetings.db";
    public static final String JSON_FILE_NAME = "meetings.json";
    public static final int CURRENT_SCHEMA_VERSION = 2;

    private final Path storageDirectory;
    private final Path dbFilePath;
    private final Path legacyJsonFilePath;
    private final Gson gson;
    private final UrlValidationService urlValidationService;
    private final String jdbcUrl;

    public static class BackupEnvelope {
        public int schemaVersion;
        public long exportTimestamp;
        public String appName;
        public List<Meeting> records;

        public BackupEnvelope() {
            this.schemaVersion = CURRENT_SCHEMA_VERSION;
            this.exportTimestamp = System.currentTimeMillis();
            this.appName = "Google Meet Desktop & Mobile Manager";
            this.records = new ArrayList<>();
        }

        public BackupEnvelope(List<Meeting> records) {
            this.schemaVersion = CURRENT_SCHEMA_VERSION;
            this.exportTimestamp = System.currentTimeMillis();
            this.appName = "Google Meet Desktop & Mobile Manager";
            this.records = records != null ? new ArrayList<>(records) : new ArrayList<>();
        }
    }

    public MeetingStorageService() {
        this(determineDefaultStorageDirectory());
    }

    public MeetingStorageService(Path storageDirectory) {
        this.storageDirectory = storageDirectory;
        this.dbFilePath = storageDirectory.resolve(DB_FILE_NAME);
        this.legacyJsonFilePath = storageDirectory.resolve(JSON_FILE_NAME);
        this.jdbcUrl = "jdbc:sqlite:" + dbFilePath.toAbsolutePath().toString();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.urlValidationService = new UrlValidationService();

        initializeStorage();
    }

    public static Path determineDefaultStorageDirectory() {
        String appData = System.getenv("APPDATA");
        if (appData != null && !appData.trim().isEmpty()) {
            return Paths.get(appData, APP_DIR_NAME);
        }
        String userHome = System.getProperty("user.home");
        if (userHome != null) {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) {
                return Paths.get(userHome, "AppData", "Roaming", APP_DIR_NAME);
            }
            return Paths.get(userHome, "." + APP_DIR_NAME.toLowerCase());
        }
        return Paths.get(".", APP_DIR_NAME);
    }

    private void initializeStorage() {
        try {
            if (!Files.exists(storageDirectory)) {
                Files.createDirectories(storageDirectory);
            }
            initSqliteDatabase();
            migrateLegacyJsonIfNeeded();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize storage", e);
        }
    }

    private void initSqliteDatabase() throws SQLException {
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             Statement stmt = conn.createStatement()) {
            String createTableSql = "CREATE TABLE IF NOT EXISTS meetings (" +
                    "id TEXT PRIMARY KEY, " +
                    "name TEXT NOT NULL, " +
                    "url TEXT NOT NULL, " +
                    "category TEXT, " +
                    "description TEXT, " +
                    "notes TEXT, " +
                    "scheduled_time TEXT, " +
                    "is_favorite INTEGER DEFAULT 0, " +
                    "color TEXT, " +
                    "join_count INTEGER DEFAULT 0, " +
                    "last_joined_at INTEGER, " +
                    "created_at INTEGER, " +
                    "updated_at INTEGER" +
                    ");";
            stmt.execute(createTableSql);

            // Create index for search speed
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_meetings_name ON meetings(name);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_meetings_category ON meetings(category);");

            // App settings key-value table for persistent user configurations (e.g. 1-Click Default Meeting)
            String createSettingsSql = "CREATE TABLE IF NOT EXISTS app_settings (" +
                    "key TEXT PRIMARY KEY, " +
                    "value TEXT NOT NULL" +
                    ");";
            stmt.execute(createSettingsSql);

            // Persistent audio recording sessions metadata table
            String createRecordingsSql = "CREATE TABLE IF NOT EXISTS recordings (" +
                    "id TEXT PRIMARY KEY, " +
                    "title TEXT, " +
                    "filename TEXT NOT NULL, " +
                    "file_path TEXT NOT NULL, " +
                    "start_time INTEGER NOT NULL, " +
                    "duration_ms INTEGER DEFAULT 0, " +
                    "size_bytes INTEGER DEFAULT 0, " +
                    "mode TEXT, " +
                    "consent_confirmed INTEGER DEFAULT 1" +
                    ");";
            stmt.execute(createRecordingsSql);
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_recordings_start_time ON recordings(start_time DESC);");

            // Enterprise User Accounts and Role-Based Access Table
            String createUsersSql = "CREATE TABLE IF NOT EXISTS users (" +
                    "id TEXT PRIMARY KEY, " +
                    "email TEXT UNIQUE NOT NULL, " +
                    "display_name TEXT NOT NULL, " +
                    "role TEXT NOT NULL, " +
                    "password_hash TEXT NOT NULL, " +
                    "salt TEXT NOT NULL, " +
                    "created_at INTEGER, " +
                    "last_login_at INTEGER" +
                    ");";
            stmt.execute(createUsersSql);
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);");

            // Active user login sessions & remember-me token table
            String createSessionsSql = "CREATE TABLE IF NOT EXISTS auth_sessions (" +
                    "token TEXT PRIMARY KEY, " +
                    "user_id TEXT NOT NULL, " +
                    "created_at INTEGER, " +
                    "expires_at INTEGER, " +
                    "remember_me INTEGER DEFAULT 0" +
                    ");";
            stmt.execute(createSessionsSql);
        }

        seedDefaultUsersIfEmpty();
    }

    /**
     * Imports records from legacy JSON file if database is freshly created.
     */
    private void migrateLegacyJsonIfNeeded() {
        if (Files.exists(legacyJsonFilePath)) {
            try {
                if (loadMeetingsFromDb().isEmpty()) {
                    List<Meeting> legacyMeetings = loadLegacyJson();
                    if (!legacyMeetings.isEmpty()) {
                        saveMeetings(legacyMeetings);
                        LOGGER.info("Migrated " + legacyMeetings.size() + " meetings from legacy JSON to SQLite.");
                    }
                }
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Legacy JSON migration skipped", e);
            }
        }
    }

    private List<Meeting> loadLegacyJson() {
        try (FileReader reader = new FileReader(legacyJsonFilePath.toFile())) {
            Type listType = new TypeToken<List<Meeting>>() {}.getType();
            List<Meeting> meetings = gson.fromJson(reader, listType);
            return meetings != null ? meetings : Collections.emptyList();
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    public synchronized List<Meeting> loadMeetings() throws IOException {
        try {
            return loadMeetingsFromDb();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "SQLite read failed, attempting legacy file read", e);
            return loadLegacyJson();
        }
    }

    private List<Meeting> loadMeetingsFromDb() throws SQLException {
        List<Meeting> list = new ArrayList<>();
        String sql = "SELECT id, name, url, category, description, notes, scheduled_time, " +
                "is_favorite, color, join_count, last_joined_at, created_at, updated_at " +
                "FROM meetings ORDER BY is_favorite DESC, name COLLATE NOCASE ASC;";

        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String url = rs.getString("url");
                String category = rs.getString("category");
                String desc = rs.getString("description");
                String notes = rs.getString("notes");
                String scheduledTime = rs.getString("scheduled_time");
                boolean favorite = rs.getInt("is_favorite") == 1;
                String color = rs.getString("color");
                int joinCount = rs.getInt("join_count");
                long lastJoined = rs.getLong("last_joined_at");
                Long lastJoinedAt = rs.wasNull() ? null : lastJoined;
                long createdAt = rs.getLong("created_at");
                long updatedAt = rs.getLong("updated_at");

                Meeting m = new Meeting(id, name, url, category, desc, notes,
                        scheduledTime, favorite, color,
                        createdAt, updatedAt, lastJoinedAt, joinCount);
                list.add(m);
            }
        }
        return list;
    }

    /**
     * Atomically saves all meetings to SQLite using a transaction.
     * Also mirrors to meetings.json as a secondary backup.
     */
    public synchronized void saveMeetings(List<Meeting> meetings) throws IOException {
        String insertSql = "INSERT OR REPLACE INTO meetings (id, name, url, category, description, " +
                "notes, scheduled_time, is_favorite, color, join_count, last_joined_at, created_at, updated_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try (Connection conn = DriverManager.getConnection(jdbcUrl)) {
            conn.setAutoCommit(false);
            try (Statement clearStmt = conn.createStatement();
                 PreparedStatement ps = conn.prepareStatement(insertSql)) {

                clearStmt.execute("DELETE FROM meetings;");

                if (meetings != null) {
                    for (Meeting m : meetings) {
                        ps.setString(1, m.getId());
                        ps.setString(2, m.getName());
                        ps.setString(3, m.getUrl());
                        ps.setString(4, m.getCategory());
                        ps.setString(5, m.getDescription());
                        ps.setString(6, m.getNotes());
                        ps.setString(7, m.getScheduledTime());
                        ps.setInt(8, m.isFavorite() ? 1 : 0);
                        ps.setString(9, m.getColor());
                        ps.setInt(10, m.getJoinCount());
                        if (m.getLastJoinedAt() != null) {
                            ps.setLong(11, m.getLastJoinedAt());
                        } else {
                            ps.setNull(11, Types.BIGINT);
                        }
                        ps.setLong(12, m.getCreatedAt());
                        ps.setLong(13, m.getUpdatedAt());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw new IOException("Failed to commit SQLite transaction: " + ex.getMessage(), ex);
            }
        } catch (SQLException e) {
            throw new IOException("SQLite database error: " + e.getMessage(), e);
        }

        // Secondary JSON mirror
        saveJsonMirror(meetings);
    }

    private void saveJsonMirror(List<Meeting> meetings) {
        try {
            Path tempFile = storageDirectory.resolve(JSON_FILE_NAME + ".tmp");
            BackupEnvelope envelope = new BackupEnvelope(meetings);
            try (FileWriter writer = new FileWriter(tempFile.toFile())) {
                gson.toJson(envelope, writer);
                writer.flush();
            }
            try {
                Files.move(tempFile, legacyJsonFilePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException e) {
                Files.move(tempFile, legacyJsonFilePath, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            LOGGER.log(Level.FINE, "Secondary JSON mirror write non-critical error", e);
        }
    }

    /**
     * Exports meetings using documented Cross-Platform Shared Schema v2.
     */
    public void exportBackup(File destinationFile, List<Meeting> meetings) throws IOException {
        if (destinationFile == null) {
            throw new IllegalArgumentException("Destination file cannot be null");
        }

        File parentDir = destinationFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        BackupEnvelope envelope = new BackupEnvelope(meetings);

        try (FileWriter writer = new FileWriter(destinationFile)) {
            gson.toJson(envelope, writer);
            writer.flush();
        }
    }

    /**
     * Imports meetings from a JSON backup file (supports schema v2 envelope and legacy v1 array).
     */
    public List<Meeting> importBackup(File backupFile) throws IOException {
        if (backupFile == null || !backupFile.exists()) {
            throw new IOException("Backup file does not exist.");
        }

        try (FileReader reader = new FileReader(backupFile)) {
            JsonElement root = JsonParser.parseReader(reader);
            List<Meeting> rawMeetings = new ArrayList<>();

            if (root.isJsonObject()) {
                JsonObject obj = root.getAsJsonObject();
                if (obj.has("records") && obj.get("records").isJsonArray()) {
                    Type listType = new TypeToken<List<Meeting>>() {}.getType();
                    rawMeetings = gson.fromJson(obj.get("records"), listType);
                }
            } else if (root.isJsonArray()) {
                Type listType = new TypeToken<List<Meeting>>() {}.getType();
                rawMeetings = gson.fromJson(root, listType);
            } else {
                throw new IOException("Invalid backup format. Must be JSON object with schemaVersion/records or a JSON array.");
            }

            if (rawMeetings == null) {
                return new ArrayList<>();
            }

            List<Meeting> validated = new ArrayList<>();
            for (Meeting m : rawMeetings) {
                if (m == null || m.getName() == null || m.getName().trim().isEmpty()) {
                    continue;
                }
                UrlValidationService.ValidationResult res = urlValidationService.validate(m.getUrl());
                if (res.isValid()) {
                    m.setUrl(res.getNormalizedUrl());
                    if (m.getId() == null || m.getId().trim().isEmpty()) {
                        m.setId(UUID.randomUUID().toString());
                    }
                    validated.add(m);
                }
            }
            return validated;
        } catch (Exception e) {
            throw new IOException("Failed to parse backup file: " + e.getMessage(), e);
        }
    }

    /**
     * Persistently saves the 1-Click Default Meeting configuration.
     */
     public synchronized void saveDefaultMeeting(DefaultMeetingConfig config) {
         if (config == null) return;
         try {
             setSetting("default_meeting_title", config.getTitle());
             setSetting("default_meeting_url", config.getUrl());
             setSetting("default_meeting_last_joined", String.valueOf(config.getLastJoinedAt()));
             setSetting("default_meeting_join_count", String.valueOf(config.getJoinCount()));
         } catch (Exception e) {
             LOGGER.log(Level.WARNING, "Failed to save default meeting configuration", e);
         }
     }

    /**
     * Loads the 1-Click Default Meeting configuration from local SQLite storage.
     */
    public synchronized DefaultMeetingConfig getDefaultMeeting() {
        try {
            String title = getSetting("default_meeting_title", "Primary Google Meet");
            String url = getSetting("default_meeting_url", "");
            long lastJoined = 0L;
            int joinCount = 0;
            try {
                lastJoined = Long.parseLong(getSetting("default_meeting_last_joined", "0"));
                joinCount = Integer.parseInt(getSetting("default_meeting_join_count", "0"));
            } catch (NumberFormatException ignored) {}

            return new DefaultMeetingConfig(title, url, lastJoined, joinCount);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to load default meeting configuration", e);
            return new DefaultMeetingConfig();
        }
    }

    public synchronized void setSetting(String key, String value) throws SQLException {
        if (key == null) return;
        String sql = "INSERT INTO app_settings(key, value) VALUES(?, ?) " +
                     "ON CONFLICT(key) DO UPDATE SET value = excluded.value;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, key);
            ps.setString(2, value != null ? value : "");
            ps.executeUpdate();
        }
    }

    public synchronized String getSetting(String key, String defaultValue) {
        if (key == null) return defaultValue;
        String sql = "SELECT value FROM app_settings WHERE key = ? LIMIT 1;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("value");
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.FINE, "Error reading setting: " + key, e);
        }
        return defaultValue;
    }

    public synchronized void saveRecordingSession(RecordingSession session) throws SQLException {
        if (session == null || session.getId() == null) return;
        String sql = "INSERT INTO recordings(id, title, filename, file_path, start_time, duration_ms, size_bytes, mode, consent_confirmed) " +
                     "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "ON CONFLICT(id) DO UPDATE SET " +
                     "title = excluded.title, " +
                     "duration_ms = excluded.duration_ms, " +
                     "size_bytes = excluded.size_bytes;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, session.getId());
            ps.setString(2, session.getMeetingTitle());
            ps.setString(3, session.getFilename());
            ps.setString(4, session.getFilePath());
            ps.setLong(5, session.getStartTime());
            ps.setLong(6, session.getDurationMs());
            ps.setLong(7, session.getFileSizeBytes());
            ps.setString(8, session.getMode() != null ? session.getMode().name() : RecordingMode.MIC_ONLY.name());
            ps.setInt(9, session.isConsentConfirmed() ? 1 : 0);
            ps.executeUpdate();
        }
    }

    public synchronized List<RecordingSession> loadRecordingSessions() {
        List<RecordingSession> list = new ArrayList<>();
        String sql = "SELECT * FROM recordings ORDER BY start_time DESC;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String id = rs.getString("id");
                String title = rs.getString("title");
                String filename = rs.getString("filename");
                String filePath = rs.getString("file_path");
                long startTime = rs.getLong("start_time");
                long durationMs = rs.getLong("duration_ms");
                long sizeBytes = rs.getLong("size_bytes");
                String modeStr = rs.getString("mode");
                boolean consent = rs.getInt("consent_confirmed") == 1;

                RecordingMode mode = RecordingMode.MIC_ONLY;
                if (modeStr != null) {
                    try {
                        mode = RecordingMode.valueOf(modeStr);
                    } catch (Exception ignored) {
                    }
                }

                list.add(new RecordingSession(id, title, filename, filePath, startTime, durationMs, sizeBytes, mode, consent));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error loading recording sessions from SQLite", e);
        }
        return list;
    }

    public synchronized void deleteRecordingSession(String id) throws SQLException {
        if (id == null) return;
        String sql = "DELETE FROM recordings WHERE id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
        }
    }

    // =========================================================================
    // User Accounts, PBKDF2 Password Storage, and Session Management
    // =========================================================================

    private void seedDefaultUsersIfEmpty() {
        try {
            if (getUserCount() == 0) {
                LOGGER.info("Seeding initial Administrator and Client accounts with PBKDF2 hashed credentials.");

                // 1. Initial Administrator account
                String adminSalt = PasswordSecurityUtil.generateSalt();
                String adminHash = PasswordSecurityUtil.hashPassword("AdminPassword123!".toCharArray(), adminSalt);
                User admin = new User(
                        "usr-admin-01",
                        "admin@meetmanager.com",
                        "System Administrator",
                        UserRole.ADMIN,
                        adminHash,
                        adminSalt,
                        System.currentTimeMillis(),
                        0L
                );
                saveUser(admin);

                // 2. Initial Client account
                String clientSalt = PasswordSecurityUtil.generateSalt();
                String clientHash = PasswordSecurityUtil.hashPassword("ClientPassword123!".toCharArray(), clientSalt);
                User client = new User(
                        "usr-client-01",
                        "client@company.com",
                        "Demo Client",
                        UserRole.CLIENT,
                        clientHash,
                        clientSalt,
                        System.currentTimeMillis(),
                        0L
                );
                saveUser(client);
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to seed default user accounts", e);
        }
    }

    public synchronized int getUserCount() {
        String sql = "SELECT COUNT(*) FROM users;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error checking user count", e);
        }
        return 0;
    }

    public synchronized void saveUser(User user) throws SQLException {
        if (user == null || user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Invalid user data");
        }
        String sql = "INSERT OR REPLACE INTO users " +
                "(id, email, display_name, role, password_hash, salt, created_at, last_login_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getId());
            ps.setString(2, user.getEmail().trim().toLowerCase());
            ps.setString(3, user.getDisplayName());
            ps.setString(4, user.getRole().name());
            ps.setString(5, user.getPasswordHash());
            ps.setString(6, user.getSalt());
            ps.setLong(7, user.getCreatedAt());
            ps.setLong(8, user.getLastLoginAt());
            ps.executeUpdate();
        }
    }

    public synchronized Optional<User> findUserByEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return Optional.empty();
        }
        String sql = "SELECT * FROM users WHERE LOWER(email) = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email.trim().toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapUser(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error querying user by email: " + email, e);
        }
        return Optional.empty();
    }

    public synchronized Optional<User> findUserById(String id) {
        if (id == null || id.trim().isEmpty()) {
            return Optional.empty();
        }
        String sql = "SELECT * FROM users WHERE id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapUser(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error querying user by ID: " + id, e);
        }
        return Optional.empty();
    }

    public synchronized List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY created_at ASC;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapUser(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error listing all users", e);
        }
        return list;
    }

    public synchronized void deleteUser(String id) throws SQLException {
        if (id == null) return;
        String sql = "DELETE FROM users WHERE id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
        }
    }

    public synchronized void updateUserPassword(String userId, String passwordHash, String salt) throws SQLException {
        if (userId == null || passwordHash == null || salt == null) return;
        String sql = "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, passwordHash);
            ps.setString(2, salt);
            ps.setString(3, userId);
            ps.executeUpdate();
        }
    }

    public synchronized void updateUserLastLogin(String userId, long timestamp) {
        if (userId == null) return;
        String sql = "UPDATE users SET last_login_at = ? WHERE id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, timestamp);
            ps.setString(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error updating last login timestamp", e);
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {
        return new User(
                rs.getString("id"),
                rs.getString("email"),
                rs.getString("display_name"),
                UserRole.fromString(rs.getString("role")),
                rs.getString("password_hash"),
                rs.getString("salt"),
                rs.getLong("created_at"),
                rs.getLong("last_login_at")
        );
    }

    // =========================================================================
    // Authentication Sessions & Remember-Me Tokens
    // =========================================================================

    public synchronized void saveAuthSession(String token, String userId, long createdAt, long expiresAt, boolean rememberMe) {
        String sql = "INSERT OR REPLACE INTO auth_sessions (token, user_id, created_at, expires_at, remember_me) " +
                "VALUES (?, ?, ?, ?, ?);";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, token);
            ps.setString(2, userId);
            ps.setLong(3, createdAt);
            ps.setLong(4, expiresAt);
            ps.setInt(5, rememberMe ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error saving auth session", e);
        }
    }

    public synchronized Optional<User> findUserBySessionToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            return Optional.empty();
        }
        String sql = "SELECT u.*, s.expires_at FROM auth_sessions s " +
                "JOIN users u ON s.user_id = u.id " +
                "WHERE s.token = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, token);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    long expiresAt = rs.getLong("expires_at");
                    if (expiresAt > 0 && expiresAt < System.currentTimeMillis()) {
                        // Session expired - clean up
                        deleteAuthSession(token);
                        return Optional.empty();
                    }
                    return Optional.of(mapUser(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error verifying session token", e);
        }
        return Optional.empty();
    }

    public synchronized void deleteAuthSession(String token) {
        if (token == null) return;
        String sql = "DELETE FROM auth_sessions WHERE token = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, token);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error deleting auth session", e);
        }
    }

    public synchronized void deleteUserSessions(String userId) {
        if (userId == null) return;
        String sql = "DELETE FROM auth_sessions WHERE user_id = ?;";
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error deleting user sessions", e);
        }
    }

    public synchronized String getRememberedSessionToken() {
        return getSetting("auth_remember_token");
    }

    public synchronized void saveRememberedSessionToken(String token) {
        if (token != null) {
            saveSetting("auth_remember_token", token);
        } else {
            clearRememberedSessionToken();
        }
    }

    public synchronized void clearRememberedSessionToken() {
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM app_settings WHERE key = 'auth_remember_token';")) {
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error clearing remembered session token", e);
        }
    }

    public Path getDataFilePath() {
        return dbFilePath;
    }

    public Path getStorageDirectory() {
        return storageDirectory;
    }
}
