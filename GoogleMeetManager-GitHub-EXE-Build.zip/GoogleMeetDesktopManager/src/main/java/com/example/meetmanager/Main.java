package com.example.meetmanager;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.ui.MainWindow;

import javax.swing.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Entry point for Google Meet Desktop Manager.
 * Configures modern Windows styling, high-DPI fonts, and launches the UI.
 */
public class Main {

    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        // High-DPI font rendering flags for Windows 10/11
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        setupLookAndFeel();

        SwingUtilities.invokeLater(() -> {
            try {
                MeetingService meetingService = new MeetingService();
                com.example.meetmanager.service.AuthService authService =
                        new com.example.meetmanager.service.AuthService(meetingService.getStorageService());

                // If launched for the first time with an empty database, seed helpful realistic example links
                if (meetingService.getMeetingCount() == 0) {
                    seedDefaultExamples(meetingService);
                }

                // Attempt to restore valid remembered session
                boolean hasRememberedSession = authService.restoreRememberedSession();

                if (hasRememberedSession && authService.isAuthenticated()) {
                    LOGGER.info("Active remembered session restored for: " + authService.getCurrentUser().getEmail());
                    MainWindow mainWindow = new MainWindow(meetingService, authService);
                    mainWindow.setVisible(true);
                } else {
                    // Show modern, professional Login Page
                    com.example.meetmanager.ui.LoginPage loginPage = new com.example.meetmanager.ui.LoginPage(meetingService, authService);
                    loginPage.setVisible(true);
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Failed to initialize Google Meet Desktop Manager", e);
                JOptionPane.showMessageDialog(null,
                        "Fatal error during application startup:\n" + e.getMessage(),
                        "Startup Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private static void setupLookAndFeel() {
        try {
            // Attempt FlatLaf modern Light theme for sleek Windows 11 rounded feel
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        } catch (Exception e) {
            try {
                // Fallback to Native Windows Look and Feel
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception fallbackEx) {
                LOGGER.log(Level.WARNING, "Failed to set native look and feel", fallbackEx);
            }
        }

        // Configure default font styling for clean readability
        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 13);
        UIManager.put("Button.font", defaultFont);
        UIManager.put("Label.font", defaultFont);
        UIManager.put("TextField.font", defaultFont);
        UIManager.put("ComboBox.font", defaultFont);
    }

    private static void seedDefaultExamples(MeetingService service) {
        try {
            service.addMeeting(new Meeting(
                    "Daily Engineering Standup",
                    "https://meet.google.com/abc-defg-hij",
                    "Daily Standup",
                    "Engineering team sync every weekday at 09:30 AM (Example Link)",
                    "Bring yesterday's PR updates and blockers"
            ));

            service.addMeeting(new Meeting(
                    "Product & Design Weekly",
                    "https://meet.google.com/pqr-stuv-wxy",
                    "Team Meetings",
                    "Weekly roadmap check-in and UX review (Example Link)",
                    "Sprint review slide deck in Google Drive"
            ));

            service.addMeeting(new Meeting(
                    "Client Consultation Room",
                    "https://meet.google.com/xyz-uvwx-rst",
                    "Clients",
                    "Permanent client briefing & demo link (Example Link)",
                    "Recordings automatically saved to Drive"
            ));
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Could not seed sample meetings", ex);
        }
    }
}
