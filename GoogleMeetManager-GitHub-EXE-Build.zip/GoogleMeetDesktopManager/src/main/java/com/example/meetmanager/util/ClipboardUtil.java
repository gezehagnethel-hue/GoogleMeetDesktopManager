package com.example.meetmanager.util;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utility for copying text to the Windows system clipboard.
 */
public final class ClipboardUtil {

    private static final Logger LOGGER = Logger.getLogger(ClipboardUtil.class.getName());

    private ClipboardUtil() {}

    /**
     * Copies the given text to the system clipboard.
     *
     * @param text String to copy
     * @return true if successful, false otherwise
     */
    public static boolean copyToClipboard(String text) {
        if (text == null) {
            return false;
        }
        try {
            StringSelection selection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
            return true;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to copy text to clipboard", e);
            return false;
        }
    }
}
