package com.example.meetmanager.audio;

public enum AudioRecordingState {
    IDLE("Idle - Ready to record"),
    RECORDING("Recording in progress"),
    PAUSED("Recording paused"),
    FINALIZING("Finalizing audio file..."),
    STOPPED("Recording stopped and saved");

    private final String description;

    AudioRecordingState(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
