package com.example.meetmanager.ui;

import com.example.meetmanager.model.User;
import com.example.meetmanager.model.UserRole;
import com.example.meetmanager.service.AuthService;
import com.example.meetmanager.service.MeetingService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Modern, enterprise-grade Login Screen for Google Meet Desktop Manager.
 * Features a dual-panel split layout:
 * - Left side: Branding, vector video conference illustration, and feature highlights.
 * - Right side: Elevated white card with email/password inputs, show/hide toggle,
 *   Remember Me, Forgot Password, prominent Sign In, and Contact Administrator modal.
 */
public class LoginPage extends JFrame {

    private final MeetingService meetingService;
    private final AuthService authService;

    // Form fields
    private JTextField emailField;
    private JPasswordField passwordField;
    private JCheckBox rememberMeCheckBox;
    private JButton showHidePasswordBtn;
    private JButton signInBtn;
    private JPanel errorBanner;
    private JLabel errorLabel;
    private boolean isPasswordVisible = false;

    // Color Palette
    private static final Color PRIMARY_BLUE = new Color(37, 99, 235);       // #2563EB
    private static final Color PRIMARY_HOVER = new Color(29, 78, 216);      // #1D4ED8
    private static final Color DARK_NAVY = new Color(15, 23, 42);           // #0F172A
    private static final Color BRAND_NAVY_START = new Color(14, 34, 77);    // #0E224D
    private static final Color BRAND_NAVY_END = new Color(30, 64, 175);     // #1E40AF
    private static final Color ACCENT_CYAN = new Color(6, 182, 212);        // #06B6D4
    private static final Color CARD_BG = Color.WHITE;
    private static final Color PAGE_BG = new Color(248, 250, 252);          // #F8FAFC
    private static final Color BORDER_GRAY = new Color(226, 232, 240);       // #E2E8F0
    private static final Color TEXT_MUTED = new Color(100, 116, 139);       // #64748B
    private static final Color ERROR_BG = new Color(254, 242, 242);         // #FEF2F2
    private static final Color ERROR_BORDER = new Color(254, 202, 202);     // #FECACA
    private static final Color ERROR_TEXT = new Color(185, 28, 28);         // #B91C1C

    public LoginPage(MeetingService meetingService, AuthService authService) {
        super("Google Meet Manager - Sign In");
        this.meetingService = meetingService;
        this.authService = authService;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 640);
        setMinimumSize(new Dimension(880, 580));
        setLocationRelativeTo(null);

        initUI();
    }

    private void initUI() {
        JPanel rootPanel = new JPanel(new GridLayout(1, 2));
        rootPanel.setBackground(PAGE_BG);

        // Left Branding Panel
        JPanel leftPanel = createLeftBrandingPanel();
        rootPanel.add(leftPanel);

        // Right Login Card Panel
        JPanel rightPanel = createRightLoginPanel();
        rootPanel.add(rightPanel);

        setContentPane(rootPanel);
        getRootPane().setDefaultButton(signInBtn);
    }

    // =========================================================================
    // Left Branding & Video Meeting Illustration Panel
    // =========================================================================

    private JPanel createLeftBrandingPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Deep modern gradient from brand navy to royal blue with subtle cyan depth
                GradientPaint gp = new GradientPaint(0, 0, BRAND_NAVY_START, getWidth(), getHeight(), BRAND_NAVY_END);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // Subtle ambient cyan light circle in bottom right
                g2d.setColor(new Color(6, 182, 212, 28));
                g2d.fillOval(getWidth() - 240, getHeight() - 240, 360, 360);

                // Subtle ambient blue light in top left
                g2d.setColor(new Color(59, 130, 246, 25));
                g2d.fillOval(-80, -80, 260, 260);

                g2d.dispose();
            }
        };
        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(36, 40, 32, 40));

        // 1. Top Branding Header
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        // Logo row with camera badge
        JPanel logoRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoRow.setOpaque(false);

        JLabel logoBadge = new JLabel("📹 ") {
            @Override
            public Font getFont() {
                return new Font("Segoe UI Emoji", Font.PLAIN, 26);
            }
        };

        JLabel appTitle = new JLabel("Google Meet Manager");
        appTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        appTitle.setForeground(Color.WHITE);

        logoRow.add(logoBadge);
        logoRow.add(Box.createHorizontalStrut(6));
        logoRow.add(appTitle);
        headerPanel.add(logoRow);

        JLabel appSubtitle = new JLabel("Enterprise Meeting Launch & Recording Platform");
        appSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        appSubtitle.setForeground(new Color(191, 219, 254)); // #BFDBFE
        appSubtitle.setBorder(new EmptyBorder(4, 34, 0, 0));
        headerPanel.add(appSubtitle);

        panel.add(headerPanel, BorderLayout.NORTH);

        // 2. Center Illustration
        CourtImagePanel illustrationPanel = new CourtImagePanel();
        panel.add(illustrationPanel, BorderLayout.CENTER);

        // 3. Bottom Feature Highlights & Version Info
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));

        bottomPanel.add(createFeatureItem("⚡", "One-Click Instant Join", "Launch authorized Google Meet links in 1 click via browser or app."));
        bottomPanel.add(Box.createVerticalStrut(10));
        bottomPanel.add(createFeatureItem("🎙", "Consent-Based Audio Recording", "Loopback and mic capture with full participant disclosure compliance."));
        bottomPanel.add(Box.createVerticalStrut(10));
        bottomPanel.add(createFeatureItem("🔒", "Enterprise Role Security", "Dedicated Administrator and Client accounts with PBKDF2 offline storage."));

        bottomPanel.add(Box.createVerticalStrut(18));

        JLabel versionLabel = new JLabel("v2.4 LTS Enterprise • Zero Cloud Telemetry • Offline SQLite");
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        versionLabel.setForeground(new Color(147, 197, 253, 180));
        bottomPanel.add(versionLabel);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createFeatureItem(String icon, String title, String description) {
        JPanel item = new JPanel(new BorderLayout(10, 0));
        item.setOpaque(false);

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 15));
        iconLabel.setForeground(ACCENT_CYAN);
        item.add(iconLabel, BorderLayout.WEST);

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setForeground(Color.WHITE);

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        descLabel.setForeground(new Color(203, 213, 225)); // #CBD5E1

        textPanel.add(titleLabel);
        textPanel.add(descLabel);

        item.add(textPanel, BorderLayout.CENTER);
        return item;
    }

    // =========================================================================
    // Right Login Card Panel
    // =========================================================================

    private JPanel createRightLoginPanel() {
        JPanel container = new JPanel(new GridBagLayout());
        container.setBackground(PAGE_BG);
        container.setBorder(new EmptyBorder(24, 24, 24, 24));

        // Elevated White Card
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int arc = 20;
                // Card background
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);

                // Subtle border
                g2.setColor(BORDER_GRAY);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);

                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(32, 34, 28, 34));
        card.setPreferredSize(new Dimension(420, 540));
        card.setMaximumSize(new Dimension(440, 560));

        // 1. Welcome Header
        JLabel welcomeLabel = new JLabel("Welcome Back");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomeLabel.setForeground(DARK_NAVY);
        welcomeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(welcomeLabel);

        JLabel subtitleLabel = new JLabel("Please sign in to access your meeting dashboard.");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(TEXT_MUTED);
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(subtitleLabel);

        card.add(Box.createVerticalStrut(16));

        // 2. Error Banner (Initially Hidden)
        errorBanner = new JPanel(new BorderLayout(8, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ERROR_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.setColor(ERROR_BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
            }
        };
        errorBanner.setOpaque(false);
        errorBanner.setBorder(new EmptyBorder(8, 12, 8, 12));
        errorBanner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        errorBanner.setAlignmentX(Component.LEFT_ALIGNMENT);
        errorBanner.setVisible(false);

        JLabel errorIcon = new JLabel("⚠️");
        errorIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        errorBanner.add(errorIcon, BorderLayout.WEST);

        errorLabel = new JLabel("Invalid email or password.");
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        errorLabel.setForeground(ERROR_TEXT);
        errorBanner.add(errorLabel, BorderLayout.CENTER);

        card.add(errorBanner);
        card.add(Box.createVerticalStrut(14));

        // 3. Email Field
        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        emailLabel.setForeground(DARK_NAVY);
        emailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(emailLabel);
        card.add(Box.createVerticalStrut(6));

        emailField = new JTextField();
        emailField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        emailField.setPreferredSize(new Dimension(Integer.MAX_VALUE, 38));
        emailField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        emailField.setAlignmentX(Component.LEFT_ALIGNMENT);
        emailField.putClientProperty("JTextField.placeholderText", "name@company.com");
        card.add(emailField);

        card.add(Box.createVerticalStrut(14));

        // 4. Password Field with Show/Hide toggle
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        passwordLabel.setForeground(DARK_NAVY);
        passwordLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(passwordLabel);
        card.add(Box.createVerticalStrut(6));

        JPanel passwordContainer = new JPanel(new BorderLayout(4, 0));
        passwordContainer.setOpaque(false);
        passwordContainer.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        passwordContainer.setAlignmentX(Component.LEFT_ALIGNMENT);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        passwordField.setPreferredSize(new Dimension(Integer.MAX_VALUE, 38));
        passwordField.putClientProperty("JTextField.placeholderText", "Enter your password");

        showHidePasswordBtn = new JButton("👁");
        showHidePasswordBtn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        showHidePasswordBtn.setToolTipText("Show / Hide Password");
        showHidePasswordBtn.setFocusPainted(false);
        showHidePasswordBtn.setContentAreaFilled(false);
        showHidePasswordBtn.setBorder(new EmptyBorder(0, 8, 0, 8));
        showHidePasswordBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        showHidePasswordBtn.addActionListener(e -> togglePasswordVisibility());

        passwordContainer.add(passwordField, BorderLayout.CENTER);
        passwordContainer.add(showHidePasswordBtn, BorderLayout.EAST);
        card.add(passwordContainer);

        card.add(Box.createVerticalStrut(12));

        // 5. Options Row: Remember Me & Forgot Password
        JPanel optionsRow = new JPanel(new BorderLayout());
        optionsRow.setOpaque(false);
        optionsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        optionsRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        rememberMeCheckBox = new JCheckBox("Remember me");
        rememberMeCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rememberMeCheckBox.setForeground(DARK_NAVY);
        rememberMeCheckBox.setOpaque(false);
        rememberMeCheckBox.setFocusPainted(false);
        rememberMeCheckBox.setSelected(true);
        optionsRow.add(rememberMeCheckBox, BorderLayout.WEST);

        JButton forgotPasswordBtn = createLinkButton("Forgot Password?");
        forgotPasswordBtn.addActionListener(e -> showForgotPasswordDialog());
        optionsRow.add(forgotPasswordBtn, BorderLayout.EAST);

        card.add(optionsRow);

        card.add(Box.createVerticalStrut(18));

        // 6. Prominent Sign In Button
        signInBtn = new JButton("Sign In") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(PRIMARY_HOVER.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(PRIMARY_HOVER);
                } else {
                    g2.setColor(PRIMARY_BLUE);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        signInBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signInBtn.setForeground(Color.WHITE);
        signInBtn.setContentAreaFilled(false);
        signInBtn.setBorderPainted(false);
        signInBtn.setFocusPainted(false);
        signInBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signInBtn.setPreferredSize(new Dimension(Integer.MAX_VALUE, 42));
        signInBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        signInBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        signInBtn.addActionListener(e -> handleLogin());
        card.add(signInBtn);

        card.add(Box.createVerticalStrut(12));

        // 7. Sign in with Google (Informative SSO button)
        JButton googleSignInBtn = new JButton("Sign in with Google Workspace") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(241, 245, 249) : Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.setColor(BORDER_GRAY);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        googleSignInBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        googleSignInBtn.setForeground(DARK_NAVY);
        googleSignInBtn.setContentAreaFilled(false);
        googleSignInBtn.setBorderPainted(false);
        googleSignInBtn.setFocusPainted(false);
        googleSignInBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        googleSignInBtn.setPreferredSize(new Dimension(Integer.MAX_VALUE, 38));
        googleSignInBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        googleSignInBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        googleSignInBtn.addActionListener(e -> showGoogleSsoNotice());
        card.add(googleSignInBtn);

        card.add(Box.createVerticalStrut(18));

        // 8. Contact Administrator Link
        JPanel footerRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        footerRow.setOpaque(false);
        footerRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel needAccountLabel = new JLabel("Need an account?");
        needAccountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        needAccountLabel.setForeground(TEXT_MUTED);

        JButton contactAdminBtn = createLinkButton("Contact Administrator");
        contactAdminBtn.addActionListener(e -> showContactAdminDialog());

        footerRow.add(needAccountLabel);
        footerRow.add(contactAdminBtn);
        card.add(footerRow);

        container.add(card);
        return container;
    }

    private JButton createLinkButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(PRIMARY_BLUE);
        btn.setBorder(null);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setForeground(PRIMARY_HOVER);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setForeground(PRIMARY_BLUE);
            }
        });
        return btn;
    }

    private void togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible;
        if (isPasswordVisible) {
            passwordField.setEchoChar((char) 0);
            showHidePasswordBtn.setText("🙈");
        } else {
            passwordField.setEchoChar('•');
            showHidePasswordBtn.setText("👁");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorBanner.setVisible(true);
        errorBanner.revalidate();
        errorBanner.repaint();
    }

    private void clearError() {
        errorBanner.setVisible(false);
        errorBanner.revalidate();
        errorBanner.repaint();
    }

    // =========================================================================
    // Login Execution & Role Redirection
    // =========================================================================

    private void handleLogin() {
        clearError();

        String email = emailField.getText() != null ? emailField.getText().trim() : "";
        char[] password = passwordField.getPassword();
        boolean rememberMe = rememberMeCheckBox.isSelected();

        if (email.isEmpty()) {
            showError("Please enter your email address.");
            emailField.requestFocusInWindow();
            return;
        }

        if (password.length == 0) {
            showError("Please enter your password.");
            passwordField.requestFocusInWindow();
            return;
        }

        // Disable button while authenticating
        signInBtn.setEnabled(false);
        signInBtn.setText("Signing In...");

        SwingUtilities.invokeLater(() -> {
            try {
                AuthService.AuthResult result = authService.login(email, password, rememberMe);

                if (result.isSuccess()) {
                    User user = result.getUser();
                    // Dispose login screen
                    dispose();

                    // Open Main application window with role-tailored dashboard
                    MainWindow mainWindow = new MainWindow(meetingService, authService);
                    mainWindow.setVisible(true);

                    // Show welcome notification
                    String roleTitle = user.isAdmin() ? "Administrator" : "Client Member";
                    JOptionPane.showMessageDialog(mainWindow,
                            "Welcome back, " + user.getDisplayName() + "!\n" +
                                    "Logged in as: " + roleTitle + " (" + user.getEmail() + ")",
                            "Login Successful",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    showError(result.getErrorMessage());
                    signInBtn.setEnabled(true);
                    signInBtn.setText("Sign In");
                    passwordField.setText("");
                    passwordField.requestFocusInWindow();
                }
            } catch (Exception ex) {
                showError("An unexpected error occurred during login. Please try again.");
                signInBtn.setEnabled(true);
                signInBtn.setText("Sign In");
            }
        });
    }

    private void showForgotPasswordDialog() {
        JOptionPane.showMessageDialog(this,
                "Password Recovery Assistance:\n\n" +
                        "For enterprise security, password resets are authorized by your System Administrator.\n\n" +
                        "1. Please contact your administrator at admin@meetmanager.com.\n" +
                        "2. An administrator can securely reset your credentials from the User Management console.\n\n" +
                        "(Default administrator credential for initial setup is: admin@meetmanager.com / AdminPassword123!)",
                "Forgot Password",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void showContactAdminDialog() {
        JDialog dialog = new JDialog(this, "Contact Administrator", true);
        dialog.setSize(440, 320);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new BorderLayout(16, 16));
        panel.setBorder(new EmptyBorder(24, 24, 24, 24));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Enterprise Account Access");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(DARK_NAVY);
        panel.add(title, BorderLayout.NORTH);

        JTextArea body = new JTextArea(
                "Google Meet Desktop Manager accounts are provisioned and managed locally with offline PBKDF2 encryption.\n\n" +
                        "• Default Administrator: admin@meetmanager.com\n" +
                        "  (Initial setup password: AdminPassword123!)\n\n" +
                        "• Demo Client Member: client@company.com\n" +
                        "  (Initial setup password: ClientPassword123!)\n\n" +
                        "Administrators can create client accounts, assign meeting launchpads, and reset passwords directly via the User Management dialog."
        );
        body.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        body.setForeground(DARK_NAVY);
        body.setEditable(false);
        body.setOpaque(false);
        body.setLineWrap(true);
        body.setWrapStyleWord(true);
        panel.add(body, BorderLayout.CENTER);

        JButton closeBtn = new JButton("Understood");
        closeBtn.addActionListener(e -> dialog.dispose());
        JPanel btnPanel = new FlowLayout(FlowLayout.RIGHT);
        btnPanel.setOpaque(false);
        btnPanel.add(closeBtn);
        panel.add(btnPanel, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private void showGoogleSsoNotice() {
        JOptionPane.showMessageDialog(this,
                "Google Workspace Single Sign-On (SSO):\n\n" +
                        "To connect corporate Google Workspace OAuth for desktop browser authentication:\n" +
                        "1. Configure your organization's Google Cloud OAuth Client ID in Settings.\n" +
                        "2. Standard email/password authentication is currently active with offline SQLite encryption.\n\n" +
                        "Use your authorized company email and password to sign in.",
                "Google Workspace SSO",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // =========================================================================
    // Oromia Supreme Court image panel (login branding only)
    // =========================================================================

    private static class CourtImagePanel extends JPanel {
        private final Image courtImage;

        public CourtImagePanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(380, 220));
            Image loaded = null;
            try (java.io.InputStream in = LoginPage.class.getResourceAsStream(
                    "/images/oromia-supreme-court.jpg")) {
                if (in != null) loaded = javax.imageio.ImageIO.read(in);
            } catch (java.io.IOException ignored) {
                // Keep the login screen usable if the optional branding image is unavailable.
            }
            courtImage = loaded;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

            int w = getWidth();
            int h = getHeight();
            int x = 4, y = 8, drawW = Math.max(1, w - 8), drawH = Math.max(1, h - 16);
            Shape clip = new RoundRectangle2D.Float(x, y, drawW, drawH, 18, 18);
            g2.setClip(clip);
            g2.setColor(new Color(15, 23, 42));
            g2.fillRect(x, y, drawW, drawH);

            if (courtImage != null) {
                int iw = courtImage.getWidth(this);
                int ih = courtImage.getHeight(this);
                if (iw > 0 && ih > 0) {
                    double scale = Math.max((double) drawW / iw, (double) drawH / ih);
                    int sw = (int) Math.ceil(iw * scale);
                    int sh = (int) Math.ceil(ih * scale);
                    g2.drawImage(courtImage, x + (drawW - sw) / 2, y + (drawH - sh) / 2, sw, sh, this);
                }
            } else {
                g2.setColor(new Color(30, 64, 175));
                g2.fillRect(x, y, drawW, drawH);
            }

            // Subtle lower gradient ensures the court name remains legible.
            g2.setPaint(new GradientPaint(0, y + drawH * 0.55f, new Color(15, 23, 42, 0),
                    0, y + drawH, new Color(15, 23, 42, 210)));
            g2.fillRect(x, y, drawW, drawH);
            g2.setClip(null);
            g2.setColor(new Color(255, 255, 255, 225));
            g2.setStroke(new BasicStroke(1.2f));
            g2.draw(clip);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
            String title = "Oromia Supreme Court";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(title, x + 16, y + drawH - 18);
            g2.dispose();
        }
    }
}
