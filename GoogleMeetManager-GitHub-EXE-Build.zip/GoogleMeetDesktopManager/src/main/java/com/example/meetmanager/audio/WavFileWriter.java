package com.example.meetmanager.audio;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Streams 16-bit PCM audio samples directly to a standard compliant WAV (RIFF) file.
 * Flushes data progressively so memory usage remains low during long meetings.
 */
public class WavFileWriter implements AutoCloseable {

    private final File outputFile;
    private final RandomAccessFile raf;
    private final int sampleRate;
    private final int channels;
    private final int bitsPerSample;
    private long totalAudioBytes = 0;
    private boolean closed = false;

    public WavFileWriter(File outputFile, int sampleRate, int channels, int bitsPerSample) throws IOException {
        this.outputFile = outputFile;
        this.sampleRate = sampleRate;
        this.channels = channels;
        this.bitsPerSample = bitsPerSample;

        // Ensure parent directory exists
        File parent = outputFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        this.raf = new RandomAccessFile(outputFile, "rw");
        // Write placeholder 44-byte header
        writeWavHeader(0);
    }

    public synchronized void writeSamples(byte[] data, int offset, int length) throws IOException {
        if (closed) {
            throw new IOException("Cannot write to closed WavFileWriter");
        }
        raf.write(data, offset, length);
        totalAudioBytes += length;
    }

    private void writeWavHeader(long audioDataLength) throws IOException {
        long totalDataLen = audioDataLength + 36;
        int byteRate = sampleRate * channels * (bitsPerSample / 8);
        int blockAlign = channels * (bitsPerSample / 8);

        byte[] header = new byte[44];
        // RIFF header
        header[0] = 'R';
        header[1] = 'I';
        header[2] = 'F';
        header[3] = 'F';
        header[4] = (byte) (totalDataLen & 0xff);
        header[5] = (byte) ((totalDataLen >> 8) & 0xff);
        header[6] = (byte) ((totalDataLen >> 16) & 0xff);
        header[7] = (byte) ((totalDataLen >> 24) & 0xff);
        // WAVE
        header[8] = 'W';
        header[9] = 'A';
        header[10] = 'V';
        header[11] = 'E';
        // 'fmt ' chunk
        header[12] = 'f';
        header[13] = 'm';
        header[14] = 't';
        header[15] = ' ';
        header[16] = 16; // 16 for PCM
        header[17] = 0;
        header[18] = 0;
        header[19] = 0;
        header[20] = 1; // AudioFormat 1 = PCM
        header[21] = 0;
        header[22] = (byte) channels;
        header[23] = 0;
        header[24] = (byte) (sampleRate & 0xff);
        header[25] = (byte) ((sampleRate >> 8) & 0xff);
        header[26] = (byte) ((sampleRate >> 16) & 0xff);
        header[27] = (byte) ((sampleRate >> 24) & 0xff);
        header[28] = (byte) (byteRate & 0xff);
        header[29] = (byte) ((byteRate >> 8) & 0xff);
        header[30] = (byte) ((byteRate >> 16) & 0xff);
        header[31] = (byte) ((byteRate >> 24) & 0xff);
        header[32] = (byte) blockAlign;
        header[33] = 0;
        header[34] = (byte) bitsPerSample;
        header[35] = 0;
        // 'data' chunk
        header[36] = 'd';
        header[37] = 'a';
        header[38] = 't';
        header[39] = 'a';
        header[40] = (byte) (audioDataLength & 0xff);
        header[41] = (byte) ((audioDataLength >> 8) & 0xff);
        header[42] = (byte) ((audioDataLength >> 16) & 0xff);
        header[43] = (byte) ((audioDataLength >> 24) & 0xff);

        raf.seek(0);
        raf.write(header);
    }

    public synchronized long getTotalAudioBytes() {
        return totalAudioBytes;
    }

    public File getOutputFile() {
        return outputFile;
    }

    @Override
    public synchronized void close() throws IOException {
        if (!closed) {
            closed = true;
            try {
                // Finalize RIFF header with accurate lengths
                writeWavHeader(totalAudioBytes);
            } finally {
                raf.close();
            }
        }
    }
}
