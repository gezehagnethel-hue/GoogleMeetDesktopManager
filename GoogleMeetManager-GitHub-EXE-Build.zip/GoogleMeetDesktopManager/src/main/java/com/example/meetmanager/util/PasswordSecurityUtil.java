package com.example.meetmanager.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.regex.Pattern;

/**
 * Enterprise security utility for password hashing, cryptographic salting,
 * constant-time verification, and credential format validation.
 * Uses PBKDF2 with HMAC-SHA256 (65,536 iterations) - NIST recommended standard.
 */
public final class PasswordSecurityUtil {

    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATION_COUNT = 65536;
    private static final int KEY_LENGTH = 256;
    private static final int SALT_LENGTH_BYTES = 16;
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$"
    );

    private PasswordSecurityUtil() {
        // Private constructor for utility class
    }

    /**
     * Generates a cryptographically secure random salt encoded in Base64.
     */
    public static String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        SECURE_RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Hashes a password using PBKDF2WithHmacSHA256 and the provided salt.
     * Never stores plaintext passwords.
     */
    public static String hashPassword(char[] password, String saltBase64) {
        if (password == null || password.length == 0) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
        if (saltBase64 == null || saltBase64.trim().isEmpty()) {
            throw new IllegalArgumentException("Salt cannot be empty");
        }

        try {
            byte[] salt = Base64.getDecoder().decode(saltBase64);
            KeySpec spec = new PBEKeySpec(password, salt, ITERATION_COUNT, KEY_LENGTH);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // Fallback to SHA-256 with salt if PBKDF2 is unavailable on the JRE
            return fallbackSha256(password, saltBase64);
        }
    }

    /**
     * Verifies a candidate password against the stored hash and salt using
     * constant-time byte comparison to prevent side-channel timing attacks.
     */
    public static boolean verifyPassword(char[] candidatePassword, String storedHash, String storedSaltBase64) {
        if (candidatePassword == null || storedHash == null || storedSaltBase64 == null) {
            return false;
        }
        try {
            String candidateHash = hashPassword(candidatePassword, storedSaltBase64);
            byte[] a = candidateHash.getBytes();
            byte[] b = storedHash.getBytes();
            return MessageDigest.isEqual(a, b);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Validates whether an email string conforms to standard email format.
     */
    public static boolean isValidEmail(String email) {
        if (email == null) return false;
        String trimmed = email.trim();
        return !trimmed.isEmpty() && EMAIL_PATTERN.matcher(trimmed).matches();
    }

    /**
     * Checks if a password meets minimum complexity guidelines.
     */
    public static ValidationResult validatePasswordRequirements(char[] password) {
        if (password == null || password.length == 0) {
            return new ValidationResult(false, "Password cannot be empty.");
        }
        if (password.length < 6) {
            return new ValidationResult(false, "Password must be at least 6 characters long.");
        }
        return new ValidationResult(true, "Password meets criteria.");
    }

    private static String fallbackSha256(char[] password, String saltBase64) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(Base64.getDecoder().decode(saltBase64));
            byte[] passwordBytes = new String(password).getBytes("UTF-8");
            byte[] hash = digest.digest(passwordBytes);
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception ex) {
            throw new RuntimeException("Cryptographic digest unavailable", ex);
        }
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String message;

        public ValidationResult(boolean valid, String message) {
            this.valid = valid;
            this.message = message;
        }

        public boolean isValid() {
            return valid;
        }

        public String getMessage() {
            return message;
        }
    }
}
