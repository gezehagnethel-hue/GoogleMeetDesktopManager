package com.example.meetmanager.ui;

import com.example.meetmanager.model.DefaultMeetingConfig;
import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.UrlValidationService;
import com.example.meetmanager.util.BrowserUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;

/**
 * Main application window: "My Meeting Center"
 * Responsive dashboard providing:
 * 1. Prominent One-Click "JOIN MEETING NOW" launcher card
 * 2. Dedicated Multi-Button Launchpad ("1 interface, multi button" view)
 * 3. Detailed meeting cards view
 * Includes batch multi-button creation, live search, and 1-click launchers.
 */
public class MainWindow extends JFrame {

    private final MeetingService meetingService;
    private final com.example.meetmanager.service.AuthService authService;

    // View Modes
    public enum ViewMode {
        MULTI_BUTTON_PAD,
        DETAILED_CARDS,
        AUDIO_RECORDING
    }
    private ViewMode currentViewMode = ViewMode.MULTI_BUTTON_PAD;

    // UI state
    private JTextField searchField;
    private JComboBox<String> categoryFilterCombo;
    private JLabel countBadgeLabel;
    private JPanel cardsContainer;
    private JScrollPane scrollPane;
    private QuickLaunchBoard quickLaunchBoard;
    private RecordingPanel recordingPanel;
    private JPanel mainContentSwitcher;
    private CardLayout contentCardLayout;
    private JPanel emptyStatePanel;
    private JLabel statusLabel;
    private JButton multiButtonModeBtn;
    private JButton cardModeBtn;
    private JButton recordingModeBtn;

    // Hero "JOIN MEETING NOW" UI Elements
    private JLabel heroTitleLabel;
    private JLabel heroUrlLabel;
    private JLabel heroStatusLabel;
    private JButton joinMeetingNowBtn;

    public MainWindow(MeetingService meetingService) {
        this(meetingService, new com.example.meetmanager.service.AuthService(meetingService.getStorageService()));
    }

    public MainWindow(MeetingService meetingService, com.example.meetmanager.service.AuthService authService) {
        super("My Meeting Center" + (authService != null && authService.getCurrentUser() != null ?
                " - " + authService.getCurrentUser().getDisplayName() + " [" + authService.getCurrentUser().getRole().getDisplayName() + "]" : ""));
        this.meetingService = meetingService;
        this.authService = authService;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(880, 620));
        setSize(1040, 740);
        setLocationRelativeTo(null);

        initMenuBar();
        initUI();

        // Listen for data updates to auto-refresh UI
        this.meetingService.addChangeListener(this::refreshDashboard);

        // Initial render
        refreshDashboard();
    }

    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);

        JMenuItem joinNowItem = new JMenuItem("⚡ Join Meeting Now");
        joinNowItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        joinNowItem.addActionListener(e -> handleJoinNow());

        JMenuItem defaultSettingsItem = new JMenuItem("Meeting Settings (Default Link)...");
        defaultSettingsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        defaultSettingsItem.addActionListener(e -> showDefaultMeetingSettingsDialog());

        JMenuItem addMeetingItem = new JMenuItem("Add Meeting...");
        addMeetingItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        addMeetingItem.addActionListener(e -> showAddMeetingDialog());

        JMenuItem batchAddItem = new JMenuItem("Add Multiple Buttons (Batch)...");
        batchAddItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        batchAddItem.addActionListener(e -> showBatchAddDialog());

        JMenuItem recordingConsoleItem = new JMenuItem("🎙 Audio Recording Console...");
        recordingConsoleItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        recordingConsoleItem.addActionListener(e -> setViewMode(ViewMode.AUDIO_RECORDING));

        JMenuItem settingsItem = new JMenuItem("Settings & Local Storage...");
        settingsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_COMMA, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        settingsItem.addActionListener(e -> showSettingsDialog());

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(joinNowItem);
        fileMenu.add(defaultSettingsItem);
        fileMenu.addSeparator();
        fileMenu.add(addMeetingItem);
        fileMenu.add(batchAddItem);
        fileMenu.addSeparator();
        fileMenu.add(recordingConsoleItem);
        fileMenu.add(settingsItem);
        fileMenu.addSeparator();

        if (authService != null && authService.isAdmin()) {
            JMenuItem userMgmtItem = new JMenuItem("👥 User Management & Roles...");
            userMgmtItem.addActionListener(e -> showUserManagementDialog());
            fileMenu.add(userMgmtItem);
        }

        String userDisplay = (authService != null && authService.getCurrentUser() != null) ?
                authService.getCurrentUser().getEmail() : "Logout";
        JMenuItem signOutItem = new JMenuItem("🚪 Sign Out (" + userDisplay + ")");
        signOutItem.addActionListener(e -> handleSignOut());
        fileMenu.add(signOutItem);

        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // View Menu
        JMenu viewMenu = new JMenu("View");
        viewMenu.setMnemonic(KeyEvent.VK_V);

        JMenuItem multiBtnItem = new JMenuItem("Switch to Multi-Button Pad View");
        multiBtnItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        multiBtnItem.addActionListener(e -> setViewMode(ViewMode.MULTI_BUTTON_PAD));

        JMenuItem cardsItem = new JMenuItem("Switch to Detailed Cards View");
        cardsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_2, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        cardsItem.addActionListener(e -> setViewMode(ViewMode.DETAILED_CARDS));

        JMenuItem recordingViewItem = new JMenuItem("Switch to Audio Recording Console");
        recordingViewItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_3, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        recordingViewItem.addActionListener(e -> setViewMode(ViewMode.AUDIO_RECORDING));

        JMenuItem refreshItem = new JMenuItem("Refresh Meetings");
        refreshItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
        refreshItem.addActionListener(e -> refreshDashboard());

        JMenuItem focusSearchItem = new JMenuItem("Focus Search Bar");
        focusSearchItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        focusSearchItem.addActionListener(e -> {
            if (searchField != null) searchField.requestFocusInWindow();
        });

        viewMenu.add(multiBtnItem);
        viewMenu.add(cardsItem);
        viewMenu.add(recordingViewItem);
        viewMenu.addSeparator();
        viewMenu.add(refreshItem);
        viewMenu.add(focusSearchItem);

        // Help Menu
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);

        JMenuItem aboutItem = new JMenuItem("About Google Meet Desktop Manager");
        aboutItem.addActionListener(e -> new AboutDialog(this).setVisible(true));

        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(viewMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);
    }

    private void initUI() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(new Color(248, 249, 250));

        // 1. Header Toolbar
        rootPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Central Switcher: Multi-Button Pad vs Detailed Cards
        contentCardLayout = new CardLayout();
        mainContentSwitcher = new JPanel(contentCardLayout);
        mainContentSwitcher.setOpaque(false);

        // Subview A: Multi-Button Launch Board
        quickLaunchBoard = new QuickLaunchBoard(
                this::handleMeetingJoined,
                this::handleEditMeeting,
                this::handleDeleteMeeting,
                this::handleDuplicateMeeting,
                this::handleToggleFavorite
        );
        mainContentSwitcher.add(quickLaunchBoard, ViewMode.MULTI_BUTTON_PAD.name());

        // Subview B: Detailed Scrollable Cards View
        cardsContainer = new JPanel();
        cardsContainer.setLayout(new BoxLayout(cardsContainer, BoxLayout.Y_AXIS));
        cardsContainer.setBackground(new Color(248, 249, 250));
        cardsContainer.setBorder(new EmptyBorder(12, 24, 20, 24));

        scrollPane = new JScrollPane(cardsContainer);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBackground(new Color(248, 249, 250));
        mainContentSwitcher.add(scrollPane, ViewMode.DETAILED_CARDS.name());

        // Subview C: Consent-Based Audio Recording Dashboard
        recordingPanel = new RecordingPanel(this, meetingService.getStorageService());
        mainContentSwitcher.add(recordingPanel, ViewMode.AUDIO_RECORDING.name());

        emptyStatePanel = createEmptyStatePanel();

        rootPanel.add(mainContentSwitcher, BorderLayout.CENTER);

        // 3. Status Bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 231, 239)),
                new EmptyBorder(6, 16, 6, 16)
        ));
        statusBar.setBackground(Color.WHITE);

        statusLabel = new JLabel("Ready. Single-interface multi-button launcher active.");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(95, 99, 104));

        JLabel privacyNote = new JLabel("1 Interface • Multi Button Launcher • Windows 10/11");
        privacyNote.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        privacyNote.setForeground(new Color(128, 134, 139));

        statusBar.add(statusLabel, BorderLayout.WEST);
        statusBar.add(privacyNote, BorderLayout.EAST);
        rootPanel.add(statusBar, BorderLayout.SOUTH);

        setContentPane(rootPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 231, 239)));

        // Top Row: Title, Subtitle & Action Buttons
        JPanel topRow = new JPanel(new BorderLayout(16, 0));
        topRow.setOpaque(false);
        topRow.setBorder(new EmptyBorder(16, 24, 12, 24));

        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);

        JPanel titleBadgeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        titleBadgeRow.setOpaque(false);

        JLabel appTitle = new JLabel("My Meeting Center");
        appTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        appTitle.setForeground(new Color(32, 33, 36));

        countBadgeLabel = new JLabel("0 buttons");
        countBadgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        countBadgeLabel.setForeground(new Color(26, 115, 232));
        countBadgeLabel.setBackground(new Color(232, 240, 254));
        countBadgeLabel.setOpaque(true);
        countBadgeLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(194, 217, 254), 1, true),
                new EmptyBorder(3, 8, 3, 8)
        ));

        titleBadgeRow.add(appTitle);
        titleBadgeRow.add(countBadgeLabel);
        titles.add(titleBadgeRow);

        JLabel subtitle = new JLabel("Google Meet Desktop Manager • Single-screen multi-button launcher");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(new Color(95, 99, 104));
        subtitle.setBorder(new EmptyBorder(4, 0, 0, 0));
        titles.add(subtitle);

        // Buttons Group: Add Meeting, Batch Multi-Button, & View Mode
        JPanel topActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        topActions.setOpaque(false);

        // View Mode Segmented Switch
        JPanel viewSwitch = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
        viewSwitch.setBackground(new Color(241, 243, 244));
        viewSwitch.setBorder(BorderFactory.createLineBorder(new Color(218, 220, 224), 1, true));

        multiButtonModeBtn = new JButton("🎛️ Multi-Button Pad");
        multiButtonModeBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        multiButtonModeBtn.setFocusPainted(false);
        multiButtonModeBtn.setBackground(new Color(26, 115, 232));
        multiButtonModeBtn.setForeground(Color.WHITE);
        multiButtonModeBtn.addActionListener(e -> setViewMode(ViewMode.MULTI_BUTTON_PAD));

        cardModeBtn = new JButton("📋 Cards View");
        cardModeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        cardModeBtn.setFocusPainted(false);
        cardModeBtn.setBackground(new Color(241, 243, 244));
        cardModeBtn.setForeground(new Color(60, 64, 67));
        cardModeBtn.addActionListener(e -> setViewMode(ViewMode.DETAILED_CARDS));

        recordingModeBtn = new JButton("🎙 Audio Recording");
        recordingModeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        recordingModeBtn.setFocusPainted(false);
        recordingModeBtn.setBackground(new Color(241, 243, 244));
        recordingModeBtn.setForeground(new Color(60, 64, 67));
        recordingModeBtn.addActionListener(e -> setViewMode(ViewMode.AUDIO_RECORDING));

        viewSwitch.add(multiButtonModeBtn);
        viewSwitch.add(cardModeBtn);
        viewSwitch.add(recordingModeBtn);

        JButton batchBtn = new JButton("+ Multi-Add");
        batchBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        batchBtn.setFocusPainted(false);
        batchBtn.setToolTipText("Add multiple meeting buttons at once");
        batchBtn.addActionListener(e -> showBatchAddDialog());

        JButton addBtn = new JButton("+ Add Button");
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addBtn.setForeground(Color.WHITE);
        addBtn.setBackground(new Color(26, 115, 232));
        addBtn.setFocusPainted(false);
        addBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addBtn.addActionListener(e -> showAddMeetingDialog());

        topActions.add(viewSwitch);
        topActions.add(batchBtn);
        topActions.add(addBtn);

        if (authService != null && authService.getCurrentUser() != null) {
            com.example.meetmanager.model.User user = authService.getCurrentUser();
            JPanel userBadge = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            userBadge.setOpaque(false);
            userBadge.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(203, 213, 225), 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));

            String roleTag = user.isAdmin() ? "ADMIN" : "CLIENT";
            Color roleColor = user.isAdmin() ? new Color(37, 99, 235) : new Color(13, 148, 136);

            JLabel userRoleLabel = new JLabel(roleTag);
            userRoleLabel.setFont(new Font("Segoe UI", Font.BOLD, 10));
            userRoleLabel.setForeground(roleColor);

            JLabel userNameLabel = new JLabel(user.getDisplayName());
            userNameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            userNameLabel.setForeground(new Color(30, 41, 59));

            userBadge.add(userRoleLabel);
            userBadge.add(userNameLabel);
            topActions.add(userBadge);

            if (user.isAdmin()) {
                JButton userMgmtBtn = new JButton("👥 Users");
                userMgmtBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                userMgmtBtn.setFocusPainted(false);
                userMgmtBtn.setToolTipText("Open User Management & Roles");
                userMgmtBtn.addActionListener(e -> showUserManagementDialog());
                topActions.add(userMgmtBtn);
            }

            JButton signOutBtn = new JButton("🚪 Sign Out");
            signOutBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            signOutBtn.setFocusPainted(false);
            signOutBtn.setToolTipText("Sign out of current account (" + user.getEmail() + ")");
            signOutBtn.addActionListener(e -> handleSignOut());
            topActions.add(signOutBtn);
        }

        topRow.add(titles, BorderLayout.WEST);
        topRow.add(topActions, BorderLayout.EAST);

        // Center Hero Row: Ultra-Prominent "JOIN MEETING NOW" Card
        JPanel heroRow = createHeroJoinPanel();

        // Bottom Row: Live Search & Category Filter
        JPanel filterRow = new JPanel(new BorderLayout(14, 0));
        filterRow.setOpaque(false);
        filterRow.setBorder(new EmptyBorder(0, 24, 14, 24));

        // Search Field
        JPanel searchBox = new JPanel(new BorderLayout(8, 0));
        searchBox.setOpaque(false);

        JLabel searchIconLabel = new JLabel("🔍 Search:");
        searchIconLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        searchIconLabel.setForeground(new Color(95, 99, 104));

        searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        searchField.putClientProperty("JTextField.placeholderText", "Filter buttons by name, code, category, or description...");
        searchField.setPreferredSize(new Dimension(340, 32));
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                applyFilterAndRender();
            }
        });

        searchBox.add(searchIconLabel, BorderLayout.WEST);
        searchBox.add(searchField, BorderLayout.CENTER);

        // Category Filter Combo
        JPanel catBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        catBox.setOpaque(false);

        JLabel catLabel = new JLabel("Category:");
        catLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        catLabel.setForeground(new Color(95, 99, 104));

        categoryFilterCombo = new JComboBox<>();
        categoryFilterCombo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        categoryFilterCombo.addItem("All Categories");
        categoryFilterCombo.setPreferredSize(new Dimension(170, 32));
        categoryFilterCombo.addActionListener(e -> applyFilterAndRender());

        JButton clearFilterBtn = new JButton("Clear");
        clearFilterBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        clearFilterBtn.addActionListener(e -> {
            searchField.setText("");
            categoryFilterCombo.setSelectedIndex(0);
            applyFilterAndRender();
        });

        catBox.add(catLabel);
        catBox.add(categoryFilterCombo);
        catBox.add(clearFilterBtn);

        filterRow.add(searchBox, BorderLayout.CENTER);
        filterRow.add(catBox, BorderLayout.EAST);

        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(topRow);
        header.add(heroRow);
        header.add(filterRow);
        return header;
    }

    private JPanel createHeroJoinPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(0, 24, 14, 24));

        JPanel card = new JPanel(new BorderLayout(16, 0));
        card.setBackground(new Color(15, 23, 42)); // Deep Navy
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(30, 41, 59), 1, true),
                new EmptyBorder(14, 20, 14, 20)
        ));

        // Left info column
        JPanel infoCol = new JPanel();
        infoCol.setLayout(new BoxLayout(infoCol, BoxLayout.Y_AXIS));
        infoCol.setOpaque(false);

        JLabel tagLabel = new JLabel("⚡ ONE-CLICK INSTANT LAUNCHER");
        tagLabel.setFont(new Font("Segoe UI", Font.BOLD, 10));
        tagLabel.setForeground(new Color(56, 189, 248)); // Sky Blue
        tagLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        heroTitleLabel = new JLabel("Primary Google Meet");
        heroTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 17));
        heroTitleLabel.setForeground(Color.WHITE);
        heroTitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        heroUrlLabel = new JLabel("https://meet.google.com/...");
        heroUrlLabel.setFont(new Font("Consolas", Font.PLAIN, 12));
        heroUrlLabel.setForeground(new Color(148, 163, 184)); // Slate
        heroUrlLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        heroStatusLabel = new JLabel("Configured & ready to launch");
        heroStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        heroStatusLabel.setForeground(new Color(52, 211, 153)); // Emerald
        heroStatusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        infoCol.add(tagLabel);
        infoCol.add(Box.createVerticalStrut(3));
        infoCol.add(heroTitleLabel);
        infoCol.add(Box.createVerticalStrut(2));
        infoCol.add(heroUrlLabel);
        infoCol.add(Box.createVerticalStrut(4));
        infoCol.add(heroStatusLabel);

        // Right button column
        JPanel actionsCol = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionsCol.setOpaque(false);

        JButton settingsBtn = new JButton("⚙️ Meeting Settings");
        settingsBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        settingsBtn.setFocusPainted(false);
        settingsBtn.setBackground(new Color(30, 41, 59));
        settingsBtn.setForeground(new Color(226, 232, 240));
        settingsBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true),
                new EmptyBorder(10, 14, 10, 14)
        ));
        settingsBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        settingsBtn.setToolTipText("Configure or update the default Google Meet link");
        settingsBtn.addActionListener(e -> showDefaultMeetingSettingsDialog());

        joinMeetingNowBtn = new JButton("⚡ JOIN MEETING NOW");
        joinMeetingNowBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        joinMeetingNowBtn.setForeground(Color.WHITE);
        joinMeetingNowBtn.setBackground(new Color(26, 115, 232)); // Bright Blue
        joinMeetingNowBtn.setFocusPainted(false);
        joinMeetingNowBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(66, 133, 244), 1, true),
                new EmptyBorder(10, 22, 10, 22)
        ));
        joinMeetingNowBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        joinMeetingNowBtn.setToolTipText("Immediately launch your configured Google Meet in the default browser");
        joinMeetingNowBtn.addActionListener(e -> handleJoinNow());

        actionsCol.add(settingsBtn);
        actionsCol.add(joinMeetingNowBtn);

        card.add(infoCol, BorderLayout.CENTER);
        card.add(actionsCol, BorderLayout.EAST);
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private void updateHeroJoinPanel() {
        if (heroTitleLabel == null || heroUrlLabel == null || heroStatusLabel == null || joinMeetingNowBtn == null) {
            return;
        }

        DefaultMeetingConfig config = meetingService.getDefaultMeeting();
        if (config.isConfigured()) {
            heroTitleLabel.setText(config.getTitle());
            heroUrlLabel.setText(config.getUrl());
            UrlValidationService.ValidationResult res = meetingService.getUrlValidationService().validate(config.getUrl());
            if (res.isValid()) {
                heroStatusLabel.setText("✓ Ready • " + (config.getJoinCount() > 0 ? "Joined " + config.getJoinCount() + " times" : "Click to launch instantly in default browser"));
                heroStatusLabel.setForeground(new Color(52, 211, 153));
                joinMeetingNowBtn.setBackground(new Color(26, 115, 232));
                joinMeetingNowBtn.setText("⚡ JOIN MEETING NOW");
            } else {
                heroStatusLabel.setText("⚠️ Invalid meeting URL: " + res.getMessage());
                heroStatusLabel.setForeground(new Color(248, 113, 113));
                joinMeetingNowBtn.setBackground(new Color(185, 28, 28));
                joinMeetingNowBtn.setText("⚠️ FIX MEETING LINK");
            }
        } else {
            heroTitleLabel.setText("No Default Meeting Configured");
            heroUrlLabel.setText("Configure your permanent Google Meet URL once to join with 1 click");
            heroStatusLabel.setText("⚠️ Please configure your Google Meet link first.");
            heroStatusLabel.setForeground(new Color(251, 191, 36)); // Amber
            joinMeetingNowBtn.setBackground(new Color(51, 65, 85));
            joinMeetingNowBtn.setText("⚡ SET UP MEETING LINK");
        }
    }

    public void setViewMode(ViewMode mode) {
        this.currentViewMode = mode;
        if (mode == ViewMode.MULTI_BUTTON_PAD) {
            multiButtonModeBtn.setBackground(new Color(26, 115, 232));
            multiButtonModeBtn.setForeground(Color.WHITE);
            cardModeBtn.setBackground(new Color(241, 243, 244));
            cardModeBtn.setForeground(new Color(60, 64, 67));
            recordingModeBtn.setBackground(new Color(241, 243, 244));
            recordingModeBtn.setForeground(new Color(60, 64, 67));
            setStatus("Switched to Multi-Button Pad View");
        } else if (mode == ViewMode.DETAILED_CARDS) {
            cardModeBtn.setBackground(new Color(26, 115, 232));
            cardModeBtn.setForeground(Color.WHITE);
            multiButtonModeBtn.setBackground(new Color(241, 243, 244));
            multiButtonModeBtn.setForeground(new Color(60, 64, 67));
            recordingModeBtn.setBackground(new Color(241, 243, 244));
            recordingModeBtn.setForeground(new Color(60, 64, 67));
            setStatus("Switched to Detailed Cards View");
        } else if (mode == ViewMode.AUDIO_RECORDING) {
            recordingModeBtn.setBackground(new Color(15, 23, 42)); // Slate 900
            recordingModeBtn.setForeground(Color.WHITE);
            multiButtonModeBtn.setBackground(new Color(241, 243, 244));
            multiButtonModeBtn.setForeground(new Color(60, 64, 67));
            cardModeBtn.setBackground(new Color(241, 243, 244));
            cardModeBtn.setForeground(new Color(60, 64, 67));
            setStatus("Switched to Audio Recording Console (Authorized Hosts & Administrators)");
        }
        contentCardLayout.show(mainContentSwitcher, mode.name());
        applyFilterAndRender();
    }

    private JPanel createEmptyStatePanel() {
        JPanel empty = new JPanel();
        empty.setLayout(new BoxLayout(empty, BoxLayout.Y_AXIS));
        empty.setOpaque(false);
        empty.setBorder(new EmptyBorder(60, 40, 60, 40));

        JLabel iconLabel = new JLabel("🎛️", SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel("No Saved Meeting Buttons Found", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(32, 33, 36));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(new EmptyBorder(12, 0, 6, 0));

        JLabel descLabel = new JLabel("Create multiple buttons for your recurring Google Meet rooms.", SwingConstants.CENTER);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        descLabel.setForeground(new Color(95, 99, 104));
        descLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        descLabel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnRow.setOpaque(false);

        JButton addFirstBtn = new JButton("+ Add Meeting Button");
        addFirstBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        addFirstBtn.setForeground(Color.WHITE);
        addFirstBtn.setBackground(new Color(26, 115, 232));
        addFirstBtn.addActionListener(e -> showAddMeetingDialog());

        JButton batchBtn = new JButton("+ Multi-Add Buttons");
        batchBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        batchBtn.addActionListener(e -> showBatchAddDialog());

        btnRow.add(addFirstBtn);
        btnRow.add(batchBtn);
        btnRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        empty.add(iconLabel);
        empty.add(titleLabel);
        empty.add(descLabel);
        empty.add(btnRow);

        return empty;
    }

    private void updateCategoryOptions() {
        String current = (String) categoryFilterCombo.getSelectedItem();
        categoryFilterCombo.removeAllItems();
        categoryFilterCombo.addItem("All Categories");

        Set<String> categories = meetingService.getAllCategories();
        for (String cat : categories) {
            categoryFilterCombo.addItem(cat);
        }

        if (current != null) {
            for (int i = 0; i < categoryFilterCombo.getItemCount(); i++) {
                if (categoryFilterCombo.getItemAt(i).equalsIgnoreCase(current)) {
                    categoryFilterCombo.setSelectedIndex(i);
                    return;
                }
            }
        }
    }

    public void refreshDashboard() {
        updateCategoryOptions();
        updateHeroJoinPanel();
        applyFilterAndRender();
    }

    private void applyFilterAndRender() {
        String query = searchField != null ? searchField.getText() : "";
        String cat = categoryFilterCombo != null ? (String) categoryFilterCombo.getSelectedItem() : "All Categories";

        List<Meeting> results = meetingService.filterAndSearch(query, cat);
        int totalCount = meetingService.getMeetingCount();

        countBadgeLabel.setText(totalCount + (totalCount == 1 ? " button" : " buttons"));

        if (currentViewMode == ViewMode.MULTI_BUTTON_PAD) {
            quickLaunchBoard.renderButtons(results);
        } else {
            cardsContainer.removeAll();
            if (results.isEmpty()) {
                if (totalCount == 0) {
                    cardsContainer.add(emptyStatePanel);
                } else {
                    JPanel noMatch = new JPanel();
                    noMatch.setLayout(new BoxLayout(noMatch, BoxLayout.Y_AXIS));
                    noMatch.setOpaque(false);
                    noMatch.setBorder(new EmptyBorder(40, 20, 40, 20));

                    JLabel msg = new JLabel("No meetings match: \"" + query + "\"");
                    msg.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                    msg.setForeground(new Color(95, 99, 104));
                    msg.setAlignmentX(Component.CENTER_ALIGNMENT);

                    JButton resetBtn = new JButton("Reset Filter");
                    resetBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                    resetBtn.addActionListener(e -> {
                        searchField.setText("");
                        categoryFilterCombo.setSelectedIndex(0);
                        applyFilterAndRender();
                    });

                    noMatch.add(msg);
                    noMatch.add(Box.createVerticalStrut(12));
                    noMatch.add(resetBtn);
                    cardsContainer.add(noMatch);
                }
            } else {
                for (Meeting meeting : results) {
                    MeetingCard card = new MeetingCard(
                            meeting,
                            this::handleEditMeeting,
                            this::handleDeleteMeeting,
                            this::handleMeetingJoined,
                            this::handleDuplicateMeeting,
                            this::handleToggleFavorite
                    );
                    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
                    cardsContainer.add(card);
                    cardsContainer.add(Box.createVerticalStrut(10));
                }
            }
            cardsContainer.revalidate();
            cardsContainer.repaint();
        }
    }

    private void showAddMeetingDialog() {
        MeetingDialog dialog = new MeetingDialog(this, meetingService, null);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            setStatus("Meeting button created successfully.");
        }
    }

    private void showBatchAddDialog() {
        BatchAddDialog dialog = new BatchAddDialog(this, meetingService);
        dialog.setVisible(true);
        if (dialog.isAddedAny()) {
            setStatus("Multiple meeting buttons created.");
        }
    }

    private void handleEditMeeting(Meeting meeting) {
        MeetingDialog dialog = new MeetingDialog(this, meetingService, meeting);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            setStatus("Meeting button '" + meeting.getName() + "' updated.");
        }
    }

    private void handleDeleteMeeting(Meeting meeting) {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Delete meeting button:\n\n" +
                        "\"" + meeting.getName() + "\"\n" +
                        "(" + meeting.getUrl() + ")?\n\n" +
                        "This will remove the button from your launcher.",
                "Confirm Delete Button",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                meetingService.deleteMeeting(meeting.getId());
                setStatus("Deleted meeting button: " + meeting.getName());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to delete: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleMeetingJoined(Meeting meeting) {
        meetingService.recordMeetingJoined(meeting.getId());
        setStatus("Launched: " + meeting.getName() + " (" + meeting.getUrl() + ")");
    }

    private void handleDuplicateMeeting(Meeting meeting) {
        try {
            Meeting copy = meetingService.duplicateMeeting(meeting.getId());
            setStatus("Duplicated button: " + copy.getName());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to duplicate: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleToggleFavorite(Meeting meeting) {
        try {
            boolean isFav = meetingService.toggleFavorite(meeting.getId());
            setStatus((isFav ? "Starred favorite: " : "Unstarred: ") + meeting.getName());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to update favorite status: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleJoinNow() {
        DefaultMeetingConfig config = meetingService.getDefaultMeeting();
        if (!config.isConfigured()) {
            int choice = JOptionPane.showOptionDialog(
                    this,
                    "Please configure your Google Meet link first.\n\n" +
                    "Would you like to set your default Google Meet link now?",
                    "Meeting Link Required",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"Configure Link Now", "Cancel"},
                    "Configure Link Now"
            );
            if (choice == JOptionPane.YES_OPTION) {
                showDefaultMeetingSettingsDialog();
            }
            return;
        }

        UrlValidationService.ValidationResult val = meetingService.getUrlValidationService().validate(config.getUrl());
        if (!val.isValid()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot join meeting: The configured link is invalid or unavailable.\n\n" +
                    "Error: " + val.getMessage() + "\n\n" +
                    "Please update your Google Meet URL in Meeting Settings.",
                    "Invalid Meeting Link",
                    JOptionPane.ERROR_MESSAGE
            );
            showDefaultMeetingSettingsDialog();
            return;
        }

        try {
            BrowserUtil.openUrl(val.getNormalizedUrl());
            meetingService.recordDefaultMeetingJoined();
            setStatus("Joined " + config.getTitle() + " (" + val.getNormalizedUrl() + ")");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not open default web browser for Google Meet:\n" + ex.getMessage(),
                    "Browser Launch Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void showDefaultMeetingSettingsDialog() {
        DefaultMeetingSettingsDialog dialog = new DefaultMeetingSettingsDialog(this, meetingService);
        dialog.setVisible(true);
        updateHeroJoinPanel();
    }

    private void showSettingsDialog() {
        SettingsDialog dialog = new SettingsDialog(this, meetingService);
        dialog.setVisible(true);
    }

    private void showUserManagementDialog() {
        if (authService != null && authService.isAdmin()) {
            UserManagementDialog dialog = new UserManagementDialog(this, authService);
            dialog.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Access restricted to system administrators.", "Access Denied", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleSignOut() {
        int opt = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to sign out from your Google Meet Manager account?",
                "Confirm Sign Out",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (opt == JOptionPane.YES_OPTION) {
            if (authService != null) {
                authService.logout();
            }
            dispose();
            SwingUtilities.invokeLater(() -> {
                LoginPage loginPage = new LoginPage(meetingService, authService != null ? authService : new com.example.meetmanager.service.AuthService(meetingService.getStorageService()));
                loginPage.setVisible(true);
            });
        }
    }

    public void setStatus(String text) {
        if (statusLabel != null) {
            statusLabel.setText(text);
        }
    }
}
