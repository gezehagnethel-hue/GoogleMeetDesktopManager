package com.example.meetmanager.audio;

/**
 * Mixes two 16-bit signed PCM audio byte streams (e.g., local microphone and remote system audio)
 * into a single synchronized stream with dynamic headroom scaling and anti-clipping protection.
 */
public class AudioMixer {

    private final float micGain;
    private final float systemGain;

    public AudioMixer() {
        this(0.9f, 0.9f);
    }

    public AudioMixer(float micGain, float systemGain) {
        this.micGain = micGain;
        this.systemGain = systemGain;
    }

    /**
     * Mixes two buffers of 16-bit PCM little-endian audio samples of equal length.
     */
    public byte[] mixPcmBuffers(byte[] micBuffer, int micLen, byte[] sysBuffer, int sysLen) {
        int maxLen = Math.max(micLen, sysLen);
        // Ensure even number of bytes for 16-bit samples
        if (maxLen % 2 != 0) {
            maxLen--;
        }
        byte[] mixed = new byte[maxLen];

        for (int i = 0; i < maxLen; i += 2) {
            short sMic = 0;
            if (i + 1 < micLen) {
                sMic = (short) ((micBuffer[i] & 0xFF) | (micBuffer[i + 1] << 8));
            }

            short sSys = 0;
            if (i + 1 < sysLen) {
                sSys = (short) ((sysBuffer[i] & 0xFF) | (sysBuffer[i + 1] << 8));
            }

            int mixedSample = (int) (sMic * micGain + sSys * systemGain);

            // Soft-limit anti-clipping
            if (mixedSample > Short.MAX_VALUE) {
                mixedSample = Short.MAX_VALUE;
            } else if (mixedSample < Short.MIN_VALUE) {
                mixedSample = Short.MIN_VALUE;
            }

            mixed[i] = (byte) (mixedSample & 0xFF);
            mixed[i + 1] = (byte) ((mixedSample >> 8) & 0xFF);
        }

        return mixed;
    }

    /**
     * Calculates peak amplitude (0.0 to 1.0) from a 16-bit PCM buffer for UI audio meters.
     */
    public static float calculatePeakLevel(byte[] buffer, int length) {
        if (buffer == null || length < 2) return 0f;
        int max = 0;
        for (int i = 0; i < length - 1; i += 2) {
            short sample = (short) ((buffer[i] & 0xFF) | (buffer[i + 1] << 8));
            int abs = Math.abs(sample);
            if (abs > max) {
                max = abs;
            }
        }
        return Math.min(1.0f, max / 32767.0f);
    }
}
