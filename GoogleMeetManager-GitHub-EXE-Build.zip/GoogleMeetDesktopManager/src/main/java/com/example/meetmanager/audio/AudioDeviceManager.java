package com.example.meetmanager.audio;

import javax.sound.sampled.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Enumerates and monitors audio capture devices on Windows.
 * Distinguishes between local microphone inputs and system loopback/stereo mix devices.
 */
public class AudioDeviceManager {

    private static final String[] LOOPBACK_KEYWORDS = {
            "stereo mix", "what u hear", "loopback", "wave out",
            "virtual audio", "cable output", "voicemeeter", "soundflower",
            "blackhole", "mixage stéréo", "mezcla estéreo", "stereomix"
    };

    public static class DeviceInfo {
        private final Mixer.Info mixerInfo;
        private final boolean isLoopback;
        private final boolean isMicrophone;

        public DeviceInfo(Mixer.Info mixerInfo, boolean isLoopback, boolean isMicrophone) {
            this.mixerInfo = mixerInfo;
            this.isLoopback = isLoopback;
            this.isMicrophone = isMicrophone;
        }

        public Mixer.Info getMixerInfo() {
            return mixerInfo;
        }

        public String getName() {
            return mixerInfo.getName();
        }

        public String getDescription() {
            return mixerInfo.getDescription();
        }

        public boolean isLoopback() {
            return isLoopback;
        }

        public boolean isMicrophone() {
            return isMicrophone;
        }

        @Override
        public String toString() {
            return getName() + (isLoopback ? " [System Audio Loopback]" : " [Microphone]");
        }
    }

    /**
     * Finds all available audio input devices capable of providing a TargetDataLine.
     */
    public List<DeviceInfo> getAvailableInputDevices() {
        List<DeviceInfo> devices = new ArrayList<>();
        Mixer.Info[] mixerInfos = AudioSystem.getMixerInfo();

        AudioFormat standardFormat = new AudioFormat(44100.0f, 16, 1, true, false);
        DataLine.Info targetLineInfo = new DataLine.Info(TargetDataLine.class, standardFormat);

        for (Mixer.Info info : mixerInfos) {
            try {
                Mixer mixer = AudioSystem.getMixer(info);
                if (mixer.isLineSupported(targetLineInfo)) {
                    String nameLower = info.getName().toLowerCase();
                    boolean isLoopback = false;
                    for (String kw : LOOPBACK_KEYWORDS) {
                        if (nameLower.contains(kw)) {
                            isLoopback = true;
                            break;
                        }
                    }
                    devices.add(new DeviceInfo(info, isLoopback, !isLoopback));
                }
            } catch (Exception ignored) {
            }
        }
        return devices;
    }

    /**
     * Checks if a system audio loopback capture device is currently active on this machine.
     */
    public boolean isSystemLoopbackAvailable() {
        for (DeviceInfo dev : getAvailableInputDevices()) {
            if (dev.isLoopback()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the first detected loopback mixer info, or null if none is available.
     */
    public Mixer.Info getLoopbackMixerInfo() {
        for (DeviceInfo dev : getAvailableInputDevices()) {
            if (dev.isLoopback()) {
                return dev.getMixerInfo();
            }
        }
        return null;
    }

    /**
     * Returns the primary microphone mixer info.
     */
    public Mixer.Info getMicrophoneMixerInfo() {
        for (DeviceInfo dev : getAvailableInputDevices()) {
            if (!dev.isLoopback()) {
                return dev.getMixerInfo();
            }
        }
        // Fallback to null (AudioSystem default target line)
        return null;
    }
}
