package com.example.meetmanager.model;

/**
 * Authorization roles for Google Meet Manager users.
 */
public enum UserRole {
    ADMIN("Administrator", "Full system access, meeting management, backup/restore, user administration"),
    CLIENT("Client Member", "Standard access to launch meetings, view assigned launchpad, and authorized recording");

    private final String displayName;
    private final String description;

    UserRole(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public boolean canManageMeetings() {
        return this == ADMIN;
    }

    public boolean canManageUsers() {
        return this == ADMIN;
    }

    public boolean canConfigureStorage() {
        return this == ADMIN;
    }

    public boolean canPerformBackupRestore() {
        return this == ADMIN;
    }

    public static UserRole fromString(String roleStr) {
        if (roleStr == null) return CLIENT;
        try {
            return UserRole.valueOf(roleStr.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return CLIENT;
        }
    }
}
