package com.example.meetmanager.ui;

import com.example.meetmanager.model.User;
import com.example.meetmanager.model.UserRole;
import com.example.meetmanager.service.AuthService;
import com.example.meetmanager.util.PasswordSecurityUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Administrative dialog for managing user accounts, provisioning client credentials,
 * resetting passwords, and viewing audit access logs.
 */
public class UserManagementDialog extends JDialog {

    private final AuthService authService;
    private final JTable userTable;
    private final DefaultTableModel tableModel;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public UserManagementDialog(Frame owner, AuthService authService) {
        super(owner, "User Management & Role Administration", true);
        this.authService = authService;

        setSize(760, 480);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(12, 12));

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout(8, 4));
        headerPanel.setBorder(new EmptyBorder(16, 20, 8, 20));
        JLabel title = new JLabel("Enterprise Account & Role Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel subtitle = new JLabel("Provision client accounts, reset credentials, and assign administrative permissions.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(new Color(100, 116, 139));
        headerPanel.add(title, BorderLayout.NORTH);
        headerPanel.add(subtitle, BorderLayout.SOUTH);
        add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"Name", "Email", "Role", "Created", "Last Login"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        userTable = new JTable(tableModel);
        userTable.setRowHeight(28);
        userTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));

        // Center align role and date columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        userTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        userTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        userTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);

        JScrollPane scrollPane = new JScrollPane(userTable);
        scrollPane.setBorder(new EmptyBorder(0, 20, 0, 20));
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Controls
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(new EmptyBorder(12, 20, 16, 20));

        JPanel leftActions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JButton addUserBtn = new JButton("+ Add User");
        addUserBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addUserBtn.addActionListener(e -> showAddUserDialog());

        JButton resetPassBtn = new JButton("Reset Password...");
        resetPassBtn.addActionListener(e -> handleResetPassword());

        JButton deleteUserBtn = new JButton("Delete User");
        deleteUserBtn.addActionListener(e -> handleDeleteUser());

        leftActions.add(addUserBtn);
        leftActions.add(resetPassBtn);
        leftActions.add(deleteUserBtn);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> dispose());
        rightActions.add(closeBtn);

        bottomPanel.add(leftActions, BorderLayout.WEST);
        bottomPanel.add(rightActions, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        refreshUserList();
    }

    private void refreshUserList() {
        tableModel.setRowCount(0);
        List<User> users = authService.getAllUsers();
        for (User u : users) {
            String createdStr = dateFormat.format(new Date(u.getCreatedAt()));
            String loginStr = u.getLastLoginAt() > 0 ? dateFormat.format(new Date(u.getLastLoginAt())) : "Never";
            tableModel.addRow(new Object[]{
                    u.getDisplayName(),
                    u.getEmail(),
                    u.getRole().getDisplayName(),
                    createdStr,
                    loginStr
            });
        }
    }

    private void showAddUserDialog() {
        JDialog dialog = new JDialog(this, "Add New User Account", true);
        dialog.setSize(420, 360);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new GridLayout(4, 2, 8, 12));
        form.setBorder(new EmptyBorder(16, 20, 16, 20));

        form.add(new JLabel("Full Name:"));
        JTextField nameField = new JTextField();
        form.add(nameField);

        form.add(new JLabel("Email Address:"));
        JTextField emailField = new JTextField();
        form.add(emailField);

        form.add(new JLabel("Role:"));
        JComboBox<UserRole> roleCombo = new JComboBox<>(UserRole.values());
        roleCombo.setSelectedItem(UserRole.CLIENT);
        form.add(roleCombo);

        form.add(new JLabel("Initial Password:"));
        JPasswordField passField = new JPasswordField();
        form.add(passField);

        dialog.add(form, BorderLayout.CENTER);

        JPanel btnPanel = new FlowLayout(FlowLayout.RIGHT, 8, 12);
        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton saveBtn = new JButton("Create User");
        saveBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        saveBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            UserRole role = (UserRole) roleCombo.getSelectedItem();
            char[] pass = passField.getPassword();

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter a display name.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!PasswordSecurityUtil.isValidEmail(email)) {
                JOptionPane.showMessageDialog(dialog, "Please enter a valid email address.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            PasswordSecurityUtil.ValidationResult passRes = PasswordSecurityUtil.validatePasswordRequirements(pass);
            if (!passRes.isValid()) {
                JOptionPane.showMessageDialog(dialog, passRes.getMessage(), "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                authService.createUser(email, name, pass, role);
                JOptionPane.showMessageDialog(dialog, "User account created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
                refreshUserList();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Failed to create user: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnPanel.add(cancelBtn);
        btnPanel.add(saveBtn);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private void handleResetPassword() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a user to reset their password.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String email = (String) tableModel.getValueAt(selectedRow, 1);
        List<User> users = authService.getAllUsers();
        User target = users.stream().filter(u -> u.getEmail().equalsIgnoreCase(email)).findFirst().orElse(null);
        if (target == null) return;

        JPasswordField newPassField = new JPasswordField();
        int opt = JOptionPane.showConfirmDialog(this, new Object[]{
                "Enter new password for " + target.getEmail() + " (min 6 characters):",
                newPassField
        }, "Reset User Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (opt == JOptionPane.OK_OPTION) {
            char[] newPass = newPassField.getPassword();
            PasswordSecurityUtil.ValidationResult res = PasswordSecurityUtil.validatePasswordRequirements(newPass);
            if (!res.isValid()) {
                JOptionPane.showMessageDialog(this, res.getMessage(), "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                authService.resetUserPassword(target.getId(), newPass);
                JOptionPane.showMessageDialog(this, "Password updated successfully for " + target.getEmail(), "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating password: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleDeleteUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String email = (String) tableModel.getValueAt(selectedRow, 1);
        List<User> users = authService.getAllUsers();
        User target = users.stream().filter(u -> u.getEmail().equalsIgnoreCase(email)).findFirst().orElse(null);
        if (target == null) return;

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete user account:\n" +
                        target.getDisplayName() + " (" + target.getEmail() + ")?\n\n" +
                        "This will revoke all active sessions for this account.",
                "Confirm Account Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                authService.deleteUser(target.getId());
                refreshUserList();
                JOptionPane.showMessageDialog(this, "User deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Deletion Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
