package com.example.meetmanager.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Pattern;

/**
 * Validates and sanitizes Google Meet URLs.
 * Enforces strict security constraints:
 * - Scheme must be HTTPS
 * - Host must be exactly "meet.google.com"
 * - Disallows unsafe schemes, shell arguments, or command execution characters.
 */
public class UrlValidationService {

    private static final String ALLOWED_HOST = "meet.google.com";
    private static final String HTTPS_SCHEME = "https";

    // Standard Google Meet code pattern: 3 letters, hyphen, 4 letters, hyphen, 3 letters
    // Example: abc-defg-hij
    private static final Pattern STANDARD_MEET_CODE_PATTERN = Pattern.compile("^[a-z]{3}-[a-z]{4}-[a-z]{3}$", Pattern.CASE_INSENSITIVE);

    // General valid path pattern for meet.google.com (including lookup, new, or alpha-numeric codes)
    private static final Pattern VALID_PATH_PATTERN = Pattern.compile("^/[a-zA-Z0-9_-]+(/[a-zA-Z0-9_.-]+)*$");

    public static class ValidationResult {
        private final boolean valid;
        private final String message;
        private final String normalizedUrl;
        private final String meetingCode;

        private ValidationResult(boolean valid, String message, String normalizedUrl, String meetingCode) {
            this.valid = valid;
            this.message = message;
            this.normalizedUrl = normalizedUrl;
            this.meetingCode = meetingCode;
        }

        public static ValidationResult success(String normalizedUrl, String meetingCode) {
            return new ValidationResult(true, "Valid Google Meet URL", normalizedUrl, meetingCode);
        }

        public static ValidationResult failure(String message) {
            return new ValidationResult(false, message, null, null);
        }

        public boolean isValid() {
            return valid;
        }

        public String getMessage() {
            return message;
        }

        public String getNormalizedUrl() {
            return normalizedUrl;
        }

        public String getMeetingCode() {
            return meetingCode;
        }
    }

    /**
     * Validates a candidate Google Meet URL.
     *
     * @param rawInput Raw URL or meeting code entered by user
     * @return ValidationResult indicating success or specific failure reason
     */
    public ValidationResult validate(String rawInput) {
        if (rawInput == null || rawInput.trim().isEmpty()) {
            return ValidationResult.failure("Meeting URL cannot be empty.");
        }

        String input = rawInput.trim();

        // Convenience support: if user entered raw code like "abc-defg-hij", prepend https://meet.google.com/
        if (STANDARD_MEET_CODE_PATTERN.matcher(input).matches()) {
            input = "https://" + ALLOWED_HOST + "/" + input.toLowerCase();
        }

        // Check for disallowed characters (spaces, control characters, shell special chars)
        if (input.contains(" ") || input.contains("\"") || input.contains("'") || input.contains("<") || input.contains(">") || input.contains("`")) {
            return ValidationResult.failure("URL contains invalid or unsafe characters.");
        }

        URI uri;
        try {
            uri = new URI(input);
        } catch (URISyntaxException e) {
            return ValidationResult.failure("Malformed URL: " + e.getReason());
        }

        // 1. Verify scheme
        String scheme = uri.getScheme();
        if (scheme == null) {
            return ValidationResult.failure("Missing URL protocol. Must start with https://");
        }
        if (!HTTPS_SCHEME.equalsIgnoreCase(scheme)) {
            if ("http".equalsIgnoreCase(scheme)) {
                return ValidationResult.failure("Insecure HTTP protocol is not permitted. Only secure HTTPS (https://meet.google.com/...) is accepted.");
            }
            return ValidationResult.failure("Invalid protocol: '" + scheme + "'. Only https:// is allowed.");
        }

        // 2. Verify Host
        String host = uri.getHost();
        if (host == null || host.isEmpty()) {
            return ValidationResult.failure("Invalid URL host. Must be meet.google.com");
        }
        if (!ALLOWED_HOST.equalsIgnoreCase(host)) {
            return ValidationResult.failure("Unrelated host '" + host + "'. This manager only supports Google Meet links (meet.google.com).");
        }

        // 3. Verify Path
        String path = uri.getPath();
        if (path == null || path.trim().isEmpty() || "/".equals(path.trim())) {
            return ValidationResult.failure("URL is missing a meeting code. Expected format: https://meet.google.com/xxx-yyyy-zzz");
        }

        // Check path structure
        if (!VALID_PATH_PATTERN.matcher(path).matches()) {
            return ValidationResult.failure("Invalid meeting path format in URL: " + path);
        }

        // Extract meeting code (without leading slash)
        String meetingCode = path.startsWith("/") ? path.substring(1) : path;

        // Build canonical normalized URL
        String normalizedUrl = "https://" + ALLOWED_HOST + "/" + meetingCode;
        if (uri.getQuery() != null && !uri.getQuery().isEmpty()) {
            // Keep query if present (e.g. authuser=0), but strip any hash or dangerous components
            normalizedUrl += "?" + uri.getQuery();
        }

        return ValidationResult.success(normalizedUrl, meetingCode);
    }

    /**
     * Quick boolean check.
     */
    public boolean isValid(String url) {
        return validate(url).isValid();
    }
}
