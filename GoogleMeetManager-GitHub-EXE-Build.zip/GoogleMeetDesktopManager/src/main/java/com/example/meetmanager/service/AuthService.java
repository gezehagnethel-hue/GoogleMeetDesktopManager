package com.example.meetmanager.service;

import com.example.meetmanager.model.User;
import com.example.meetmanager.model.UserRole;
import com.example.meetmanager.util.PasswordSecurityUtil;

import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Authentication and authorization service managing user sign-in, PBKDF2 verification,
 * secure session tokens, Remember-Me persistence, role checks, and user administration.
 */
public class AuthService {

    private static final Logger LOGGER = Logger.getLogger(AuthService.class.getName());

    public interface AuthListener {
        void onAuthStateChanged(User currentUser);
    }

    public static class AuthResult {
        private final boolean success;
        private final String errorMessage;
        private final User user;

        private AuthResult(boolean success, String errorMessage, User user) {
            this.success = success;
            this.errorMessage = errorMessage;
            this.user = user;
        }

        public static AuthResult success(User user) {
            return new AuthResult(true, null, user);
        }

        public static AuthResult failure(String errorMessage) {
            return new AuthResult(false, errorMessage, null);
        }

        public boolean isSuccess() {
            return success;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public User getUser() {
            return user;
        }
    }

    private final MeetingStorageService storageService;
    private final List<AuthListener> listeners = new CopyOnWriteArrayList<>();
    private User currentUser;
    private String currentSessionToken;

    public AuthService(MeetingStorageService storageService) {
        this.storageService = Objects.requireNonNull(storageService, "StorageService cannot be null");
    }

    public AuthService() {
        this(new MeetingStorageService());
    }

    public void addAuthListener(AuthListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeAuthListener(AuthListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners() {
        for (AuthListener listener : listeners) {
            try {
                listener.onAuthStateChanged(currentUser);
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Error in AuthListener notification", ex);
            }
        }
    }

    /**
     * Authenticates a user by email and password using salted PBKDF2-HMAC-SHA256 verification.
     * Never stores or compares plaintext passwords.
     */
    public synchronized AuthResult login(String email, char[] password, boolean rememberMe) {
        if (email == null || email.trim().isEmpty()) {
            return AuthResult.failure("Please enter your email address.");
        }
        if (!PasswordSecurityUtil.isValidEmail(email)) {
            return AuthResult.failure("Please enter a valid email address (e.g. name@company.com).");
        }
        if (password == null || password.length == 0) {
            return AuthResult.failure("Please enter your password.");
        }

        String normalizedEmail = email.trim().toLowerCase();
        Optional<User> userOpt = storageService.findUserByEmail(normalizedEmail);

        if (userOpt.isEmpty()) {
            LOGGER.warning("Authentication failed: User not found for email " + normalizedEmail);
            return AuthResult.failure("Invalid email or password. Please verify your credentials.");
        }

        User user = userOpt.get();
        boolean valid = PasswordSecurityUtil.verifyPassword(password, user.getPasswordHash(), user.getSalt());

        // Zero out password in memory
        Arrays.fill(password, '\0');

        if (!valid) {
            LOGGER.warning("Authentication failed: Incorrect password for user " + normalizedEmail);
            return AuthResult.failure("Invalid email or password. Please verify your credentials.");
        }

        // Authentication succeeded
        long now = System.currentTimeMillis();
        user.setLastLoginAt(now);
        storageService.updateUserLastLogin(user.getId(), now);

        String sessionToken = UUID.randomUUID().toString();
        long expirationDuration = rememberMe ? (30L * 24L * 60L * 60L * 1000L) : (12L * 60L * 60L * 1000L);
        long expiresAt = now + expirationDuration;

        storageService.saveAuthSession(sessionToken, user.getId(), now, expiresAt, rememberMe);

        if (rememberMe) {
            storageService.saveRememberedSessionToken(sessionToken);
        } else {
            storageService.clearRememberedSessionToken();
        }

        this.currentUser = user;
        this.currentSessionToken = sessionToken;

        LOGGER.info("User logged in successfully: " + user.getEmail() + " [Role: " + user.getRole() + "]");
        notifyListeners();

        return AuthResult.success(user);
    }

    /**
     * Attempts to automatically restore a previous valid Remember-Me session on application startup.
     */
    public synchronized boolean restoreRememberedSession() {
        String rememberedToken = storageService.getRememberedSessionToken();
        if (rememberedToken == null || rememberedToken.trim().isEmpty()) {
            return false;
        }

        Optional<User> userOpt = storageService.findUserBySessionToken(rememberedToken.trim());
        if (userOpt.isPresent()) {
            this.currentUser = userOpt.get();
            this.currentSessionToken = rememberedToken.trim();
            this.currentUser.setLastLoginAt(System.currentTimeMillis());
            storageService.updateUserLastLogin(this.currentUser.getId(), this.currentUser.getLastLoginAt());
            LOGGER.info("Restored remembered session for user: " + currentUser.getEmail());
            notifyListeners();
            return true;
        } else {
            // Token was invalid or expired
            storageService.clearRememberedSessionToken();
            return false;
        }
    }

    /**
     * Terminates the current session, deletes the session token, and signs the user out.
     */
    public synchronized void logout() {
        if (currentSessionToken != null) {
            storageService.deleteAuthSession(currentSessionToken);
            currentSessionToken = null;
        }
        storageService.clearRememberedSessionToken();
        User previousUser = currentUser;
        currentUser = null;

        if (previousUser != null) {
            LOGGER.info("User logged out: " + previousUser.getEmail());
        }
        notifyListeners();
    }

    public synchronized User getCurrentUser() {
        return currentUser;
    }

    public synchronized boolean isAuthenticated() {
        return currentUser != null;
    }

    public synchronized boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }

    public synchronized boolean isClient() {
        return currentUser != null && currentUser.isClient();
    }

    // =========================================================================
    // User Management (Admin Only)
    // =========================================================================

    public synchronized List<User> getAllUsers() {
        return storageService.getAllUsers();
    }

    public synchronized User createUser(String email, String displayName, char[] password, UserRole role) throws SQLException {
        if (currentUser == null || !currentUser.isAdmin()) {
            throw new SecurityException("Unauthorized: Only administrators can create new users.");
        }
        if (email == null || !PasswordSecurityUtil.isValidEmail(email)) {
            throw new IllegalArgumentException("Invalid email address format.");
        }
        PasswordSecurityUtil.ValidationResult passRes = PasswordSecurityUtil.validatePasswordRequirements(password);
        if (!passRes.isValid()) {
            throw new IllegalArgumentException(passRes.getMessage());
        }

        String normalizedEmail = email.trim().toLowerCase();
        if (storageService.findUserByEmail(normalizedEmail).isPresent()) {
            throw new IllegalArgumentException("A user with this email address already exists.");
        }

        String salt = PasswordSecurityUtil.generateSalt();
        String hash = PasswordSecurityUtil.hashPassword(password, salt);
        Arrays.fill(password, '\0');

        User newUser = new User(
                UUID.randomUUID().toString(),
                normalizedEmail,
                displayName != null && !displayName.trim().isEmpty() ? displayName.trim() : normalizedEmail,
                role != null ? role : UserRole.CLIENT,
                hash,
                salt,
                System.currentTimeMillis(),
                0L
        );

        storageService.saveUser(newUser);
        LOGGER.info("Administrator created user: " + newUser.getEmail() + " [Role: " + newUser.getRole() + "]");
        return newUser;
    }

    public synchronized void deleteUser(String userId) throws SQLException {
        if (currentUser == null || !currentUser.isAdmin()) {
            throw new SecurityException("Unauthorized: Only administrators can delete users.");
        }
        if (userId == null) return;

        Optional<User> targetOpt = storageService.findUserById(userId);
        if (targetOpt.isEmpty()) {
            throw new IllegalArgumentException("User not found.");
        }

        User target = targetOpt.get();
        if (target.getId().equals(currentUser.getId())) {
            throw new IllegalArgumentException("Administrators cannot delete their own active account.");
        }

        // Ensure at least one administrator remains
        if (target.isAdmin()) {
            long adminCount = storageService.getAllUsers().stream().filter(User::isAdmin).count();
            if (adminCount <= 1) {
                throw new IllegalStateException("Cannot delete the last remaining administrator account.");
            }
        }

        storageService.deleteUserSessions(userId);
        storageService.deleteUser(userId);
        LOGGER.info("Deleted user: " + target.getEmail());
    }

    public synchronized void resetUserPassword(String userId, char[] newPassword) throws SQLException {
        if (currentUser == null || !currentUser.isAdmin()) {
            throw new SecurityException("Unauthorized: Only administrators can reset passwords.");
        }
        PasswordSecurityUtil.ValidationResult passRes = PasswordSecurityUtil.validatePasswordRequirements(newPassword);
        if (!passRes.isValid()) {
            throw new IllegalArgumentException(passRes.getMessage());
        }

        String newSalt = PasswordSecurityUtil.generateSalt();
        String newHash = PasswordSecurityUtil.hashPassword(newPassword, newSalt);
        Arrays.fill(newPassword, '\0');

        storageService.updateUserPassword(userId, newHash, newSalt);
        storageService.deleteUserSessions(userId);
        LOGGER.info("Password reset successfully for user ID: " + userId);
    }

    public MeetingStorageService getStorageService() {
        return storageService;
    }
}
