package com.example.meetmanager.ui;

import com.example.meetmanager.audio.RecordingMode;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Modal dialog enforcing mandatory consent confirmation before any audio recording can begin.
 * Explains legal obligations, two-party consent laws, and participant notification rules.
 */
public class RecordingConsentDialog extends JDialog {

    private boolean consentConfirmed = false;
    private final JCheckBox consentCheckbox;
    private final JButton startButton;

    public RecordingConsentDialog(Frame owner, String meetingTitle, RecordingMode mode) {
        super(owner, "Audio Recording Consent Confirmation", true);
        setSize(540, 480);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());
        setResizable(false);

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(15, 23, 42)); // Slate 900
        headerPanel.setBorder(new EmptyBorder(16, 20, 16, 20));

        JLabel titleLabel = new JLabel("Audio Recording Authorization & Consent");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("Mandatory participant notice and legal authorization check");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(148, 163, 184)); // Slate 400

        headerPanel.add(titleLabel, BorderLayout.NORTH);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);
        add(headerPanel, BorderLayout.NORTH);

        // Content Panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(18, 20, 18, 20));
        contentPanel.setBackground(Color.WHITE);

        // Meeting context
        JLabel meetingInfoLabel = new JLabel("Target Meeting: " + (meetingTitle != null ? meetingTitle : "Ad-hoc Meeting"));
        meetingInfoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        meetingInfoLabel.setForeground(new Color(30, 41, 59));
        meetingInfoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.add(meetingInfoLabel);

        contentPanel.add(Box.createVerticalStrut(6));

        // Mode badge
        JLabel modeLabel = new JLabel("Detection Mode: " + mode.getLabel());
        modeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        modeLabel.setForeground(mode.isTwoSided() ? new Color(16, 185, 129) : new Color(217, 119, 6));
        modeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.add(modeLabel);

        contentPanel.add(Box.createVerticalStrut(14));

        // Notice text
        JTextArea noticeArea = new JTextArea();
        noticeArea.setEditable(false);
        noticeArea.setWrapStyleWord(true);
        noticeArea.setLineWrap(true);
        noticeArea.setOpaque(false);
        noticeArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        noticeArea.setForeground(new Color(51, 65, 85));
        noticeArea.setText(
                "Before initiating this local audio recording, please review the following legal requirements:\n\n" +
                "1. Participant Notification: Most jurisdictions (including two-party consent states in the US and GDPR member states in the EU) require informing all meeting participants before recording audio.\n\n" +
                "2. Host Authorization: Local recording must only be conducted by authorized meeting hosts, administrators, or designated note-takers with explicit organizational permission.\n\n" +
                "3. No Secret Recording: This tool must never be used to secretly capture private conversations. A visible recording indicator will remain active throughout the session.\n\n" +
                "4. Preferred Cloud Alternative: If your Google Workspace account supports it, please use Google Meet's built-in cloud recording (Activities > Recording), which automatically alerts all participants on screen."
        );
        noticeArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.add(noticeArea);

        contentPanel.add(Box.createVerticalStrut(14));

        // Mandatory Agreement Checkbox
        consentCheckbox = new JCheckBox("<html><b>I confirm that I am an authorized meeting host or have explicit permission from all participants to record this meeting audio in accordance with applicable laws.</b></html>");
        consentCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        consentCheckbox.setForeground(new Color(15, 23, 42));
        consentCheckbox.setOpaque(false);
        consentCheckbox.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.add(consentCheckbox);

        add(contentPanel, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        buttonPanel.setBackground(new Color(248, 250, 252));
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> {
            consentConfirmed = false;
            dispose();
        });

        startButton = new JButton("I Agree & Start Recording");
        startButton.setEnabled(false);
        startButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        startButton.setBackground(new Color(220, 38, 38)); // Vibrant Red
        startButton.setForeground(Color.WHITE);
        startButton.addActionListener(e -> {
            if (consentCheckbox.isSelected()) {
                consentConfirmed = true;
                dispose();
            }
        });

        consentCheckbox.addActionListener(e -> startButton.setEnabled(consentCheckbox.isSelected()));

        buttonPanel.add(cancelButton);
        buttonPanel.add(startButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public boolean isConsentConfirmed() {
        return consentConfirmed;
    }
}
