package com.example.meetmanager.ui;

import com.example.meetmanager.audio.*;
import com.example.meetmanager.service.MeetingStorageService;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.SQLException;
import java.util.List;

/**
 * Modern Swing recording dashboard for authorized meeting hosts and administrators.
 * Provides controls, real-time timer, dual-stream loopback status, consent enforcement,
 * and local WAV file management.
 */
public class RecordingPanel extends JPanel implements AudioRecordingService.RecordingListener {

    private final Frame parentFrame;
    private final AudioRecordingService recordingService;
    private final MeetingStorageService storageService;

    // UI Elements
    private JLabel statusBadgeLabel;
    private JLabel statusMessageLabel;
    private JLabel timerLabel;
    private JProgressBar micProgressBar;
    private JProgressBar sysProgressBar;
    private JLabel streamStatusLabel;
    private JLabel outputLocationLabel;

    private JButton startBtn;
    private JButton pauseBtn;
    private JButton resumeBtn;
    private JButton stopBtn;
    private JButton openFolderBtn;

    private JTable recordingsTable;
    private DefaultTableModel tableModel;

    public RecordingPanel(Frame parentFrame, MeetingStorageService storageService) {
        this.parentFrame = parentFrame;
        this.storageService = storageService;
        this.recordingService = new AudioRecordingService();
        this.recordingService.addListener(this);

        setLayout(new BorderLayout(0, 16));
        setBackground(new Color(248, 250, 252));
        setBorder(new EmptyBorder(16, 16, 16, 16));

        initUI();
        refreshDeviceStatus();
        loadPastRecordings();
    }

    private void initUI() {
        // Top Section: Live Recording Console & Status
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);

        // Header Card (Console)
        JPanel consoleCard = new JPanel(new BorderLayout(16, 12));
        consoleCard.setBackground(new Color(15, 23, 42)); // Slate 900
        consoleCard.setBorder(new CompoundBorder(
                new LineBorder(new Color(51, 65, 85), 1, true),
                new EmptyBorder(18, 20, 18, 20)
        ));

        // Console Top Row: Status badge & Directory path
        JPanel statusRow = new JPanel(new BorderLayout());
        statusRow.setOpaque(false);

        JPanel badgeWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        badgeWrapper.setOpaque(false);

        statusBadgeLabel = new JLabel("● IDLE");
        statusBadgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statusBadgeLabel.setForeground(new Color(148, 163, 184));
        statusBadgeLabel.setBorder(new CompoundBorder(
                new LineBorder(new Color(71, 85, 105), 1, true),
                new EmptyBorder(3, 8, 3, 8)
        ));

        statusMessageLabel = new JLabel(" Ready to record authorized audio");
        statusMessageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusMessageLabel.setForeground(new Color(203, 213, 225));

        badgeWrapper.add(statusBadgeLabel);
        badgeWrapper.add(Box.createHorizontalStrut(10));
        badgeWrapper.add(statusMessageLabel);

        outputLocationLabel = new JLabel("Output: " + recordingService.getRecordingsDirectory().getAbsolutePath());
        outputLocationLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        outputLocationLabel.setForeground(new Color(148, 163, 184));

        statusRow.add(badgeWrapper, BorderLayout.WEST);
        statusRow.add(outputLocationLabel, BorderLayout.EAST);
        consoleCard.add(statusRow, BorderLayout.NORTH);

        // Console Center: Big Timer & Volume Meters
        JPanel centerConsole = new JPanel(new GridBagLayout());
        centerConsole.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();

        timerLabel = new JLabel("00:00:00");
        timerLabel.setFont(new Font("Consolas", Font.BOLD, 36));
        timerLabel.setForeground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        centerConsole.add(timerLabel, gbc);

        // Volume Level Meters
        JPanel metersPanel = new JPanel(new GridLayout(2, 2, 8, 4));
        metersPanel.setOpaque(false);
        metersPanel.setBorder(new EmptyBorder(0, 30, 0, 0));

        JLabel micLabel = new JLabel("Microphone:");
        micLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        micLabel.setForeground(new Color(148, 163, 184));

        micProgressBar = new JProgressBar(0, 100);
        micProgressBar.setValue(0);
        micProgressBar.setPreferredSize(new Dimension(140, 10));
        micProgressBar.setForeground(new Color(37, 99, 235));

        JLabel sysLabel = new JLabel("System Audio:");
        sysLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sysLabel.setForeground(new Color(148, 163, 184));

        sysProgressBar = new JProgressBar(0, 100);
        sysProgressBar.setValue(0);
        sysProgressBar.setPreferredSize(new Dimension(140, 10));
        sysProgressBar.setForeground(new Color(16, 185, 129));

        metersPanel.add(micLabel);
        metersPanel.add(micProgressBar);
        metersPanel.add(sysLabel);
        metersPanel.add(sysProgressBar);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        centerConsole.add(metersPanel, gbc);

        consoleCard.add(centerConsole, BorderLayout.CENTER);

        // Console Bottom: Action Buttons
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionsPanel.setOpaque(false);

        startBtn = new JButton("🔴 Start Recording...");
        startBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        startBtn.setBackground(new Color(220, 38, 38));
        startBtn.setForeground(Color.WHITE);
        startBtn.addActionListener(e -> handleStartRecording());

        pauseBtn = new JButton("⏸ Pause");
        pauseBtn.setEnabled(false);
        pauseBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        pauseBtn.addActionListener(e -> recordingService.pauseRecording());

        resumeBtn = new JButton("▶ Resume");
        resumeBtn.setEnabled(false);
        resumeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        resumeBtn.addActionListener(e -> recordingService.resumeRecording());

        stopBtn = new JButton("⏹ Stop & Save");
        stopBtn.setEnabled(false);
        stopBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        stopBtn.setBackground(new Color(71, 85, 105));
        stopBtn.setForeground(Color.WHITE);
        stopBtn.addActionListener(e -> handleStopRecording());

        openFolderBtn = new JButton("📁 Open Folder");
        openFolderBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        openFolderBtn.addActionListener(e -> openRecordingsFolder());

        actionsPanel.add(startBtn);
        actionsPanel.add(pauseBtn);
        actionsPanel.add(resumeBtn);
        actionsPanel.add(stopBtn);
        actionsPanel.add(openFolderBtn);

        consoleCard.add(actionsPanel, BorderLayout.SOUTH);
        topPanel.add(consoleCard);

        topPanel.add(Box.createVerticalStrut(10));

        // Detection & Limitation Card
        JPanel infoCard = new JPanel(new BorderLayout(10, 6));
        infoCard.setBackground(Color.WHITE);
        infoCard.setBorder(new CompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1, true),
                new EmptyBorder(12, 16, 12, 16)
        ));

        streamStatusLabel = new JLabel("Scanning audio devices...");
        streamStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JLabel recommendationLabel = new JLabel(
                "<html><b>Preferred Method:</b> For full meeting recordings with participant video, remote voices, and Google Drive auto-sync, use Google Meet's built-in cloud recording (<i>Activities &gt; Recording</i>) for authorized Workspace hosts. Local audio recording is designed for authorized host note-taking.</html>"
        );
        recommendationLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        recommendationLabel.setForeground(new Color(100, 116, 139));

        infoCard.add(streamStatusLabel, BorderLayout.NORTH);
        infoCard.add(recommendationLabel, BorderLayout.SOUTH);
        topPanel.add(infoCard);

        add(topPanel, BorderLayout.NORTH);

        // Center / Bottom: Past Recordings Table
        JPanel tableSection = new JPanel(new BorderLayout(0, 8));
        tableSection.setOpaque(false);

        JPanel tableHeader = new JPanel(new BorderLayout());
        tableHeader.setOpaque(false);
        JLabel tableTitle = new JLabel("Saved Audio Recordings (Local Storage)");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tableTitle.setForeground(new Color(30, 41, 59));
        tableHeader.add(tableTitle, BorderLayout.WEST);

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        refreshBtn.addActionListener(e -> loadPastRecordings());
        tableHeader.add(refreshBtn, BorderLayout.EAST);

        tableSection.add(tableHeader, BorderLayout.NORTH);

        String[] columnNames = {"Date / Time", "Meeting Title", "Duration", "File Size", "Recording Mode", "Filename"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        recordingsTable = new JTable(tableModel);
        recordingsTable.setRowHeight(24);
        recordingsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        recordingsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(recordingsTable);
        scrollPane.setBorder(new LineBorder(new Color(226, 232, 240), 1, true));
        tableSection.add(scrollPane, BorderLayout.CENTER);

        // Table Action Buttons
        JPanel tableActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        tableActions.setOpaque(false);

        JButton playBtn = new JButton("Play in Default Player");
        playBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        playBtn.addActionListener(e -> handlePlaySelected());

        JButton deleteBtn = new JButton("Delete Recording");
        deleteBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        deleteBtn.setForeground(new Color(220, 38, 38));
        deleteBtn.addActionListener(e -> handleDeleteSelected());

        tableActions.add(playBtn);
        tableActions.add(deleteBtn);
        tableSection.add(tableActions, BorderLayout.SOUTH);

        add(tableSection, BorderLayout.CENTER);
    }

    private void refreshDeviceStatus() {
        boolean loopback = recordingService.getDeviceManager().isSystemLoopbackAvailable();
        if (loopback) {
            streamStatusLabel.setText("✔ Dual-Stream Audio Active: Microphone + Windows System Loopback detected");
            streamStatusLabel.setForeground(new Color(16, 185, 129));
        } else {
            streamStatusLabel.setText("⚠ Single-Stream (Microphone Only): System Loopback not detected. Remote voices will NOT be captured.");
            streamStatusLabel.setForeground(new Color(217, 119, 6));
        }
    }

    private void handleStartRecording() {
        String meetingTitle = JOptionPane.showInputDialog(
                parentFrame,
                "Enter meeting title or purpose for this recording:",
                "Meeting Title",
                JOptionPane.PLAIN_MESSAGE
        );
        if (meetingTitle == null) return; // user cancelled

        boolean loopback = recordingService.getDeviceManager().isSystemLoopbackAvailable();
        RecordingMode mode = loopback ? RecordingMode.DUAL_STREAM_MIXED : RecordingMode.MIC_ONLY;

        RecordingConsentDialog consentDialog = new RecordingConsentDialog(parentFrame, meetingTitle, mode);
        consentDialog.setVisible(true);

        if (!consentDialog.isConsentConfirmed()) {
            return;
        }

        try {
            recordingService.startRecording(meetingTitle, true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    parentFrame,
                    "Could not start audio recording: " + ex.getMessage(),
                    "Recording Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void handleStopRecording() {
        RecordingSession session = recordingService.stopRecording();
        if (session != null) {
            try {
                storageService.saveRecordingSession(session);
            } catch (SQLException ex) {
                // Log and ignore
            }
            loadPastRecordings();
            JOptionPane.showMessageDialog(
                    parentFrame,
                    "Recording saved successfully:\n" + session.getFilename() + "\n(" + session.getFormattedSize() + ")",
                    "Recording Saved",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void handlePlaySelected() {
        int row = recordingsTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(parentFrame, "Select a recording row to play.", "Notice", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String filename = (String) tableModel.getValueAt(row, 5);
        File file = new File(recordingService.getRecordingsDirectory(), filename);
        if (file.exists() && Desktop.isDesktopSupported()) {
            try {
                Desktop.getDesktop().open(file);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parentFrame, "Could not open media player: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleDeleteSelected() {
        int row = recordingsTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(parentFrame, "Select a recording row to delete.", "Notice", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String filename = (String) tableModel.getValueAt(row, 5);
        int confirm = JOptionPane.showConfirmDialog(
                parentFrame,
                "Are you sure you want to permanently delete \"" + filename + "\" from disk?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (confirm == JOptionPane.YES_OPTION) {
            File file = new File(recordingService.getRecordingsDirectory(), filename);
            if (file.exists()) {
                file.delete();
            }
            // Also delete from sqlite
            List<RecordingSession> list = storageService.loadRecordingSessions();
            for (RecordingSession s : list) {
                if (s.getFilename().equals(filename)) {
                    try {
                        storageService.deleteRecordingSession(s.getId());
                    } catch (SQLException ignored) {
                    }
                    break;
                }
            }
            loadPastRecordings();
        }
    }

    private void openRecordingsFolder() {
        File dir = recordingService.getRecordingsDirectory();
        if (Desktop.isDesktopSupported() && dir.exists()) {
            try {
                Desktop.getDesktop().open(dir);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parentFrame, "Could not open folder: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadPastRecordings() {
        tableModel.setRowCount(0);
        List<RecordingSession> sessions = storageService.loadRecordingSessions();
        for (RecordingSession s : sessions) {
            tableModel.addRow(new Object[]{
                    new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date(s.getStartTime())),
                    s.getMeetingTitle(),
                    s.getFormattedDuration(),
                    s.getFormattedSize(),
                    s.getMode().isTwoSided() ? "Dual-Stream (Mixed)" : "Mic Only (1-Sided)",
                    s.getFilename()
            });
        }
    }

    // AudioRecordingService.RecordingListener callbacks
    @Override
    public void onStateChanged(AudioRecordingState state, String message) {
        SwingUtilities.invokeLater(() -> {
            statusMessageLabel.setText(" " + message);
            switch (state) {
                case RECORDING:
                    statusBadgeLabel.setText("● RECORDING");
                    statusBadgeLabel.setForeground(new Color(239, 68, 68)); // Red
                    startBtn.setEnabled(false);
                    pauseBtn.setEnabled(true);
                    resumeBtn.setEnabled(false);
                    stopBtn.setEnabled(true);
                    break;
                case PAUSED:
                    statusBadgeLabel.setText("❚❚ PAUSED");
                    statusBadgeLabel.setForeground(new Color(245, 158, 11)); // Amber
                    startBtn.setEnabled(false);
                    pauseBtn.setEnabled(false);
                    resumeBtn.setEnabled(true);
                    stopBtn.setEnabled(true);
                    break;
                case FINALIZING:
                    statusBadgeLabel.setText("● SAVING...");
                    statusBadgeLabel.setForeground(new Color(59, 130, 246));
                    startBtn.setEnabled(false);
                    pauseBtn.setEnabled(false);
                    resumeBtn.setEnabled(false);
                    stopBtn.setEnabled(false);
                    break;
                case IDLE:
                case STOPPED:
                default:
                    statusBadgeLabel.setText("● IDLE");
                    statusBadgeLabel.setForeground(new Color(148, 163, 184));
                    timerLabel.setText("00:00:00");
                    micProgressBar.setValue(0);
                    sysProgressBar.setValue(0);
                    startBtn.setEnabled(true);
                    pauseBtn.setEnabled(false);
                    resumeBtn.setEnabled(false);
                    stopBtn.setEnabled(false);
                    break;
            }
        });
    }

    @Override
    public void onTimeUpdate(long elapsedMs, String formattedTime) {
        SwingUtilities.invokeLater(() -> timerLabel.setText(formattedTime));
    }

    @Override
    public void onPeakLevels(float micLevel, float sysLevel) {
        SwingUtilities.invokeLater(() -> {
            micProgressBar.setValue((int) (micLevel * 100));
            sysProgressBar.setValue((int) (sysLevel * 100));
        });
    }

    @Override
    public void onError(String errorMessage) {
        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(parentFrame, errorMessage, "Recording Error", JOptionPane.ERROR_MESSAGE);
        });
    }
}
