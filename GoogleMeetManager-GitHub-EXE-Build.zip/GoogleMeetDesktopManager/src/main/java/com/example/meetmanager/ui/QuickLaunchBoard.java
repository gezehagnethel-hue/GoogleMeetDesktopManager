package com.example.meetmanager.ui;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.util.BrowserUtil;
import com.example.meetmanager.util.ClipboardUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

/**
 * A dedicated single-screen Multi-Button Launchpad interface ("1 interface, multi button").
 * Displays permanent meeting buttons with color coding, favorites, duplicate, and 1-click launch.
 */
public class QuickLaunchBoard extends JPanel {

    private final Consumer<Meeting> onJoin;
    private final Consumer<Meeting> onEdit;
    private final Consumer<Meeting> onDelete;
    private final Consumer<Meeting> onDuplicate;
    private final Consumer<Meeting> onToggleFavorite;

    private static final Color[] TILE_COLORS = {
            new Color(26, 115, 232),  // Google Blue
            new Color(15, 157, 88),   // Emerald Green
            new Color(142, 36, 170),  // Purple
            new Color(230, 81, 0),    // Warm Amber
            new Color(0, 151, 167),   // Teal Cyan
            new Color(216, 27, 96),   // Rose Red
            new Color(69, 90, 100)    // Slate
    };

    public QuickLaunchBoard(Consumer<Meeting> onJoin,
                            Consumer<Meeting> onEdit,
                            Consumer<Meeting> onDelete,
                            Consumer<Meeting> onDuplicate,
                            Consumer<Meeting> onToggleFavorite) {
        this.onJoin = onJoin;
        this.onEdit = onEdit;
        this.onDelete = onDelete;
        this.onDuplicate = onDuplicate;
        this.onToggleFavorite = onToggleFavorite;

        setLayout(new BorderLayout());
        setOpaque(false);
    }

    public void renderButtons(List<Meeting> meetings) {
        removeAll();

        if (meetings == null || meetings.isEmpty()) {
            JPanel emptyPanel = new JPanel();
            emptyPanel.setLayout(new BoxLayout(emptyPanel, BoxLayout.Y_AXIS));
            emptyPanel.setOpaque(false);
            emptyPanel.setBorder(new EmptyBorder(60, 20, 60, 20));

            JLabel icon = new JLabel("🎛️", SwingConstants.CENTER);
            icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 44));
            icon.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel title = new JLabel("No Meeting Buttons Configured", SwingConstants.CENTER);
            title.setFont(new Font("Segoe UI", Font.BOLD, 16));
            title.setForeground(new Color(32, 33, 36));
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            title.setBorder(new EmptyBorder(8, 0, 4, 0));

            JLabel sub = new JLabel("Click '+ Add Button' or '+ Multi-Add' to populate this launch board.", SwingConstants.CENTER);
            sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            sub.setForeground(new Color(95, 99, 104));
            sub.setAlignmentX(Component.CENTER_ALIGNMENT);

            emptyPanel.add(icon);
            emptyPanel.add(title);
            emptyPanel.add(sub);
            add(emptyPanel, BorderLayout.CENTER);
            revalidate();
            repaint();
            return;
        }

        // Responsive Multi-Button Grid (3 columns by default)
        int cols = 3;
        JPanel gridPanel = new JPanel(new GridLayout(0, cols, 14, 14));
        gridPanel.setOpaque(false);
        gridPanel.setBorder(new EmptyBorder(16, 16, 24, 16));

        int index = 0;
        for (Meeting m : meetings) {
            Color accentColor = TILE_COLORS[index % TILE_COLORS.length];
            JPanel buttonTile = createMultiButtonTile(m, accentColor, index + 1);
            gridPanel.add(buttonTile);
            index++;
        }

        JScrollPane scroll = new JScrollPane(gridPanel);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);

        add(scroll, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel createMultiButtonTile(Meeting m, Color accentColor, int slotNumber) {
        JPanel tile = new JPanel(new BorderLayout(8, 8));
        tile.setBackground(Color.WHITE);
        tile.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(m.isFavorite() ? new Color(251, 191, 36) : new Color(225, 231, 239), m.isFavorite() ? 2 : 1, true),
                new EmptyBorder(12, 14, 12, 14)
        ));

        // Tile Header: Slot badge + Favorite Star + Category
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel leftHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        leftHeader.setOpaque(false);

        JButton starBtn = new JButton(m.isFavorite() ? "★" : "☆");
        starBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        starBtn.setForeground(m.isFavorite() ? new Color(217, 119, 6) : new Color(156, 163, 175));
        starBtn.setBorder(BorderFactory.createEmptyBorder());
        starBtn.setContentAreaFilled(false);
        starBtn.setFocusPainted(false);
        starBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        starBtn.setToolTipText(m.isFavorite() ? "Favorited (Click to unpin)" : "Mark as Favorite");
        starBtn.addActionListener(e -> {
            if (onToggleFavorite != null) onToggleFavorite.accept(m);
        });
        leftHeader.add(starBtn);

        JLabel slotBadge = new JLabel("Button #" + slotNumber);
        slotBadge.setFont(new Font("Segoe UI", Font.BOLD, 10));
        slotBadge.setForeground(accentColor);
        leftHeader.add(slotBadge);
        header.add(leftHeader, BorderLayout.WEST);

        JPanel rightBadges = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        rightBadges.setOpaque(false);

        if (m.getScheduledTime() != null && !m.getScheduledTime().isEmpty()) {
            JLabel timeTag = new JLabel(m.getScheduledTime());
            timeTag.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            timeTag.setForeground(new Color(107, 114, 128));
            rightBadges.add(timeTag);
        }

        JLabel catBadge = new JLabel(m.getCategory());
        catBadge.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        catBadge.setForeground(new Color(95, 99, 104));
        rightBadges.add(catBadge);

        header.add(rightBadges, BorderLayout.EAST);
        tile.add(header, BorderLayout.NORTH);

        // Center: Meeting name & code
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);

        JLabel nameLabel = new JLabel(m.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        nameLabel.setForeground(new Color(32, 33, 36));
        center.add(nameLabel);

        JLabel codeLabel = new JLabel("meet.google.com/" + m.getDisplayMeetingCode());
        codeLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
        codeLabel.setForeground(new Color(95, 99, 104));
        codeLabel.setBorder(new EmptyBorder(2, 0, 4, 0));
        center.add(codeLabel);

        if (m.getDescription() != null && !m.getDescription().isEmpty()) {
            JLabel desc = new JLabel("<html><body style='width: 180px; color: #5f6368; font-size: 10px;'>" + escape(m.getDescription()) + "</body></html>");
            center.add(desc);
        }

        tile.add(center, BorderLayout.CENTER);

        // Footer: Big Primary Launch Button + Mini Menu
        JPanel footer = new JPanel(new BorderLayout(6, 0));
        footer.setOpaque(false);

        JButton joinBtn = new JButton("▶ Launch Meet");
        joinBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        joinBtn.setForeground(Color.WHITE);
        joinBtn.setBackground(accentColor);
        joinBtn.setFocusPainted(false);
        joinBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        joinBtn.setBorder(new EmptyBorder(8, 12, 8, 12));
        joinBtn.setToolTipText("1-Click Launch: " + m.getUrl() + " (Requires internet to join)");
        joinBtn.addActionListener(e -> {
            try {
                BrowserUtil.openUrl(m.getUrl());
                if (onJoin != null) onJoin.accept(m);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(tile, "Failed to launch meeting: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel miniActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        miniActions.setOpaque(false);

        JButton copyBtn = new JButton("Copy");
        copyBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        copyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        copyBtn.addActionListener(e -> {
            ClipboardUtil.copyToClipboard(m.getUrl());
            copyBtn.setText("Copied!");
            Timer t = new Timer(1500, evt -> copyBtn.setText("Copy"));
            t.setRepeats(false);
            t.start();
        });

        JButton menuBtn = new JButton("•••");
        menuBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        menuBtn.setToolTipText("More button actions");
        menuBtn.addActionListener(e -> {
            JPopupMenu popup = new JPopupMenu();

            JMenuItem favItem = new JMenuItem(m.isFavorite() ? "Unfavorite Button" : "Star as Favorite");
            favItem.addActionListener(ev -> {
                if (onToggleFavorite != null) onToggleFavorite.accept(m);
            });

            JMenuItem dupItem = new JMenuItem("Duplicate Button");
            dupItem.addActionListener(ev -> {
                if (onDuplicate != null) onDuplicate.accept(m);
            });

            JMenuItem editItem = new JMenuItem("Edit Button...");
            editItem.addActionListener(ev -> {
                if (onEdit != null) onEdit.accept(m);
            });

            JMenuItem deleteItem = new JMenuItem("Delete Button");
            deleteItem.setForeground(new Color(217, 48, 37));
            deleteItem.addActionListener(ev -> {
                if (onDelete != null) onDelete.accept(m);
            });

            popup.add(favItem);
            popup.add(dupItem);
            popup.add(editItem);
            popup.addSeparator();
            popup.add(deleteItem);
            popup.show(menuBtn, 0, menuBtn.getHeight());
        });

        miniActions.add(copyBtn);
        miniActions.add(menuBtn);

        footer.add(joinBtn, BorderLayout.CENTER);
        footer.add(miniActions, BorderLayout.EAST);

        tile.add(footer, BorderLayout.SOUTH);
        return tile;
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
