package com.example.meetmanager.service;

import com.example.meetmanager.model.DefaultMeetingConfig;
import com.example.meetmanager.model.Meeting;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Core business service managing meeting records, search filtering, favorites, duplication, and persistence.
 */
public class MeetingService {

    public interface MeetingChangeListener {
        void onMeetingsChanged();
    }

    private final MeetingStorageService storageService;
    private final UrlValidationService urlValidationService;
    private final List<Meeting> meetings;
    private final List<MeetingChangeListener> listeners;

    public MeetingService(MeetingStorageService storageService, UrlValidationService urlValidationService) {
        this.storageService = Objects.requireNonNull(storageService);
        this.urlValidationService = Objects.requireNonNull(urlValidationService);
        this.meetings = new ArrayList<>();
        this.listeners = new CopyOnWriteArrayList<>();
        loadInitialData();
    }

    public MeetingService() {
        this(new MeetingStorageService(), new UrlValidationService());
    }

    public void addChangeListener(MeetingChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeChangeListener(MeetingChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners() {
        for (MeetingChangeListener listener : listeners) {
            try {
                listener.onMeetingsChanged();
            } catch (Exception ignored) {
            }
        }
    }

    private void loadInitialData() {
        try {
            List<Meeting> loaded = storageService.loadMeetings();
            synchronized (meetings) {
                meetings.clear();
                meetings.addAll(loaded);
                Collections.sort(meetings);
            }
        } catch (IOException e) {
            // Keep empty list if error
        }
    }

    public synchronized List<Meeting> getAllMeetings() {
        return Collections.unmodifiableList(new ArrayList<>(meetings));
    }

    public synchronized int getMeetingCount() {
        return meetings.size();
    }

    public synchronized Set<String> getAllCategories() {
        Set<String> categories = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (Meeting m : meetings) {
            if (m.getCategory() != null && !m.getCategory().trim().isEmpty()) {
                categories.add(m.getCategory().trim());
            }
        }
        return categories;
    }

    public synchronized Optional<Meeting> findById(String id) {
        if (id == null) return Optional.empty();
        return meetings.stream().filter(m -> id.equals(m.getId())).findFirst();
    }

    public synchronized Optional<Meeting> findDuplicateByUrl(String url, String excludeId) {
        if (url == null) return Optional.empty();
        UrlValidationService.ValidationResult res = urlValidationService.validate(url);
        String targetUrl = res.isValid() ? res.getNormalizedUrl() : url.trim();

        return meetings.stream()
                .filter(m -> (excludeId == null || !m.getId().equals(excludeId)))
                .filter(m -> targetUrl.equalsIgnoreCase(m.getUrl().trim()))
                .findFirst();
    }

    public synchronized void addMeeting(Meeting meeting) throws IOException, IllegalArgumentException {
        if (meeting == null) {
            throw new IllegalArgumentException("Meeting cannot be null.");
        }
        if (meeting.getName() == null || meeting.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Meeting name is required.");
        }

        UrlValidationService.ValidationResult val = urlValidationService.validate(meeting.getUrl());
        if (!val.isValid()) {
            throw new IllegalArgumentException(val.getMessage());
        }

        meeting.setUrl(val.getNormalizedUrl());
        meetings.add(meeting);
        Collections.sort(meetings);

        storageService.saveMeetings(meetings);
        notifyListeners();
    }

    public synchronized void updateMeeting(Meeting updated) throws IOException, IllegalArgumentException {
        if (updated == null) {
            throw new IllegalArgumentException("Meeting cannot be null.");
        }
        if (updated.getName() == null || updated.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Meeting name is required.");
        }

        UrlValidationService.ValidationResult val = urlValidationService.validate(updated.getUrl());
        if (!val.isValid()) {
            throw new IllegalArgumentException(val.getMessage());
        }
        updated.setUrl(val.getNormalizedUrl());

        int index = -1;
        for (int i = 0; i < meetings.size(); i++) {
            if (meetings.get(i).getId().equals(updated.getId())) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            throw new IllegalArgumentException("Meeting record not found for update.");
        }

        meetings.set(index, updated);
        Collections.sort(meetings);

        storageService.saveMeetings(meetings);
        notifyListeners();
    }

    /**
     * Toggles the favorite (starred) status of a meeting.
     */
    public synchronized boolean toggleFavorite(String id) throws IOException {
        Optional<Meeting> target = findById(id);
        if (target.isPresent()) {
            Meeting m = target.get();
            m.setFavorite(!m.isFavorite());
            Collections.sort(meetings);
            storageService.saveMeetings(meetings);
            notifyListeners();
            return m.isFavorite();
        }
        return false;
    }

    /**
     * Duplicates an existing meeting record with a distinct title and UUID.
     */
    public synchronized Meeting duplicateMeeting(String id) throws IOException {
        Optional<Meeting> target = findById(id);
        if (target.isPresent()) {
            Meeting copy = target.get().duplicate();
            meetings.add(copy);
            Collections.sort(meetings);
            storageService.saveMeetings(meetings);
            notifyListeners();
            return copy;
        }
        throw new NoSuchElementException("Meeting not found with ID: " + id);
    }

    public synchronized boolean deleteMeeting(String id) throws IOException {
        if (id == null) return false;
        boolean removed = meetings.removeIf(m -> id.equals(m.getId()));
        if (removed) {
            storageService.saveMeetings(meetings);
            notifyListeners();
        }
        return removed;
    }

    public synchronized void recordMeetingJoined(String id) {
        if (id == null) return;
        findById(id).ifPresent(m -> {
            m.incrementJoinCount();
            try {
                storageService.saveMeetings(meetings);
                notifyListeners();
            } catch (IOException ignored) {
            }
        });
    }

    /**
     * Live search and category filtering with optional favorites filter.
     */
    public synchronized List<Meeting> filterAndSearch(String searchQuery, String categoryFilter, boolean favoritesOnly) {
        String query = searchQuery != null ? searchQuery.trim().toLowerCase() : "";
        String cat = categoryFilter != null ? categoryFilter.trim() : "";

        return meetings.stream().filter(m -> {
            // Favorites filter
            if (favoritesOnly && !m.isFavorite()) {
                return false;
            }

            // Category filter
            if (!cat.isEmpty() && !"All Categories".equalsIgnoreCase(cat) && !"All Meetings".equalsIgnoreCase(cat)) {
                if (!cat.equalsIgnoreCase(m.getCategory())) {
                    return false;
                }
            }

            // Text query
            if (!query.isEmpty()) {
                boolean matchesName = m.getName().toLowerCase().contains(query);
                boolean matchesUrl = m.getUrl().toLowerCase().contains(query);
                boolean matchesCat = m.getCategory().toLowerCase().contains(query);
                boolean matchesDesc = m.getDescription().toLowerCase().contains(query);
                boolean matchesNotes = m.getNotes().toLowerCase().contains(query);
                boolean matchesSchedule = m.getScheduledTime().toLowerCase().contains(query);
                return matchesName || matchesUrl || matchesCat || matchesDesc || matchesNotes || matchesSchedule;
            }

            return true;
        }).collect(Collectors.toList());
    }

    public synchronized List<Meeting> filterAndSearch(String searchQuery, String categoryFilter) {
        return filterAndSearch(searchQuery, categoryFilter, false);
    }

    public synchronized void exportBackup(File file) throws IOException {
        storageService.exportBackup(file, meetings);
    }

    public synchronized int importBackup(File file, boolean replaceExisting) throws IOException {
        List<Meeting> imported = storageService.importBackup(file);
        if (imported.isEmpty()) {
            return 0;
        }

        if (replaceExisting) {
            meetings.clear();
            meetings.addAll(imported);
        } else {
            // Merge mode: Add unique IDs and URLs
            for (Meeting m : imported) {
                boolean exists = meetings.stream().anyMatch(existing ->
                        existing.getId().equals(m.getId()) ||
                                existing.getUrl().equalsIgnoreCase(m.getUrl()));
                if (!exists) {
                    meetings.add(m);
                }
            }
        }

        Collections.sort(meetings);
        storageService.saveMeetings(meetings);
        notifyListeners();
        return imported.size();
    }

    public synchronized DefaultMeetingConfig getDefaultMeeting() {
        return storageService.getDefaultMeeting();
    }

    public synchronized void saveDefaultMeeting(String title, String url) {
        String cleanTitle = (title != null && !title.trim().isEmpty()) ? title.trim() : "Primary Google Meet";
        String cleanUrl = url != null ? url.trim() : "";
        if (!cleanUrl.isEmpty()) {
            UrlValidationService.ValidationResult res = urlValidationService.validate(cleanUrl);
            if (res.isValid()) {
                cleanUrl = res.getNormalizedUrl();
            }
        }
        DefaultMeetingConfig current = storageService.getDefaultMeeting();
        current.setTitle(cleanTitle);
        current.setUrl(cleanUrl);
        storageService.saveDefaultMeeting(current);
        notifyListeners();
    }

    public synchronized void recordDefaultMeetingJoined() {
        DefaultMeetingConfig current = storageService.getDefaultMeeting();
        current.incrementJoinCount();
        storageService.saveDefaultMeeting(current);

        // Also check if any existing meeting matches this URL, and increment its count too
        if (current.isConfigured()) {
            for (Meeting m : meetings) {
                if (m.getUrl().equalsIgnoreCase(current.getUrl())) {
                    m.incrementJoinCount();
                    try {
                        storageService.saveMeetings(meetings);
                    } catch (IOException ignored) {}
                    break;
                }
            }
        }
        notifyListeners();
    }

    public MeetingStorageService getStorageService() {
        return storageService;
    }

    public UrlValidationService getUrlValidationService() {
        return urlValidationService;
    }
}
