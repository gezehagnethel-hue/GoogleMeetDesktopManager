package com.example.meetmanager.ui;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.UrlValidationService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Dialog allowing users to batch add multiple meeting buttons in a single interface.
 */
public class BatchAddDialog extends JDialog {

    private final MeetingService meetingService;
    private final UrlValidationService validator;
    private JTextArea bulkTextArea;
    private JLabel statusLabel;
    private boolean addedAny = false;

    public BatchAddDialog(Frame owner, MeetingService meetingService) {
        super(owner, "Add Multiple Meeting Buttons", true);
        this.meetingService = meetingService;
        this.validator = meetingService.getUrlValidationService();

        setSize(580, 480);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        JPanel content = new JPanel(new BorderLayout(8, 12));
        content.setBorder(new EmptyBorder(16, 20, 16, 20));
        content.setBackground(Color.WHITE);

        // Header
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel title = new JLabel("Add Multiple Permanent Meeting Buttons");
        title.setFont(new Font("Segoe UI", Font.BOLD, 15));
        title.setForeground(new Color(32, 33, 36));

        JLabel desc = new JLabel("<html><body style='width: 520px; color: #5f6368; font-size: 11px;'>" +
                "Enter or paste one meeting per line in either format:<br>" +
                "<b>Meeting Name | https://meet.google.com/xxx-yyyy-zzz | Category</b><br>" +
                "or simply: <b>Meeting Name, https://meet.google.com/xxx-yyyy-zzz</b>" +
                "</body></html>");
        desc.setBorder(new EmptyBorder(4, 0, 8, 0));

        header.add(title);
        header.add(desc);
        content.add(header, BorderLayout.NORTH);

        // Text area for multi-entry
        bulkTextArea = new JTextArea(12, 40);
        bulkTextArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        bulkTextArea.setText(
                "Engineering Standup | https://meet.google.com/eng-sync-dly | Daily Standup\n" +
                "Design Critique | https://meet.google.com/des-crit-rev | Team Meetings\n" +
                "Client Briefing Room | https://meet.google.com/cli-demo-rm1 | Clients\n" +
                "Founder 1-on-1 | https://meet.google.com/fnd-sync-one | 1-on-1s"
        );
        JScrollPane scroll = new JScrollPane(bulkTextArea);
        content.add(scroll, BorderLayout.CENTER);

        // Status / feedback label
        statusLabel = new JLabel("Ready to import multiple meeting buttons.");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(new Color(95, 99, 104));
        content.add(statusLabel, BorderLayout.SOUTH);

        add(content, BorderLayout.CENTER);

        // Bottom Actions
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        footer.setBackground(new Color(248, 249, 250));
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 231, 239)));

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> dispose());

        JButton addAllBtn = new JButton("+ Create All Buttons");
        addAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addAllBtn.setForeground(Color.WHITE);
        addAllBtn.setBackground(new Color(26, 115, 232));
        addAllBtn.setFocusPainted(false);
        addAllBtn.addActionListener(e -> handleProcessBatch());

        footer.add(cancelBtn);
        footer.add(addAllBtn);
        add(footer, BorderLayout.SOUTH);
    }

    private void handleProcessBatch() {
        String text = bulkTextArea.getText();
        if (text == null || text.trim().isEmpty()) {
            statusLabel.setText("Please enter at least one meeting line.");
            return;
        }

        String[] lines = text.split("\\r?\\n");
        int successCount = 0;
        List<String> errors = new ArrayList<>();

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;

            String[] parts;
            if (line.contains("|")) {
                parts = line.split("\\|");
            } else if (line.contains(",")) {
                parts = line.split(",");
            } else {
                parts = line.split("\\s{2,}");
            }

            if (parts.length < 2) {
                errors.add("Line " + (i + 1) + ": Missing URL or Name separator.");
                continue;
            }

            String name = parts[0].trim();
            String rawUrl = parts[1].trim();
            String cat = parts.length >= 3 ? parts[2].trim() : "General";

            UrlValidationService.ValidationResult res = validator.validate(rawUrl);
            if (!res.isValid()) {
                errors.add("Line " + (i + 1) + " (" + name + "): " + res.getMessage());
                continue;
            }

            try {
                Meeting m = new Meeting(name, res.getNormalizedUrl(), cat, "", "");
                meetingService.addMeeting(m);
                successCount++;
            } catch (Exception ex) {
                errors.add("Line " + (i + 1) + ": " + ex.getMessage());
            }
        }

        if (successCount > 0) {
            addedAny = true;
            String msg = "Successfully created " + successCount + " meeting buttons!";
            if (!errors.isEmpty()) {
                msg += "\n\nSkipped " + errors.size() + " line(s) with errors:\n" + String.join("\n", errors);
                JOptionPane.showMessageDialog(this, msg, "Batch Creation Result", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
            }
            dispose();
        } else {
            statusLabel.setText("No valid meetings could be parsed. Check format.");
            if (!errors.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Errors found:\n" + String.join("\n", errors), "Batch Add Errors", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean isAddedAny() {
        return addedAny;
    }
}
