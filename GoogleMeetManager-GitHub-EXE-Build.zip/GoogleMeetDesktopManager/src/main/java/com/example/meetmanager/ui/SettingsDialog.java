package com.example.meetmanager.ui;

import com.example.meetmanager.service.MeetingService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.nio.file.Path;

/**
 * Settings and storage management dialog.
 */
public class SettingsDialog extends JDialog {

    private final MeetingService meetingService;

    public SettingsDialog(Frame owner, MeetingService meetingService) {
        super(owner, "Settings & Local Data Storage", true);
        this.meetingService = meetingService;

        setSize(560, 480);
        setLocationRelativeTo(owner);
        setResizable(false);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(20, 24, 20, 24));
        contentPanel.setBackground(Color.WHITE);

        // --- Section 1: Storage Location ---
        JLabel section1Title = new JLabel("Local Storage Location");
        section1Title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        section1Title.setForeground(new Color(32, 33, 36));
        contentPanel.add(section1Title);

        JLabel storageDesc = new JLabel("<html><body style='width: 480px; color: #5f6368;'>Meeting records are saved persistently on this PC in your user profile data directory as JSON. No passwords or tokens are stored.</body></html>");
        storageDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        storageDesc.setBorder(new EmptyBorder(4, 0, 8, 0));
        contentPanel.add(storageDesc);

        Path dataPath = meetingService.getStorageService().getDataFilePath();
        JTextField pathField = new JTextField(dataPath.toString());
        pathField.setFont(new Font("Consolas", Font.PLAIN, 12));
        pathField.setEditable(false);
        pathField.setBackground(new Color(245, 247, 250));
        pathField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        contentPanel.add(pathField);

        JPanel pathBtnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        pathBtnRow.setOpaque(false);

        JButton openFolderBtn = new JButton("Open Data Folder in Explorer");
        openFolderBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        openFolderBtn.addActionListener(e -> openFolder(meetingService.getStorageService().getStorageDirectory().toFile()));

        JButton copyPathBtn = new JButton("Copy Path");
        copyPathBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        copyPathBtn.addActionListener(e -> {
            com.example.meetmanager.util.ClipboardUtil.copyToClipboard(dataPath.toString());
            JOptionPane.showMessageDialog(this, "Path copied to clipboard!", "Copied", JOptionPane.INFORMATION_MESSAGE);
        });

        pathBtnRow.add(openFolderBtn);
        pathBtnRow.add(copyPathBtn);
        contentPanel.add(pathBtnRow);

        contentPanel.add(Box.createVerticalStrut(16));

        // --- Section 2: Backup & Restore ---
        JLabel section2Title = new JLabel("Backup & Restore");
        section2Title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        section2Title.setForeground(new Color(32, 33, 36));
        contentPanel.add(section2Title);

        JLabel backupDesc = new JLabel("<html><body style='width: 480px; color: #5f6368;'>Export your saved meetings to a portable JSON backup file, or restore existing meetings from a backup.</body></html>");
        backupDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        backupDesc.setBorder(new EmptyBorder(4, 0, 8, 0));
        contentPanel.add(backupDesc);

        JPanel backupBtnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        backupBtnRow.setOpaque(false);

        JButton exportBtn = new JButton("Export Backup (JSON)...");
        exportBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        exportBtn.addActionListener(e -> handleExport());

        JButton importBtn = new JButton("Restore from Backup (JSON)...");
        importBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        importBtn.addActionListener(e -> handleImport());

        backupBtnRow.add(exportBtn);
        backupBtnRow.add(importBtn);
        contentPanel.add(backupBtnRow);

        contentPanel.add(Box.createVerticalStrut(16));

        // --- Section 3: Safety & Info ---
        JLabel section3Title = new JLabel("Security & Operating Integrity");
        section3Title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        section3Title.setForeground(new Color(32, 33, 36));
        contentPanel.add(section3Title);

        JLabel secInfo = new JLabel("<html><body style='width: 480px; color: #5f6368;'>" +
                "• Strict HTTPS & meet.google.com domain verification.<br>" +
                "• Shell execution and external scheme injection disabled.<br>" +
                "• Atomic file write protection prevents file corruption during unexpected power cuts.<br>" +
                "• No telemetry, external ads, or Google password caching." +
                "</body></html>");
        secInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        secInfo.setBorder(new EmptyBorder(4, 0, 8, 0));
        contentPanel.add(secInfo);

        add(contentPanel, BorderLayout.CENTER);

        // Bottom close button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        bottomPanel.setBackground(new Color(248, 249, 250));
        bottomPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 231, 239)));

        JButton closeBtn = new JButton("Done");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        closeBtn.addActionListener(e -> dispose());
        bottomPanel.add(closeBtn);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void openFolder(File folder) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(folder);
            } else {
                new ProcessBuilder("explorer.exe", folder.getAbsolutePath()).start();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Could not open folder: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleExport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export Meeting Backup");
        chooser.setSelectedFile(new File("google-meet-backup.json"));
        int res = chooser.showSaveDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File dest = chooser.getSelectedFile();
            if (!dest.getName().toLowerCase().endsWith(".json")) {
                dest = new File(dest.getParentFile(), dest.getName() + ".json");
            }
            try {
                meetingService.exportBackup(dest);
                JOptionPane.showMessageDialog(this,
                        "Successfully exported " + meetingService.getMeetingCount() + " meetings to:\n" + dest.getAbsolutePath(),
                        "Backup Export Complete",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to export backup: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleImport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Restore Meeting Backup");
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File src = chooser.getSelectedFile();

            Object[] options = {"Merge with Existing", "Replace All", "Cancel"};
            int mode = JOptionPane.showOptionDialog(
                    this,
                    "How would you like to restore the backup file?\n\n" +
                            "• Merge: Keeps existing meetings and adds new ones from backup.\n" +
                            "• Replace All: Replaces your current meetings with the backup records.",
                    "Restore Mode",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (mode == 0 || mode == 1) {
                boolean replace = (mode == 1);
                try {
                    int count = meetingService.importBackup(src, replace);
                    JOptionPane.showMessageDialog(this,
                            "Successfully imported " + count + " valid meeting records from backup.",
                            "Restore Complete",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Failed to import backup: " + ex.getMessage(), "Import Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}
