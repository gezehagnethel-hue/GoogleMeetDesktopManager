package com.example.meetmanager.ui;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.util.BrowserUtil;
import com.example.meetmanager.util.ClipboardUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.function.Consumer;

/**
 * UI Component representing an individual meeting card in the dashboard.
 * Supports Favorite toggle, Duplicate, Copy, Edit, Delete, and 1-Click Launch.
 */
public class MeetingCard extends JPanel {

    private static final Color GOOGLE_BLUE = new Color(26, 115, 232);
    private static final Color CARD_BG = Color.WHITE;
    private static final Color BORDER_COLOR = new Color(225, 231, 239);
    private static final Color TEXT_PRIMARY = new Color(32, 33, 36);
    private static final Color TEXT_SECONDARY = new Color(95, 99, 104);
    private static final Color BADGE_BG = new Color(232, 240, 254);
    private static final Color BADGE_TEXT = new Color(25, 103, 210);

    private final Meeting meeting;
    private final Consumer<Meeting> onEdit;
    private final Consumer<Meeting> onDelete;
    private final Consumer<Meeting> onJoin;
    private final Consumer<Meeting> onDuplicate;
    private final Consumer<Meeting> onToggleFavorite;

    public MeetingCard(Meeting meeting,
                       Consumer<Meeting> onEdit,
                       Consumer<Meeting> onDelete,
                       Consumer<Meeting> onJoin,
                       Consumer<Meeting> onDuplicate,
                       Consumer<Meeting> onToggleFavorite) {
        this.meeting = meeting;
        this.onEdit = onEdit;
        this.onDelete = onDelete;
        this.onJoin = onJoin;
        this.onDuplicate = onDuplicate;
        this.onToggleFavorite = onToggleFavorite;

        setLayout(new BorderLayout(12, 10));
        setBackground(CARD_BG);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(meeting.isFavorite() ? new Color(251, 191, 36) : BORDER_COLOR, meeting.isFavorite() ? 2 : 1, true),
                new EmptyBorder(14, 16, 14, 16)
        ));

        initUI();
    }

    private void initUI() {
        // --- TOP PANEL: Title, Favorite Star, & Category ---
        JPanel topPanel = new JPanel(new BorderLayout(8, 0));
        topPanel.setOpaque(false);

        JPanel titleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        titleRow.setOpaque(false);

        JButton starBtn = new JButton(meeting.isFavorite() ? "★" : "☆");
        starBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        starBtn.setForeground(meeting.isFavorite() ? new Color(217, 119, 6) : new Color(156, 163, 175));
        starBtn.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 4));
        starBtn.setContentAreaFilled(false);
        starBtn.setFocusPainted(false);
        starBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        starBtn.setToolTipText(meeting.isFavorite() ? "Starred Favorite (Click to unpin)" : "Mark as Favorite");
        starBtn.addActionListener(e -> {
            if (onToggleFavorite != null) onToggleFavorite.accept(meeting);
        });
        titleRow.add(starBtn);

        JLabel nameLabel = new JLabel(meeting.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nameLabel.setForeground(TEXT_PRIMARY);
        titleRow.add(nameLabel);

        JPanel badgesPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        badgesPanel.setOpaque(false);

        if (meeting.getScheduledTime() != null && !meeting.getScheduledTime().isEmpty()) {
            JLabel timeBadge = new JLabel("🕒 " + meeting.getScheduledTime());
            timeBadge.setOpaque(true);
            timeBadge.setBackground(new Color(243, 244, 246));
            timeBadge.setForeground(new Color(55, 65, 81));
            timeBadge.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            timeBadge.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(229, 231, 235), 1, true),
                    new EmptyBorder(2, 6, 2, 6)
            ));
            badgesPanel.add(timeBadge);
        }

        JLabel categoryBadge = new JLabel(" " + meeting.getCategory() + " ");
        categoryBadge.setOpaque(true);
        categoryBadge.setBackground(BADGE_BG);
        categoryBadge.setForeground(BADGE_TEXT);
        categoryBadge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        categoryBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(194, 217, 254), 1, true),
                new EmptyBorder(2, 7, 2, 7)
        ));
        badgesPanel.add(categoryBadge);

        topPanel.add(titleRow, BorderLayout.CENTER);
        topPanel.add(badgesPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // --- CENTER PANEL: URL, Description, Notes ---
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setOpaque(false);

        JLabel urlLabel = new JLabel("meet.google.com/" + meeting.getDisplayMeetingCode());
        urlLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        urlLabel.setForeground(GOOGLE_BLUE);
        urlLabel.setBorder(new EmptyBorder(3, 0, 4, 0));
        centerPanel.add(urlLabel);

        if (meeting.getDescription() != null && !meeting.getDescription().trim().isEmpty()) {
            JLabel descLabel = new JLabel("<html><body style='width: 320px; color: #3c4043; font-size: 11px;'>" + escapeHtml(meeting.getDescription()) + "</body></html>");
            descLabel.setBorder(new EmptyBorder(2, 0, 2, 0));
            centerPanel.add(descLabel);
        }

        if (meeting.getNotes() != null && !meeting.getNotes().trim().isEmpty()) {
            JLabel notesLabel = new JLabel("<html><body style='width: 320px; color: #5f6368; font-style: italic; font-size: 11px;'>Note: " + escapeHtml(meeting.getNotes()) + "</body></html>");
            notesLabel.setBorder(new EmptyBorder(2, 0, 4, 0));
            centerPanel.add(notesLabel);
        }

        if (meeting.getJoinCount() > 0 && meeting.getLastJoinedAt() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM d, HH:mm");
            JLabel statsLabel = new JLabel("Launched " + meeting.getJoinCount() + " time" + (meeting.getJoinCount() > 1 ? "s" : "") + " (last: " + sdf.format(new Date(meeting.getLastJoinedAt())) + ")");
            statsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            statsLabel.setForeground(TEXT_SECONDARY);
            statsLabel.setBorder(new EmptyBorder(2, 0, 2, 0));
            centerPanel.add(statsLabel);
        }

        add(centerPanel, BorderLayout.CENTER);

        // --- BOTTOM PANEL: Actions ---
        JPanel bottomPanel = new JPanel(new BorderLayout(8, 0));
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(new EmptyBorder(8, 0, 0, 0));

        // Primary: Dedicated "Join Meeting" button
        JButton joinBtn = new JButton("Join Meeting");
        joinBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        joinBtn.setForeground(Color.WHITE);
        joinBtn.setBackground(GOOGLE_BLUE);
        joinBtn.setFocusPainted(false);
        joinBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        joinBtn.setBorder(new EmptyBorder(7, 14, 7, 14));
        joinBtn.setToolTipText("Open " + meeting.getUrl() + " in default web browser (Requires internet)");
        joinBtn.addActionListener(e -> launchMeeting());

        // Secondary buttons: Copy, Duplicate, Edit, Delete
        JPanel secondaryBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        secondaryBtns.setOpaque(false);

        JButton copyBtn = new JButton("Copy Link");
        copyBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        copyBtn.setFocusPainted(false);
        copyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        copyBtn.addActionListener(e -> {
            boolean ok = ClipboardUtil.copyToClipboard(meeting.getUrl());
            if (ok) {
                copyBtn.setText("Copied!");
                Timer t = new Timer(1500, evt -> copyBtn.setText("Copy Link"));
                t.setRepeats(false);
                t.start();
            }
        });

        JButton duplicateBtn = new JButton("Duplicate");
        duplicateBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        duplicateBtn.setFocusPainted(false);
        duplicateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        duplicateBtn.setToolTipText("Create an exact copy of this meeting button");
        duplicateBtn.addActionListener(e -> {
            if (onDuplicate != null) onDuplicate.accept(meeting);
        });

        JButton editBtn = new JButton("Edit");
        editBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        editBtn.setFocusPainted(false);
        editBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        editBtn.addActionListener(e -> {
            if (onEdit != null) onEdit.accept(meeting);
        });

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        deleteBtn.setForeground(new Color(217, 48, 37));
        deleteBtn.setFocusPainted(false);
        deleteBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        deleteBtn.addActionListener(e -> {
            if (onDelete != null) onDelete.accept(meeting);
        });

        secondaryBtns.add(copyBtn);
        secondaryBtns.add(duplicateBtn);
        secondaryBtns.add(editBtn);
        secondaryBtns.add(deleteBtn);

        bottomPanel.add(joinBtn, BorderLayout.WEST);
        bottomPanel.add(secondaryBtns, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void launchMeeting() {
        try {
            BrowserUtil.openUrl(meeting.getUrl());
            if (onJoin != null) {
                onJoin.accept(meeting);
            }
        } catch (IllegalArgumentException iae) {
            JOptionPane.showMessageDialog(this,
                    "Invalid URL: " + iae.getMessage(),
                    "URL Security Warning",
                    JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Failed to open browser: " + ex.getMessage() + "\nURL: " + meeting.getUrl() +
                            "\n\nNote: An active internet connection is required to join a Google Meet call.",
                    "Browser Launch Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    public Meeting getMeeting() {
        return meeting;
    }
}
