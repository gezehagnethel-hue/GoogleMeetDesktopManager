package com.example.meetmanager.util;

import com.example.meetmanager.service.UrlValidationService;

import java.awt.Desktop;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Safely opens validated Google Meet URLs in the system's default web browser.
 */
public final class BrowserUtil {

    private static final Logger LOGGER = Logger.getLogger(BrowserUtil.class.getName());
    private static final UrlValidationService VALIDATOR = new UrlValidationService();

    private BrowserUtil() {}

    /**
     * Opens a Google Meet URL in the default web browser.
     *
     * @param urlStr Valid Google Meet URL
     * @throws IllegalArgumentException If URL fails security validation
     * @throws Exception If opening browser fails
     */
    public static void openUrl(String urlStr) throws Exception {
        UrlValidationService.ValidationResult val = VALIDATOR.validate(urlStr);
        if (!val.isValid()) {
            throw new IllegalArgumentException("Cannot open invalid URL: " + val.getMessage());
        }

        String safeUrl = val.getNormalizedUrl();
        URI uri = new URI(safeUrl);

        // 1. Try standard Java Desktop API first
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            try {
                Desktop.getDesktop().browse(uri);
                LOGGER.info("Opened URL via Java Desktop API: " + safeUrl);
                return;
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Desktop.browse failed, attempting platform fallback", e);
            }
        }

        // 2. Windows-specific fallback execution
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            try {
                // Use rundll32 or ProcessBuilder with start
                new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", safeUrl).start();
                LOGGER.info("Opened URL via Windows FileProtocolHandler: " + safeUrl);
                return;
            } catch (Exception winEx) {
                LOGGER.log(Level.WARNING, "Windows rundll32 fallback failed", winEx);
            }
        } else if (os.contains("mac")) {
            new ProcessBuilder("open", safeUrl).start();
            return;
        } else if (os.contains("nix") || os.contains("nux")) {
            new ProcessBuilder("xdg-open", safeUrl).start();
            return;
        }

        throw new UnsupportedOperationException("Could not launch web browser. Please configure your default system browser.");
    }
}
