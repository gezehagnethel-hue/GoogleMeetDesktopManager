package com.example.meetmanager.audio;

import java.io.Serializable;
import java.util.UUID;

public class RecordingSession implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String meetingTitle;
    private String filename;
    private String filePath;
    private long startTime;
    private long durationMs;
    private long fileSizeBytes;
    private RecordingMode mode;
    private boolean consentConfirmed;

    public RecordingSession() {
        this.id = UUID.randomUUID().toString();
        this.startTime = System.currentTimeMillis();
        this.mode = RecordingMode.MIC_ONLY;
        this.consentConfirmed = false;
    }

    public RecordingSession(String id, String meetingTitle, String filename, String filePath,
                            long startTime, long durationMs, long fileSizeBytes,
                            RecordingMode mode, boolean consentConfirmed) {
        this.id = (id != null && !id.trim().isEmpty()) ? id : UUID.randomUUID().toString();
        this.meetingTitle = (meetingTitle != null) ? meetingTitle.trim() : "Ad-hoc Meeting";
        this.filename = filename != null ? filename : "";
        this.filePath = filePath != null ? filePath : "";
        this.startTime = startTime;
        this.durationMs = durationMs;
        this.fileSizeBytes = fileSizeBytes;
        this.mode = (mode != null) ? mode : RecordingMode.MIC_ONLY;
        this.consentConfirmed = consentConfirmed;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMeetingTitle() {
        return meetingTitle;
    }

    public void setMeetingTitle(String meetingTitle) {
        this.meetingTitle = meetingTitle;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(long durationMs) {
        this.durationMs = durationMs;
    }

    public long getFileSizeBytes() {
        return fileSizeBytes;
    }

    public void setFileSizeBytes(long fileSizeBytes) {
        this.fileSizeBytes = fileSizeBytes;
    }

    public RecordingMode getMode() {
        return mode;
    }

    public void setMode(RecordingMode mode) {
        this.mode = mode;
    }

    public boolean isConsentConfirmed() {
        return consentConfirmed;
    }

    public void setConsentConfirmed(boolean consentConfirmed) {
        this.consentConfirmed = consentConfirmed;
    }

    public String getFormattedDuration() {
        long totalSeconds = durationMs / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        long hours = minutes / 60;
        minutes = minutes % 60;
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format("%02d:%02d", minutes, seconds);
    }

    public String getFormattedSize() {
        if (fileSizeBytes < 1024) {
            return fileSizeBytes + " B";
        } else if (fileSizeBytes < 1024 * 1024) {
            return String.format("%.1f KB", fileSizeBytes / 1024.0);
        } else {
            return String.format("%.2f MB", fileSizeBytes / (1024.0 * 1024.0));
        }
    }
}
