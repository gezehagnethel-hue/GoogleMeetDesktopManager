package com.example.meetmanager.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * About and Attribution Dialog.
 */
public class AboutDialog extends JDialog {

    public AboutDialog(Frame owner) {
        super(owner, "About Google Meet Desktop Manager", true);

        setSize(480, 360);
        setLocationRelativeTo(owner);
        setResizable(false);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(24, 28, 20, 28));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Google Meet Desktop Manager");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(26, 115, 232));
        panel.add(title);

        JLabel version = new JLabel("Version 1.0.0 (Production Release)");
        version.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        version.setForeground(new Color(95, 99, 104));
        version.setBorder(new EmptyBorder(2, 0, 16, 0));
        panel.add(version);

        JLabel desc = new JLabel("<html><body style='width: 400px; color: #3c4043; line-height: 1.4;'>" +
                "<b>Google Meet Desktop Manager</b> is an independent desktop launcher and organizer designed for Windows 10 and Windows 11.<br><br>" +
                "It enables professionals, educators, and teams to bookmark and launch their permanent Google Meet conference links with a single click in their default web browser.<br><br>" +
                "<b>Disclaimer:</b> This application is an independent open-source launcher utility and is not affiliated with, sponsored by, or endorsed by Google LLC. All Google Meet trademarks and assets remain the property of Google LLC." +
                "</body></html>");
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        panel.add(desc);

        add(panel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        btnPanel.setBackground(new Color(248, 249, 250));
        btnPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 231, 239)));

        JButton okBtn = new JButton("Close");
        okBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        okBtn.addActionListener(e -> dispose());
        btnPanel.add(okBtn);

        add(btnPanel, BorderLayout.SOUTH);
    }
}
