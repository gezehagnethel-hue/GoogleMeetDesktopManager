package com.example.meetmanager.audio;

public enum RecordingMode {
    DUAL_STREAM_MIXED("Dual-Stream (Microphone + Remote System Loopback Audio)", true),
    MIC_ONLY("Single-Stream (Microphone Only - 1-Sided)", false);

    private final String label;
    private final boolean twoSided;

    RecordingMode(String label, boolean twoSided) {
        this.label = label;
        this.twoSided = twoSided;
    }

    public String getLabel() {
        return label;
    }

    public boolean isTwoSided() {
        return twoSided;
    }
}
