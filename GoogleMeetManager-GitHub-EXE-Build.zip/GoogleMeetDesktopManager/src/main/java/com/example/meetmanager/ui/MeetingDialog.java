package com.example.meetmanager.ui;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.UrlValidationService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Optional;
import java.util.Set;

/**
 * Dialog for adding or editing a meeting button with scheduling and favorite options.
 */
public class MeetingDialog extends JDialog {

    private final MeetingService meetingService;
    private final Meeting existingMeeting;
    private boolean saved = false;

    private JTextField nameField;
    private JTextField urlField;
    private JComboBox<String> categoryCombo;
    private JTextField scheduledTimeField;
    private JCheckBox favoriteCheck;
    private JComboBox<String> colorCombo;
    private JTextField descField;
    private JTextArea notesArea;
    private JLabel errorLabel;

    public MeetingDialog(Frame owner, MeetingService meetingService, Meeting existingMeeting) {
        super(owner, existingMeeting == null ? "Add Meeting Button" : "Edit Meeting Button", true);
        this.meetingService = meetingService;
        this.existingMeeting = existingMeeting;

        setSize(540, 560);
        setLocationRelativeTo(owner);
        setResizable(false);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(18, 24, 14, 24));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 4, 5, 4);

        int row = 0;

        JLabel headerLabel = new JLabel(existingMeeting == null ? "Save a Permanent Google Meet Button" : "Update Meeting Button Details");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        headerLabel.setForeground(new Color(32, 33, 36));
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 2;
        formPanel.add(headerLabel, gbc);

        JLabel subHeader = new JLabel("Permanent URL is stored offline. An active internet connection is required to join a call.");
        subHeader.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        subHeader.setForeground(new Color(95, 99, 104));
        gbc.gridy = row++;
        gbc.insets = new Insets(0, 4, 12, 4);
        formPanel.add(subHeader, gbc);

        gbc.insets = new Insets(5, 4, 5, 4);
        gbc.gridwidth = 1;

        // 1. Meeting Name
        JLabel nameLabel = new JLabel("Button Name *:");
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.28;
        formPanel.add(nameLabel, gbc);

        nameField = new JTextField(24);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        if (existingMeeting != null) nameField.setText(existingMeeting.getName());
        gbc.gridx = 1;
        gbc.weightx = 0.72;
        formPanel.add(nameField, gbc);
        row++;

        // 2. Google Meet URL
        JLabel urlLabel = new JLabel("Google Meet URL *:");
        urlLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(urlLabel, gbc);

        urlField = new JTextField(24);
        urlField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        if (existingMeeting != null) {
            urlField.setText(existingMeeting.getUrl());
        } else {
            urlField.setText("https://meet.google.com/");
        }
        gbc.gridx = 1;
        formPanel.add(urlField, gbc);
        row++;

        // 3. Category
        JLabel catLabel = new JLabel("Category:");
        catLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(catLabel, gbc);

        categoryCombo = new JComboBox<>();
        categoryCombo.setEditable(true);
        categoryCombo.addItem("General");
        categoryCombo.addItem("Daily Standup");
        categoryCombo.addItem("Team Meetings");
        categoryCombo.addItem("Clients");
        categoryCombo.addItem("1-on-1s");
        categoryCombo.addItem("Personal");

        Set<String> allCats = meetingService.getAllCategories();
        for (String cat : allCats) {
            boolean exists = false;
            for (int i = 0; i < categoryCombo.getItemCount(); i++) {
                if (categoryCombo.getItemAt(i).equalsIgnoreCase(cat)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) categoryCombo.addItem(cat);
        }

        if (existingMeeting != null && existingMeeting.getCategory() != null) {
            categoryCombo.setSelectedItem(existingMeeting.getCategory());
        }
        gbc.gridx = 1;
        formPanel.add(categoryCombo, gbc);
        row++;

        // 4. Scheduled Time (Optional)
        JLabel timeLabel = new JLabel("Scheduled Time:");
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(timeLabel, gbc);

        scheduledTimeField = new JTextField(24);
        scheduledTimeField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        if (existingMeeting != null && existingMeeting.getScheduledTime() != null) {
            scheduledTimeField.setText(existingMeeting.getScheduledTime());
        }
        scheduledTimeField.putClientProperty("JTextField.placeholderText", "e.g. Weekdays 09:30 AM, 2026-10-21 14:00");
        gbc.gridx = 1;
        formPanel.add(scheduledTimeField, gbc);
        row++;

        // 5. Button Color & Favorite Options
        JLabel optLabel = new JLabel("Options:");
        optLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(optLabel, gbc);

        JPanel optPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        optPanel.setOpaque(false);

        favoriteCheck = new JCheckBox("★ Star as Favorite (Pin to Top)");
        favoriteCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        if (existingMeeting != null) {
            favoriteCheck.setSelected(existingMeeting.isFavorite());
        }

        colorCombo = new JComboBox<>(new String[]{"Google Blue", "Emerald Green", "Purple", "Warm Amber", "Teal", "Rose Red"});
        if (existingMeeting != null && existingMeeting.getColor() != null) {
            colorCombo.setSelectedItem(existingMeeting.getColor());
        }

        optPanel.add(favoriteCheck);
        optPanel.add(new JLabel("Color:"));
        optPanel.add(colorCombo);

        gbc.gridx = 1;
        formPanel.add(optPanel, gbc);
        row++;

        // 6. Description
        JLabel descLabel = new JLabel("Description:");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        formPanel.add(descLabel, gbc);

        descField = new JTextField(24);
        descField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        if (existingMeeting != null) descField.setText(existingMeeting.getDescription());
        gbc.gridx = 1;
        formPanel.add(descField, gbc);
        row++;

        // 7. Notes
        JLabel notesLabel = new JLabel("Notes / Agenda:");
        notesLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        formPanel.add(notesLabel, gbc);

        notesArea = new JTextArea(3, 24);
        notesArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        if (existingMeeting != null) notesArea.setText(existingMeeting.getNotes());
        JScrollPane notesScroll = new JScrollPane(notesArea);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        formPanel.add(notesScroll, gbc);
        row++;

        // Error message row
        errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        errorLabel.setForeground(new Color(217, 48, 37));
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(errorLabel, gbc);

        add(formPanel, BorderLayout.CENTER);

        // Bottom Actions
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        btnPanel.setBackground(new Color(248, 249, 250));
        btnPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 231, 239)));

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cancelBtn.addActionListener(e -> dispose());

        JButton saveBtn = new JButton(existingMeeting == null ? "Save Button" : "Update Button");
        saveBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setBackground(new Color(26, 115, 232));
        saveBtn.setFocusPainted(false);
        saveBtn.addActionListener(e -> handleSave());

        btnPanel.add(cancelBtn);
        btnPanel.add(saveBtn);
        add(btnPanel, BorderLayout.SOUTH);

        getRootPane().setDefaultButton(saveBtn);
    }

    private void handleSave() {
        String name = nameField.getText().trim();
        String rawUrl = urlField.getText().trim();
        Object catObj = categoryCombo.getSelectedItem();
        String category = catObj != null ? catObj.toString().trim() : "General";
        String scheduledTime = scheduledTimeField.getText().trim();
        boolean favorite = favoriteCheck.isSelected();
        String color = (String) colorCombo.getSelectedItem();
        String desc = descField.getText().trim();
        String notes = notesArea.getText().trim();

        if (name.isEmpty()) {
            errorLabel.setText("Please enter a meeting button name.");
            nameField.requestFocusInWindow();
            return;
        }

        UrlValidationService validator = meetingService.getUrlValidationService();
        UrlValidationService.ValidationResult res = validator.validate(rawUrl);

        if (!res.isValid()) {
            errorLabel.setText(res.getMessage());
            urlField.requestFocusInWindow();
            return;
        }

        String normalizedUrl = res.getNormalizedUrl();

        String currentId = existingMeeting != null ? existingMeeting.getId() : null;
        Optional<Meeting> duplicate = meetingService.findDuplicateByUrl(normalizedUrl, currentId);
        if (duplicate.isPresent()) {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Another button ('" + duplicate.get().getName() + "') already uses this Google Meet link.\n" +
                            "Do you still want to save this meeting button?",
                    "Duplicate Meeting Link Notice",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );
            if (choice != JOptionPane.YES_OPTION) {
                return;
            }
        }

        try {
            if (existingMeeting == null) {
                Meeting newMeeting = new Meeting(
                        null,
                        name,
                        normalizedUrl,
                        category,
                        desc,
                        notes,
                        scheduledTime,
                        favorite,
                        color,
                        System.currentTimeMillis(),
                        System.currentTimeMillis(),
                        null,
                        0
                );
                meetingService.addMeeting(newMeeting);
            } else {
                existingMeeting.setName(name);
                existingMeeting.setUrl(normalizedUrl);
                existingMeeting.setCategory(category);
                existingMeeting.setScheduledTime(scheduledTime);
                existingMeeting.setFavorite(favorite);
                existingMeeting.setColor(color);
                existingMeeting.setDescription(desc);
                existingMeeting.setNotes(notes);
                meetingService.updateMeeting(existingMeeting);
            }
            saved = true;
            dispose();
        } catch (Exception ex) {
            errorLabel.setText("Failed to save: " + ex.getMessage());
        }
    }

    public boolean isSaved() {
        return saved;
    }
}
