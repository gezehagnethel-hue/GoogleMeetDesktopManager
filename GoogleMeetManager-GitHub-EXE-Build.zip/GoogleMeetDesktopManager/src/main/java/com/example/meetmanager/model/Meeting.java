package com.example.meetmanager.model;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

/**
 * Represents a saved permanent Google Meet URL configuration with metadata,
 * scheduling, favorite status, and analytics.
 */
public class Meeting implements Serializable, Comparable<Meeting> {
    private static final long serialVersionUID = 2L;

    private String id;
    private String name;
    private String url;
    private String category;
    private String description;
    private String notes;
    private String scheduledTime; // Optional scheduled date/time string (e.g., "Mon 10:00 AM", "2026-10-21 14:00")
    private boolean favorite;     // Pinned/starred favorite status
    private String color;         // Accent theme color (e.g., "Google Blue", "Emerald Green")
    private long createdAt;
    private long updatedAt;
    private Long lastJoinedAt;
    private int joinCount;

    public Meeting() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = this.createdAt;
        this.joinCount = 0;
        this.favorite = false;
        this.color = "Google Blue";
        this.category = "General";
    }

    public Meeting(String name, String url, String category, String description, String notes) {
        this.id = UUID.randomUUID().toString();
        this.name = name != null ? name.trim() : "";
        this.url = url != null ? url.trim() : "";
        this.category = category != null && !category.trim().isEmpty() ? category.trim() : "General";
        this.description = description != null ? description.trim() : "";
        this.notes = notes != null ? notes.trim() : "";
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = this.createdAt;
        this.joinCount = 0;
        this.favorite = false;
        this.color = "Google Blue";
    }

    public Meeting(String id, String name, String url, String category, String description, String notes,
                   String scheduledTime, boolean favorite, String color,
                   long createdAt, long updatedAt, Long lastJoinedAt, int joinCount) {
        this.id = id != null && !id.trim().isEmpty() ? id : UUID.randomUUID().toString();
        this.name = name != null ? name.trim() : "";
        this.url = url != null ? url.trim() : "";
        this.category = category != null && !category.trim().isEmpty() ? category.trim() : "General";
        this.description = description != null ? description.trim() : "";
        this.notes = notes != null ? notes.trim() : "";
        this.scheduledTime = scheduledTime != null ? scheduledTime.trim() : "";
        this.favorite = favorite;
        this.color = color != null && !color.trim().isEmpty() ? color.trim() : "Google Blue";
        this.createdAt = createdAt > 0 ? createdAt : System.currentTimeMillis();
        this.updatedAt = updatedAt > 0 ? updatedAt : this.createdAt;
        this.lastJoinedAt = lastJoinedAt;
        this.joinCount = Math.max(0, joinCount);
    }

    /**
     * Creates a duplicate copy of this meeting with a new UUID and distinct name.
     */
    public Meeting duplicate() {
        String copyName = this.name + " (Copy)";
        return new Meeting(
                UUID.randomUUID().toString(),
                copyName,
                this.url,
                this.category,
                this.description,
                this.notes,
                this.scheduledTime,
                this.favorite,
                this.color,
                System.currentTimeMillis(),
                System.currentTimeMillis(),
                null,
                0
        );
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name != null ? name.trim() : "";
        this.updatedAt = System.currentTimeMillis();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url != null ? url.trim() : "";
        this.updatedAt = System.currentTimeMillis();
    }

    public String getCategory() {
        return category != null && !category.trim().isEmpty() ? category : "General";
    }

    public void setCategory(String category) {
        this.category = category != null && !category.trim().isEmpty() ? category.trim() : "General";
        this.updatedAt = System.currentTimeMillis();
    }

    public String getDescription() {
        return description != null ? description : "";
    }

    public void setDescription(String description) {
        this.description = description != null ? description.trim() : "";
        this.updatedAt = System.currentTimeMillis();
    }

    public String getNotes() {
        return notes != null ? notes : "";
    }

    public void setNotes(String notes) {
        this.notes = notes != null ? notes.trim() : "";
        this.updatedAt = System.currentTimeMillis();
    }

    public String getScheduledTime() {
        return scheduledTime != null ? scheduledTime : "";
    }

    public void setScheduledTime(String scheduledTime) {
        this.scheduledTime = scheduledTime != null ? scheduledTime.trim() : "";
        this.updatedAt = System.currentTimeMillis();
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
        this.updatedAt = System.currentTimeMillis();
    }

    public String getColor() {
        return color != null && !color.trim().isEmpty() ? color : "Google Blue";
    }

    public void setColor(String color) {
        this.color = color != null && !color.trim().isEmpty() ? color.trim() : "Google Blue";
        this.updatedAt = System.currentTimeMillis();
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getLastJoinedAt() {
        return lastJoinedAt;
    }

    public void setLastJoinedAt(Long lastJoinedAt) {
        this.lastJoinedAt = lastJoinedAt;
    }

    public int getJoinCount() {
        return joinCount;
    }

    public void setJoinCount(int joinCount) {
        this.joinCount = joinCount;
    }

    public void incrementJoinCount() {
        this.joinCount++;
        this.lastJoinedAt = System.currentTimeMillis();
        this.updatedAt = this.lastJoinedAt;
    }

    /**
     * Extracts normalized meeting code for display (e.g. abc-defg-hij)
     */
    public String getDisplayMeetingCode() {
        if (url == null || url.isEmpty()) {
            return "";
        }
        try {
            java.net.URI uri = java.net.URI.create(url);
            String path = uri.getPath();
            if (path != null && path.startsWith("/")) {
                path = path.substring(1);
            }
            return path != null ? path : "";
        } catch (Exception e) {
            return url;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Meeting meeting = (Meeting) o;
        return Objects.equals(id, meeting.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public int compareTo(Meeting o) {
        if (o == null) return 1;
        // Favorites pinned first
        if (this.favorite != o.favorite) {
            return this.favorite ? -1 : 1;
        }
        // Natural alphabetical ordering by name
        int cmp = this.name.compareToIgnoreCase(o.name);
        if (cmp != 0) return cmp;
        return Long.compare(this.createdAt, o.createdAt);
    }

    @Override
    public String toString() {
        return "Meeting{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", category='" + category + '\'' +
                ", favorite=" + favorite +
                ", scheduledTime='" + scheduledTime + '\'' +
                '}';
    }
}
