package com.example.meetmanager;

import com.example.meetmanager.audio.*;
import com.example.meetmanager.service.MeetingStorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AudioRecordingTest {

    @TempDir
    Path tempDir;

    private MeetingStorageService storageService;

    @BeforeEach
    void setUp() {
        storageService = new MeetingStorageService(tempDir);
    }

    @Test
    @DisplayName("WavFileWriter writes compliant 44-byte RIFF/WAVE header and updates chunk sizes on close")
    void testWavFileWriterCompliantHeader() throws IOException {
        File testWav = tempDir.resolve("test_meeting.wav").toFile();

        try (WavFileWriter writer = new WavFileWriter(testWav, 44100, 1, 16)) {
            // Write 1000 16-bit samples (2000 bytes)
            byte[] dummyPcm = new byte[2000];
            for (int i = 0; i < dummyPcm.length; i++) {
                dummyPcm[i] = (byte) (i % 128);
            }
            writer.writeSamples(dummyPcm, 0, dummyPcm.length);
            assertEquals(2000, writer.getTotalAudioBytes());
        }

        assertTrue(testWav.exists());
        assertEquals(2044, testWav.length()); // 44 header + 2000 data

        byte[] header = new byte[44];
        try (FileInputStream fis = new FileInputStream(testWav)) {
            assertEquals(44, fis.read(header));
        }

        // Verify RIFF and WAVE magic signatures
        assertEquals('R', header[0]);
        assertEquals('I', header[1]);
        assertEquals('F', header[2]);
        assertEquals('F', header[3]);
        assertEquals('W', header[8]);
        assertEquals('A', header[9]);
        assertEquals('V', header[10]);
        assertEquals('E', header[11]);

        // Verify data chunk marker
        assertEquals('d', header[36]);
        assertEquals('a', header[37]);
        assertEquals('t', header[38]);
        assertEquals('a', header[39]);

        // Verify data size in header (little-endian 2000: 0xD0, 0x07, 0x00, 0x00)
        int dataSize = (header[40] & 0xFF) | ((header[41] & 0xFF) << 8);
        assertEquals(2000, dataSize);
    }

    @Test
    @DisplayName("AudioMixer mixes microphone and system streams with anti-clipping protection")
    void testAudioMixerClamping() {
        AudioMixer mixer = new AudioMixer(1.0f, 1.0f);

        // Prepare 2 samples of high positive amplitude (30000 each -> sum 60000 > Short.MAX_VALUE)
        byte[] mic = new byte[2];
        mic[0] = (byte) (30000 & 0xFF);
        mic[1] = (byte) ((30000 >> 8) & 0xFF);

        byte[] sys = new byte[2];
        sys[0] = (byte) (30000 & 0xFF);
        sys[1] = (byte) ((30000 >> 8) & 0xFF);

        byte[] mixed = mixer.mixPcmBuffers(mic, 2, sys, 2);
        assertEquals(2, mixed.length);

        short mixedSample = (short) ((mixed[0] & 0xFF) | (mixed[1] << 8));
        assertEquals(Short.MAX_VALUE, mixedSample); // Clamped gracefully without overflow wraparound

        // Test peak level
        float peak = AudioMixer.calculatePeakLevel(mic, 2);
        assertTrue(peak > 0.9f && peak <= 1.0f);
    }

    @Test
    @DisplayName("AudioRecordingService enforces consent before recording starts")
    void testConsentRequirement() {
        AudioRecordingService service = new AudioRecordingService(tempDir.toFile());

        // Attempting to record without confirmed consent must throw IllegalStateException
        assertThrows(IllegalStateException.class, () -> {
            service.startRecording("Unauthorized Meeting", false);
        });
    }

    @Test
    @DisplayName("RecordingSession persists and loads accurately in SQLite database")
    void testRecordingSessionPersistence() throws SQLException {
        RecordingSession session = new RecordingSession(
                "rec-12345",
                "Product Strategy Sync",
                "GoogleMeet_ProductStrategy_2026.wav",
                tempDir.resolve("GoogleMeet_ProductStrategy_2026.wav").toString(),
                System.currentTimeMillis() - 60000,
                300000L, // 5 minutes
                5292000L, // ~5 MB
                RecordingMode.DUAL_STREAM_MIXED,
                true
        );

        storageService.saveRecordingSession(session);

        List<RecordingSession> loaded = storageService.loadRecordingSessions();
        assertEquals(1, loaded.size());
        RecordingSession retrieved = loaded.get(0);
        assertEquals("rec-12345", retrieved.getId());
        assertEquals("Product Strategy Sync", retrieved.getMeetingTitle());
        assertEquals("GoogleMeet_ProductStrategy_2026.wav", retrieved.getFilename());
        assertEquals(300000L, retrieved.getDurationMs());
        assertEquals("05:00", retrieved.getFormattedDuration());
        assertEquals(RecordingMode.DUAL_STREAM_MIXED, retrieved.getMode());
        assertTrue(retrieved.getMode().isTwoSided());
        assertTrue(retrieved.isConsentConfirmed());

        // Test deletion
        storageService.deleteRecordingSession("rec-12345");
        assertEquals(0, storageService.loadRecordingSessions().size());
    }
}
