package com.example.meetmanager;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.MeetingStorageService;
import com.example.meetmanager.service.UrlValidationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MeetingServiceTest {

    @TempDir
    Path tempDir;

    private MeetingService service;

    @BeforeEach
    void setUp() {
        MeetingStorageService storage = new MeetingStorageService(tempDir);
        UrlValidationService validator = new UrlValidationService();
        service = new MeetingService(storage, validator);
    }

    @Test
    @DisplayName("Adds meeting and persists it")
    void testAddMeeting() throws IOException {
        Meeting m = new Meeting("Design Crit", "https://meet.google.com/abc-defg-hij", "Design", "Critique session", "");
        service.addMeeting(m);

        assertEquals(1, service.getMeetingCount());
        assertTrue(service.findById(m.getId()).isPresent());
    }

    @Test
    @DisplayName("Rejects empty meeting name or invalid Google Meet URL")
    void testRejectsInvalidFields() {
        Meeting badName = new Meeting("", "https://meet.google.com/abc-defg-hij", "General", "", "");
        assertThrows(IllegalArgumentException.class, () -> service.addMeeting(badName));

        Meeting badUrl = new Meeting("Zoom Sync", "https://zoom.us/j/123", "General", "", "");
        assertThrows(IllegalArgumentException.class, () -> service.addMeeting(badUrl));
    }

    @Test
    @DisplayName("Detects duplicate meeting links")
    void testDuplicateDetection() throws IOException {
        Meeting m1 = new Meeting("Room A", "https://meet.google.com/abc-defg-hij", "Team", "", "");
        service.addMeeting(m1);

        assertTrue(service.findDuplicateByUrl("https://meet.google.com/abc-defg-hij", null).isPresent());
        assertFalse(service.findDuplicateByUrl("https://meet.google.com/abc-defg-hij", m1.getId()).isPresent());
    }

    @Test
    @DisplayName("Duplicates an existing meeting with distinct UUID and title")
    void testDuplicateMeeting() throws IOException {
        Meeting m = new Meeting("Client Room", "https://meet.google.com/cli-meet-xyz", "Clients", "Briefing", "");
        service.addMeeting(m);

        Meeting copy = service.duplicateMeeting(m.getId());
        assertEquals(2, service.getMeetingCount());
        assertNotEquals(m.getId(), copy.getId());
        assertEquals("Client Room (Copy)", copy.getName());
        assertEquals(m.getUrl(), copy.getUrl());
    }

    @Test
    @DisplayName("Toggles favorite and pins favorites to top")
    void testToggleFavorite() throws IOException {
        Meeting m1 = new Meeting("Alpha Meeting", "https://meet.google.com/aaa-bbbb-ccc", "General", "", "");
        Meeting m2 = new Meeting("Beta Meeting", "https://meet.google.com/ddd-eeee-fff", "General", "", "");
        service.addMeeting(m1);
        service.addMeeting(m2);

        // Initially m1 is first alphabetically
        assertEquals("Alpha Meeting", service.getAllMeetings().get(0).getName());

        // Star m2 as favorite
        service.toggleFavorite(m2.getId());

        // Now m2 must be first because it is starred
        assertEquals("Beta Meeting", service.getAllMeetings().get(0).getName());
        assertTrue(service.getAllMeetings().get(0).isFavorite());
    }

    @Test
    @DisplayName("Filters by favorites only")
    void testFavoritesOnlyFilter() throws IOException {
        Meeting m1 = new Meeting("Standup", "https://meet.google.com/aaa-bbbb-ccc", "Daily", "", "");
        Meeting m2 = new Meeting("Retro", "https://meet.google.com/ddd-eeee-fff", "Team", "", "");
        m2.setFavorite(true);
        service.addMeeting(m1);
        service.addMeeting(m2);

        List<Meeting> favs = service.filterAndSearch("", "All Categories", true);
        assertEquals(1, favs.size());
        assertEquals("Retro", favs.get(0).getName());
    }

    @Test
    @DisplayName("Filters and live searches meetings")
    void testFilterAndSearch() throws IOException {
        service.addMeeting(new Meeting("Alpha Standup", "https://meet.google.com/aaa-bbbb-ccc", "Engineering", "Morning sync", ""));
        service.addMeeting(new Meeting("Beta Review", "https://meet.google.com/ddd-eeee-fff", "Product", "Sprint demo", ""));

        List<Meeting> engOnly = service.filterAndSearch("", "Engineering");
        assertEquals(1, engOnly.size());
        assertEquals("Alpha Standup", engOnly.get(0).getName());

        List<Meeting> queryResult = service.filterAndSearch("demo", "All Categories");
        assertEquals(1, queryResult.size());
        assertEquals("Beta Review", queryResult.get(0).getName());
    }

    @Test
    @DisplayName("Deletes meeting cleanly")
    void testDeleteMeeting() throws IOException {
        Meeting m = new Meeting("Temp Meeting", "https://meet.google.com/abc-defg-hij", "General", "", "");
        service.addMeeting(m);
        assertEquals(1, service.getMeetingCount());

        boolean deleted = service.deleteMeeting(m.getId());
        assertTrue(deleted);
        assertEquals(0, service.getMeetingCount());
    }

    @Test
    @DisplayName("Tracks join count and updates lastJoinedAt timestamp")
    void testJoinTracking() throws IOException {
        Meeting m = new Meeting("Tracked Room", "https://meet.google.com/abc-defg-hij", "General", "", "");
        service.addMeeting(m);

        service.recordMeetingJoined(m.getId());
        Meeting refreshed = service.findById(m.getId()).orElseThrow();
        assertEquals(1, refreshed.getJoinCount());
        assertNotNull(refreshed.getLastJoinedAt());
    }
}
