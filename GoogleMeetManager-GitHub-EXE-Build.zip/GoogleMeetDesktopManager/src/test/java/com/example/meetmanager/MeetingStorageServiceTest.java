package com.example.meetmanager;

import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingStorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MeetingStorageServiceTest {

    @TempDir
    Path tempDir;

    private MeetingStorageService storageService;

    @BeforeEach
    void setUp() {
        storageService = new MeetingStorageService(tempDir);
    }

    @Test
    @DisplayName("Saves and reloads meeting records accurately via SQLite")
    void testSaveAndLoadMeetings() throws IOException {
        Meeting m1 = new Meeting("Weekly Sync", "https://meet.google.com/abc-defg-hij", "Team", "Sync meeting", "Check Jira");
        m1.setFavorite(true);
        m1.setScheduledTime("Every Mon 10:00 AM");

        Meeting m2 = new Meeting("Client Demo", "https://meet.google.com/xyz-uvwx-rst", "Clients", "Demo session", "Record");

        storageService.saveMeetings(Arrays.asList(m1, m2));

        List<Meeting> loaded = storageService.loadMeetings();
        assertEquals(2, loaded.size());
        // Favorite should be ordered first
        assertEquals("Weekly Sync", loaded.get(0).getName());
        assertTrue(loaded.get(0).isFavorite());
        assertEquals("Every Mon 10:00 AM", loaded.get(0).getScheduledTime());
        assertEquals("https://meet.google.com/abc-defg-hij", loaded.get(0).getUrl());

        assertEquals("Client Demo", loaded.get(1).getName());
        assertFalse(loaded.get(1).isFavorite());
    }

    @Test
    @DisplayName("Exports and imports Schema v2 cross-platform backup correctly")
    void testExportAndImportBackup() throws IOException {
        Meeting m = new Meeting("Standup", "https://meet.google.com/abc-defg-hij", "Daily", "", "");
        m.setScheduledTime("Daily 09:30 AM");
        m.setFavorite(true);
        File backupFile = tempDir.resolve("backup-v2.json").toFile();

        storageService.exportBackup(backupFile, List.of(m));
        assertTrue(backupFile.exists());

        String jsonContent = Files.readString(backupFile.toPath());
        assertTrue(jsonContent.contains("\"schemaVersion\": 2"));
        assertTrue(jsonContent.contains("exportTimestamp"));
        assertTrue(jsonContent.contains("Standup"));

        List<Meeting> imported = storageService.importBackup(backupFile);
        assertEquals(1, imported.size());
        assertEquals("Standup", imported.get(0).getName());
        assertTrue(imported.get(0).isFavorite());
        assertEquals("Daily 09:30 AM", imported.get(0).getScheduledTime());
    }

    @Test
    @DisplayName("Safely rejects corrupted or malformed backup files without crash")
    void testCorruptedBackupFileHandling() throws IOException {
        File corruptFile = tempDir.resolve("bad-backup.json").toFile();
        Files.writeString(corruptFile.toPath(), "{ this is not: [ valid json ... !! }");

        assertThrows(IOException.class, () -> storageService.importBackup(corruptFile));
    }
}
