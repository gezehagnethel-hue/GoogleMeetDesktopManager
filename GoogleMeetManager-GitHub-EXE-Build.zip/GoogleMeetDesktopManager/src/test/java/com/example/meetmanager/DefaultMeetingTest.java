package com.example.meetmanager;

import com.example.meetmanager.model.DefaultMeetingConfig;
import com.example.meetmanager.model.Meeting;
import com.example.meetmanager.service.MeetingService;
import com.example.meetmanager.service.MeetingStorageService;
import com.example.meetmanager.service.UrlValidationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class DefaultMeetingTest {

    @TempDir
    Path tempDir;

    private MeetingStorageService storageService;
    private MeetingService meetingService;

    @BeforeEach
    void setUp() throws IOException {
        storageService = new MeetingStorageService(tempDir);
        meetingService = new MeetingService(storageService);
    }

    @Test
    @DisplayName("DefaultMeetingConfig validates unconfigured vs configured state")
    void testDefaultMeetingConfigState() {
        DefaultMeetingConfig unconfigured = new DefaultMeetingConfig("", "");
        assertFalse(unconfigured.isConfigured());

        DefaultMeetingConfig invalid = new DefaultMeetingConfig("My Room", "not-a-url");
        assertFalse(invalid.isConfigured());

        DefaultMeetingConfig valid = new DefaultMeetingConfig("Daily Standup", "https://meet.google.com/abc-defg-hij");
        assertTrue(valid.isConfigured());
        assertEquals("Daily Standup", valid.getTitle());
        assertEquals("https://meet.google.com/abc-defg-hij", valid.getUrl());
        assertEquals("abc-defg-hij", valid.getFormattedCode());
    }

    @Test
    @DisplayName("Saves, persists, and loads default meeting in SQLite app_settings")
    void testSaveAndLoadDefaultMeeting() {
        DefaultMeetingConfig initial = storageService.getDefaultMeeting();
        assertNotNull(initial);
        assertFalse(initial.isConfigured());

        DefaultMeetingConfig config = new DefaultMeetingConfig("Main Scrum Room", "https://meet.google.com/xyz-uvwx-rst");
        storageService.saveDefaultMeeting(config);

        DefaultMeetingConfig loaded = storageService.getDefaultMeeting();
        assertNotNull(loaded);
        assertTrue(loaded.isConfigured());
        assertEquals("Main Scrum Room", loaded.getTitle());
        assertEquals("https://meet.google.com/xyz-uvwx-rst", loaded.getUrl());
    }

    @Test
    @DisplayName("MeetingService validates URL before saving default meeting")
    void testMeetingServiceValidation() {
        // Invalid URL should throw IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            meetingService.saveDefaultMeeting("Bad Link", "http://insecure-meet.com");
        });

        // Valid URL should succeed
        meetingService.saveDefaultMeeting("Team Sprint Room", "https://meet.google.com/aaa-bbbb-ccc");
        DefaultMeetingConfig active = meetingService.getDefaultMeeting();
        assertTrue(active.isConfigured());
        assertEquals("Team Sprint Room", active.getTitle());
        assertEquals("https://meet.google.com/aaa-bbbb-ccc", active.getUrl());
    }

    @Test
    @DisplayName("Recording default meeting join updates timestamp and join count")
    void testRecordDefaultMeetingJoined() {
        meetingService.saveDefaultMeeting("Sprint Retrospective", "https://meet.google.com/ret-rosp-ect");
        assertEquals(0, meetingService.getDefaultMeeting().getJoinCount());

        meetingService.recordDefaultMeetingJoined();
        DefaultMeetingConfig afterFirst = meetingService.getDefaultMeeting();
        assertEquals(1, afterFirst.getJoinCount());
        assertNotNull(afterFirst.getLastJoinedAt());

        meetingService.recordDefaultMeetingJoined();
        DefaultMeetingConfig afterSecond = meetingService.getDefaultMeeting();
        assertEquals(2, afterSecond.getJoinCount());
    }
}
