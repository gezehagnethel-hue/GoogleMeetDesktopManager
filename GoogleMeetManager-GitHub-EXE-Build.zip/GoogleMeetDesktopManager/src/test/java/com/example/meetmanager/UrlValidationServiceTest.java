package com.example.meetmanager;

import com.example.meetmanager.service.UrlValidationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class UrlValidationServiceTest {

    private UrlValidationService validator;

    @BeforeEach
    void setUp() {
        validator = new UrlValidationService();
    }

    @Test
    @DisplayName("Accepts valid standard Google Meet URL")
    void testValidStandardMeetUrl() {
        UrlValidationService.ValidationResult result = validator.validate("https://meet.google.com/abc-defg-hij");
        assertTrue(result.isValid(), "Standard Google Meet URL should be valid");
        assertEquals("https://meet.google.com/abc-defg-hij", result.getNormalizedUrl());
        assertEquals("abc-defg-hij", result.getMeetingCode());
    }

    @Test
    @DisplayName("Accepts Google Meet URL with query parameters")
    void testValidMeetUrlWithQuery() {
        UrlValidationService.ValidationResult result = validator.validate("https://meet.google.com/abc-defg-hij?authuser=1&hs=179");
        assertTrue(result.isValid());
        assertTrue(result.getNormalizedUrl().contains("authuser=1"));
    }

    @Test
    @DisplayName("Convenience: automatically expands raw meeting code to full HTTPS URL")
    void testExpandsRawMeetingCode() {
        UrlValidationService.ValidationResult result = validator.validate("xyz-uvwx-rst");
        assertTrue(result.isValid());
        assertEquals("https://meet.google.com/xyz-uvwx-rst", result.getNormalizedUrl());
        assertEquals("xyz-uvwx-rst", result.getMeetingCode());
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "http://meet.google.com/abc-defg-hij", // Insecure HTTP
            "https://zoom.us/j/123456789",          // Non-Google Meet host
            "https://google.com/meeting",          // google.com without meet subdomain
            "https://phishing-meet.google.com/abc",// Subdomain spoof
            "javascript:alert(1)",                 // Script injection
            "file:///C:/Windows/System32",         // File protocol
            "ftp://meet.google.com/abc-defg-hij",  // FTP protocol
            "https://meet.google.com/",            // Missing meeting code
            "",                                    // Empty
            "   ",                                 // Whitespace
            "https://meet.google.com/abc; calc.exe"// Command injection attempt
    })
    @DisplayName("Strictly rejects invalid or unsafe URLs")
    void testRejectsInvalidUrls(String invalidUrl) {
        UrlValidationService.ValidationResult result = validator.validate(invalidUrl);
        assertFalse(result.isValid(), "URL should be rejected: " + invalidUrl);
        assertNotNull(result.getMessage());
    }
}
