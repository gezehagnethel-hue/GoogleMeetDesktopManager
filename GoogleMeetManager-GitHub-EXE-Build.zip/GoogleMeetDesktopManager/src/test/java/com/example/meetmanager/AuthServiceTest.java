package com.example.meetmanager;

import com.example.meetmanager.model.User;
import com.example.meetmanager.model.UserRole;
import com.example.meetmanager.service.AuthService;
import com.example.meetmanager.service.MeetingStorageService;
import com.example.meetmanager.util.PasswordSecurityUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class AuthServiceTest {

    @TempDir
    Path tempDir;

    private MeetingStorageService storageService;
    private AuthService authService;

    @BeforeEach
    void setUp() throws IOException {
        storageService = new MeetingStorageService(tempDir);
        authService = new AuthService(storageService);
    }

    @Test
    @DisplayName("PasswordSecurityUtil produces distinct salts and validates hashes")
    void testPasswordSecurityUtil() {
        String salt1 = PasswordSecurityUtil.generateSalt();
        String salt2 = PasswordSecurityUtil.generateSalt();
        assertNotNull(salt1);
        assertNotNull(salt2);
        assertNotEquals(salt1, salt2);

        char[] pass = "SecretP@ssw0rd!".toCharArray();
        String hash = PasswordSecurityUtil.hashPassword(pass, salt1);
        assertNotNull(hash);

        assertTrue(PasswordSecurityUtil.verifyPassword("SecretP@ssw0rd!".toCharArray(), hash, salt1));
        assertFalse(PasswordSecurityUtil.verifyPassword("WrongPassword".toCharArray(), hash, salt1));
        assertFalse(PasswordSecurityUtil.verifyPassword("SecretP@ssw0rd!".toCharArray(), hash, salt2));
    }

    @Test
    @DisplayName("Email validation strictly validates addresses")
    void testEmailValidation() {
        assertTrue(PasswordSecurityUtil.isValidEmail("admin@meetmanager.com"));
        assertTrue(PasswordSecurityUtil.isValidEmail("john.doe@company.co.uk"));
        assertFalse(PasswordSecurityUtil.isValidEmail("plainaddress"));
        assertFalse(PasswordSecurityUtil.isValidEmail("@missingusername.com"));
        assertFalse(PasswordSecurityUtil.isValidEmail("user@.com"));
        assertFalse(PasswordSecurityUtil.isValidEmail(""));
        assertFalse(PasswordSecurityUtil.isValidEmail(null));
    }

    @Test
    @DisplayName("Initializes and seeds default Admin and Client accounts")
    void testDefaultAccountsSeeded() {
        List<User> users = authService.getAllUsers();
        assertTrue(users.size() >= 2);

        Optional<User> adminOpt = storageService.findUserByEmail("admin@meetmanager.com");
        assertTrue(adminOpt.isPresent());
        User admin = adminOpt.get();
        assertEquals(UserRole.ADMIN, admin.getRole());
        assertTrue(admin.isAdmin());

        Optional<User> clientOpt = storageService.findUserByEmail("client@company.com");
        assertTrue(clientOpt.isPresent());
        User client = clientOpt.get();
        assertEquals(UserRole.CLIENT, client.getRole());
        assertTrue(client.isClient());
    }

    @Test
    @DisplayName("Login rejects empty and invalid credentials")
    void testLoginValidationFailures() {
        // Empty email
        AuthService.AuthResult res1 = authService.login("", "SomePass".toCharArray(), false);
        assertFalse(res1.isSuccess());
        assertNotNull(res1.getErrorMessage());

        // Malformed email
        AuthService.AuthResult res2 = authService.login("not-an-email", "SomePass".toCharArray(), false);
        assertFalse(res2.isSuccess());

        // Non-existent user
        AuthService.AuthResult res3 = authService.login("unknown@domain.com", "Password123!".toCharArray(), false);
        assertFalse(res3.isSuccess());
        assertEquals("Invalid email or password. Please verify your credentials.", res3.getErrorMessage());

        // Wrong password
        AuthService.AuthResult res4 = authService.login("admin@meetmanager.com", "WrongPassword123!".toCharArray(), false);
        assertFalse(res4.isSuccess());
        assertEquals("Invalid email or password. Please verify your credentials.", res4.getErrorMessage());
    }

    @Test
    @DisplayName("Successful Admin login creates session and updates state")
    void testSuccessfulAdminLogin() {
        assertFalse(authService.isAuthenticated());

        AuthService.AuthResult res = authService.login("admin@meetmanager.com", "AdminPassword123!".toCharArray(), true);
        assertTrue(res.isSuccess());
        assertNotNull(res.getUser());
        assertEquals("admin@meetmanager.com", res.getUser().getEmail());
        assertTrue(res.getUser().isAdmin());

        assertTrue(authService.isAuthenticated());
        assertTrue(authService.isAdmin());
        assertFalse(authService.isClient());
        assertEquals("admin@meetmanager.com", authService.getCurrentUser().getEmail());
    }

    @Test
    @DisplayName("Successful Client login sets CLIENT role")
    void testSuccessfulClientLogin() {
        AuthService.AuthResult res = authService.login("client@company.com", "ClientPassword123!".toCharArray(), false);
        assertTrue(res.isSuccess());
        assertTrue(authService.isAuthenticated());
        assertTrue(authService.isClient());
        assertFalse(authService.isAdmin());
    }

    @Test
    @DisplayName("Remember Me restores session between application restarts")
    void testRememberMeSessionRestoration() {
        // Sign in with rememberMe = true
        AuthService.AuthResult res = authService.login("admin@meetmanager.com", "AdminPassword123!".toCharArray(), true);
        assertTrue(res.isSuccess());

        // Simulate app restart with a fresh AuthService instance pointing to same storage
        AuthService restartAuthService = new AuthService(storageService);
        assertFalse(restartAuthService.isAuthenticated());

        boolean restored = restartAuthService.restoreRememberedSession();
        assertTrue(restored);
        assertTrue(restartAuthService.isAuthenticated());
        assertEquals("admin@meetmanager.com", restartAuthService.getCurrentUser().getEmail());
    }

    @Test
    @DisplayName("Logout clears session and revokes remembered credentials")
    void testLogoutClearsSession() {
        authService.login("admin@meetmanager.com", "AdminPassword123!".toCharArray(), true);
        assertTrue(authService.isAuthenticated());

        authService.logout();
        assertFalse(authService.isAuthenticated());
        assertNull(authService.getCurrentUser());

        // Cannot restore remembered session after logout
        AuthService restartAuthService = new AuthService(storageService);
        assertFalse(restartAuthService.restoreRememberedSession());
    }

    @Test
    @DisplayName("Administrator can provision new Client and Admin accounts")
    void testUserManagementCreationAndDeletion() throws SQLException {
        // Authenticate as Admin
        authService.login("admin@meetmanager.com", "AdminPassword123!".toCharArray(), false);

        // Create new Client
        User created = authService.createUser(
                "newclient@clientcompany.com",
                "New Client User",
                "SecurePass123!".toCharArray(),
                UserRole.CLIENT
        );
        assertNotNull(created);
        assertEquals("newclient@clientcompany.com", created.getEmail());
        assertEquals(UserRole.CLIENT, created.getRole());

        // Test logging in with newly created client account
        AuthService clientAuth = new AuthService(storageService);
        AuthService.AuthResult clientLogin = clientAuth.login(
                "newclient@clientcompany.com",
                "SecurePass123!".toCharArray(),
                false
        );
        assertTrue(clientLogin.isSuccess());
        assertTrue(clientAuth.isClient());

        // Admin resets password
        authService.resetUserPassword(created.getId(), "NewPassword456!".toCharArray());

        // Old password fails, new succeeds
        AuthService clientAuth2 = new AuthService(storageService);
        assertFalse(clientAuth2.login("newclient@clientcompany.com", "SecurePass123!".toCharArray(), false).isSuccess());
        assertTrue(clientAuth2.login("newclient@clientcompany.com", "NewPassword456!".toCharArray(), false).isSuccess());

        // Admin deletes user
        authService.deleteUser(created.getId());
        assertFalse(storageService.findUserByEmail("newclient@clientcompany.com").isPresent());
    }
}
