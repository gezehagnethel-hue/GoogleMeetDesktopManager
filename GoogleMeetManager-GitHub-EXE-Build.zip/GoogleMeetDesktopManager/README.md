# Google Meet Desktop Manager

> **Window Title:** My Meeting Center  
> **Target OS:** Windows 10 & Windows 11 (64-bit)  
> **Platform:** Java 17+ LTS, Java Swing, Maven, jpackage

---

## 1. Project Overview

**Google Meet Desktop Manager** is an independent, production-grade desktop utility that allows professionals, remote teams, educators, and clients to organize and launch multiple permanent Google Meet URLs through a clean desktop interface.

Each saved meeting has its own dedicated **Join Meeting** button. When clicked, the application opens that exact meeting URL directly in the user's default Windows web browser.

> **Important Notice:** This application is a meeting-link launcher and manager. It does not host video streams, capture video calls, or bypass Google authentication, waiting rooms, or host admission controls. It is an independent utility and is not an official Google product.

---

## 2. Key Features

- **Dedicated Join Buttons**: Every meeting has its own prominent Join button that launches its specific URL.
- **1-Interface Multi-Button Pad & Cards View**: Switch between an ultra-clean speed dial board with tactile buttons or a detailed cards list.
- **Favorites & Scheduling**: Star/pin critical meeting buttons to the top, and track optional scheduled times.
- **One-Click Duplication**: Duplicate existing rooms with new UUIDs for recurring variants.
- **Strict URL & Scheme Validation**: Validates that links strictly use `https://meet.google.com/xxx-yyyy-zzz`, preventing invalid hosts, phishing, or malicious command execution.
- **Transactional SQLite Local Storage**: Records are safely stored in `%APPDATA%\GoogleMeetDesktopManager\meetings.db` with indexed ACID transactions and zero cloud dependency.
- **Cross-Platform Schema v2 Backup & Restore**: Export and restore meeting backups in standardized JSON Schema v2, compatible with the native Android app.
- **Fast Live Search & Category Filtering**: Instantly search by meeting name, room code, description, or notes, or filter by category (e.g. Daily Standup, Team Sync, Clients, 1-on-1s).
- **High-DPI & Modern Swing Styling**: Styled with FlatLaf for a clean Windows 11 light appearance, crisp Segoe UI typography, and responsive grid/list cards.

---

## 3. Project Architecture

The codebase follows strict separation of concerns:

```
GoogleMeetDesktopManager/
├── pom.xml                                      # Maven build file with Java 17 compiler and shaded JAR config
├── README.md                                    # Complete documentation and user manual
├── run.bat                                      # Quick local development runner for Windows
├── build-installer.bat                          # Batch script for Maven + jpackage EXE installer
├── build-installer.ps1                          # PowerShell script for automated Windows packaging
└── src/
    ├── main/
    │   ├── java/com/example/meetmanager/
    │   │   ├── Main.java                        # Application entry point & Look-and-Feel initializer
    │   │   ├── model/
    │   │   │   └── Meeting.java                 # Meeting data model & serialization logic
    │   │   ├── service/
    │   │   │   ├── MeetingService.java          # Core business logic, event listeners, & search filter
    │   │   │   ├── MeetingStorageService.java   # Atomic JSON persistence & backup/restore
    │   │   │   └── UrlValidationService.java    # Strict HTTPS and meet.google.com validator
    │   │   ├── ui/
    │   │   │   ├── MainWindow.java              # "My Meeting Center" main Swing dashboard
    │   │   │   ├── MeetingCard.java             # Individual card component with dedicated launcher button
    │   │   │   ├── MeetingDialog.java           # Add/Edit modal dialog with validation
    │   │   │   ├── SettingsDialog.java          # Data folder, storage path, & backup/restore actions
    │   │   │   └── AboutDialog.java             # Version details and disclaimer
    │   │   └── util/
    │   │       ├── BrowserUtil.java             # Safe desktop browser opening with Windows fallbacks
    │   │       └── ClipboardUtil.java           # Native Windows clipboard integration
    │   └── resources/
    │       └── icons/                           # UI assets and iconography
    └── test/
        └── java/com/example/meetmanager/
            ├── UrlValidationServiceTest.java    # Unit tests for URL validation and security
            ├── MeetingStorageServiceTest.java   # Tests for JSON storage and file recovery
            └── MeetingServiceTest.java          # Tests for add, edit, delete, and search filtering
```

---

## 4. Prerequisites

To build and run this application on Windows 10 or 11, install:

1. **Java Development Kit (JDK 17 LTS or 21 LTS)**:
   - Download Eclipse Temurin JDK from [https://adoptium.net/](https://adoptium.net/)
   - During installation, check the box: **"Set JAVA_HOME variable"** and **"Add to PATH"**.
2. **Apache Maven (3.8.0 or newer)**:
   - Download from [https://maven.apache.org/download.cgi](https://maven.apache.org/download.cgi) and add its `bin` directory to your `PATH`.
3. **WiX Toolset v3.11** *(Required only for building `.exe` or `.msi` installers with `jpackage`)*:
   - Download from [https://wixtoolset.org/releases/](https://wixtoolset.org/releases/)
   - Add WiX directory (`C:\Program Files (x86)\WiX Toolset v3.11\bin`) to your Windows `PATH`.

---

## 5. Development & Running Locally

### Using Windows Command Prompt (`cmd.exe`):

```cmd
:: 1. Navigate to the project root
cd GoogleMeetDesktopManager

:: 2. Verify Java and Maven
javac -version
mvn -version

:: 3. Run the development runner
run.bat
```

Or run via Maven directly:

```cmd
mvn clean compile exec:java -Dexec.mainClass="com.example.meetmanager.Main"
```

### Using Windows PowerShell (`powershell.exe`):

```powershell
Set-Location GoogleMeetDesktopManager
mvn clean compile exec:java -Dexec.mainClass="com.example.meetmanager.Main"
```

---

## 6. Running Automated Tests

Run the full JUnit 5 test suite to verify URL validation, storage persistence, and business logic:

```cmd
mvn clean test
```

Expected output:
```
[INFO] Running com.example.meetmanager.UrlValidationServiceTest
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0
[INFO] Running com.example.meetmanager.MeetingStorageServiceTest
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0
[INFO] Running com.example.meetmanager.MeetingServiceTest
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

---

## 7. Packaging the Standalone Fat JAR

To generate a single, runnable executable JAR with all dependencies bundled:

```cmd
mvn clean package
```

The resulting JAR will be created at:
`target\google-meet-desktop-manager-1.0.0.jar`

You can run it directly:
```cmd
java -jar target\google-meet-desktop-manager-1.0.0.jar
```

---

## 8. Building the Native Windows Installer (.EXE)

The application includes automated scripts to package a standalone Windows installer using JDK's `jpackage`. This bundles a dedicated runtime environment so end-users **do not need Java installed** on their Windows computers.

### Automated Packaging:
Double-click `build-installer.bat` or run in Command Prompt:

```cmd
build-installer.bat
```

Or in Windows PowerShell:

```powershell
.\build-installer.ps1
```

### Manual `jpackage` Command:

```cmd
:: 1. Build the shaded JAR
mvn clean package -DskipTests=false

:: 2. Create the distribution folder
mkdir dist
copy target\google-meet-desktop-manager-1.0.0.jar dist\google-meet-desktop-manager.jar

:: 3. Generate the Windows EXE installer
jpackage ^
  --input dist ^
  --name "GoogleMeetDesktopManager" ^
  --main-jar "google-meet-desktop-manager.jar" ^
  --main-class com.example.meetmanager.Main ^
  --type exe ^
  --app-version "1.0.0" ^
  --vendor "Independent Launcher" ^
  --description "Google Meet Desktop Manager - Permanent Meeting Link Launcher" ^
  --win-menu ^
  --win-menu-group "Google Meet Desktop Manager" ^
  --win-shortcut ^
  --win-dir-chooser ^
  --dest installer-output
```

The generated installer will be located in:
`installer-output\GoogleMeetDesktopManager-1.0.0.exe`

### What the Installer Does:
- Installs the application to `C:\Program Files\GoogleMeetDesktopManager` (or custom folder selected by the user).
- Creates a Desktop shortcut.
- Creates a Start Menu entry under "Google Meet Desktop Manager".
- Registers an entry in Windows **Apps & features** (Settings > Apps) for 1-click uninstallation.
- Bundles a private Java runtime image (no external JRE dependency).

---

## 9. Meeting Data Storage & Backup

### Data Storage Location:
On Windows 10 and 11, data is stored in your roaming app data directory:
```
%APPDATA%\GoogleMeetDesktopManager\meetings.json
```
(Full path: `C:\Users\<YourUsername>\AppData\Roaming\GoogleMeetDesktopManager\meetings.json`)

### Atomic File Write Protection:
Whenever a meeting is added, edited, or deleted, the application writes the updated records to `meetings.json.tmp` first, then atomically replaces `meetings.json`. This guarantees zero data loss even if the PC loses power during a save operation.

### Backup and Restore:
1. Open **Settings & Local Storage...** from the toolbar or File menu.
2. Click **Export Backup (JSON)...** to save your meeting collection to any folder, USB flash drive, or cloud drive.
3. Click **Restore from Backup (JSON)...** to load meetings on a new computer. You can choose to **Merge** with existing meetings or **Replace All**.

---

## 10. Enterprise Authentication, Roles & Login Screen

### 10.1 Login Screen Design & Capabilities
When launched, unauthenticated users are presented with a modern, split-view Login Page:
- **Left Panel**: Google Meet Manager corporate branding, custom vector video conference illustration with active speaker indicators, feature summaries, and enterprise security badge.
- **Right Panel**: Elevated white card with email input, password input with show/hide toggle, Remember Me persistence, Forgot Password dialog, prominent Sign In button, and Contact Administrator assistance.

### 10.2 Default Accounts (Pre-Seeded in Offline SQLite)
Upon initial launch with a new database, two pre-configured accounts are initialized with salted PBKDF2 hashes:
1. **System Administrator**:
   - **Email:** `admin@meetmanager.com`
   - **Password:** `AdminPassword123!`
   - **Role:** `ADMIN` (Full administrative control, user provisioning, database configuration, backup/restore, meeting batch creation).
2. **Demo Client Member**:
   - **Email:** `client@company.com`
   - **Password:** `ClientPassword123!`
   - **Role:** `CLIENT` (Dedicated client workspace, 1-click meeting join, launchboard view, consent-based audio recording).

### 10.3 Password Security & PBKDF2-HMAC-SHA256
- Passwords are **never stored in plaintext**.
- Stored using NIST-standard **PBKDF2WithHmacSHA256** with **65,536 iterations**, a 256-bit derived key length, and unique 16-byte cryptographically secure random salts (`SecureRandom`).
- Password validation uses **constant-time byte comparison** (`MessageDigest.isEqual`) to prevent side-channel timing attacks.

### 10.4 Session Handling & Remember Me
- When **Remember Me** is checked, an opaque UUID session token is stored in the local SQLite `auth_sessions` table with a 30-day validity window.
- When the user restarts the app, `authService.restoreRememberedSession()` safely validates the token and logs the user directly into their authorized dashboard without prompting for credentials.
- When the user clicks **Sign Out (🚪 Sign Out)**, active session tokens are revoked, the remembered state is purged, and the application returns smoothly to the Login Page.

### 10.5 Administrator Provisioning & User Management
Administrators can create client accounts for team members directly from the UI:
1. Sign in as an Administrator (`admin@meetmanager.com`).
2. Click **👥 Users** in the top header or select **File > User Management & Roles...**.
3. Click **+ Add User** and enter the client's full name, email address, role (`CLIENT` or `ADMIN`), and initial password.
4. Administrators can also reset forgotten user passwords and manage active team accounts.

---

## 11. Security & Privacy Guarantees

- **No Secrets Stored**: The application never prompts for, stores, or transmits your Google account password, Google session cookies, or OAuth tokens.
- **Strict Host Verification**: Only `meet.google.com` links over `https://` are accepted. URLs attempting schemes like `file://`, `javascript:`, or third-party web addresses are rejected immediately.
- **Safe Browser Launch**: URLs are opened strictly via the operating system's registered browser handler, preventing command injection or terminal argument tampering.
- **Zero Cloud Telemetry**: All user accounts, meeting records, audio recordings, and credentials stay 100% locally on your machine in encrypted/hashed SQLite storage.

---

## 12. Troubleshooting

| Issue | Cause | Solution |
|---|---|---|
| `'jpackage' is not recognized` | JAVA_HOME does not point to a full JDK 17+ or bin is not in PATH | Install Eclipse Temurin JDK 17+ and ensure `C:\Program Files\Eclipse Adoptium\jdk-17...\bin` is in Windows PATH. |
| `Cannot find candle.exe / light.exe` | WiX Toolset 3.11 is missing when running `jpackage --type exe` | Install WiX Toolset 3.11 from wixtoolset.org, or let the script fallback to portable `--type app-image`. |
| Browser does not open on click | Default Windows browser association is missing or blocked | Check Windows Settings > Apps > Default apps > Web browser, and confirm Chrome/Edge/Firefox is set as default. |
| URL rejected as invalid | Protocol missing or host is not meet.google.com | Enter full URL starting with `https://meet.google.com/` (or enter just the meeting code `xxx-yyyy-zzz`). |
| "Invalid email or password" | Credentials do not match stored PBKDF2 hash | Use `admin@meetmanager.com` / `AdminPassword123!` for admin, or contact administrator to reset your password. |

