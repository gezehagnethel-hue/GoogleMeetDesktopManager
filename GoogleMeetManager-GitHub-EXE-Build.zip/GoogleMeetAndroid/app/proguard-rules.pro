# Proguard rules for Google Meet Desktop & Mobile Manager
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class com.example.meetmanager.model.** { *; }
-keep class com.example.meetmanager.data.local.** { *; }
-keep class com.example.meetmanager.data.backup.** { *; }
