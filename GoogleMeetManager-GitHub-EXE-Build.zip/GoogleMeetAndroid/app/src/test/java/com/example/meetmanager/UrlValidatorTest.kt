package com.example.meetmanager

import com.example.meetmanager.util.UrlValidator
import org.junit.Assert.*
import org.junit.Test

class UrlValidatorTest {

    @Test
    fun validStandardUrl_returnsSuccess() {
        val res = UrlValidator.validate("https://meet.google.com/abc-defg-hij")
        assertTrue(res.isValid)
        assertEquals("https://meet.google.com/abc-defg-hij", res.normalizedUrl)
        assertEquals("abc-defg-hij", res.code)
    }

    @Test
    fun rawCode_autoFormatsToHttps() {
        val res = UrlValidator.validate("abc-defg-hij")
        assertTrue(res.isValid)
        assertEquals("https://meet.google.com/abc-defg-hij", res.normalizedUrl)
    }

    @Test
    fun invalidHost_rejected() {
        val res = UrlValidator.validate("https://zoom.us/j/123456")
        assertFalse(res.isValid)
        assertTrue(res.message.contains("Only meet.google.com is supported") || res.message.contains("Unrelated host"))
    }

    @Test
    fun insecureHttp_rejected() {
        val res = UrlValidator.validate("http://meet.google.com/abc-defg-hij")
        assertFalse(res.isValid)
        assertTrue(res.message.contains("HTTPS") || res.message.contains("Insecure"))
    }

    @Test
    fun emptyInput_rejected() {
        val res = UrlValidator.validate("")
        assertFalse(res.isValid)
    }
}
