package com.example.meetmanager

import com.example.meetmanager.model.DefaultMeetingConfig
import com.example.meetmanager.util.UrlValidator
import org.junit.Assert.*
import org.junit.Test

class DefaultMeetingTest {

    @Test
    fun defaultMeetingConfig_unconfiguredByDefault() {
        val config = DefaultMeetingConfig()
        assertFalse(config.isConfigured())
        assertEquals("Primary Google Meet", config.title)
        assertEquals("", config.url)
        assertEquals(0, config.joinCount)
    }

    @Test
    fun defaultMeetingConfig_configuredStateAndCodeExtraction() {
        val config = DefaultMeetingConfig(
            title = "Engineering Standup",
            url = "https://meet.google.com/abc-defg-hij"
        )
        assertTrue(config.isConfigured())
        assertEquals("Engineering Standup", config.title)
        assertEquals("https://meet.google.com/abc-defg-hij", config.url)
        assertEquals("abc-defg-hij", config.getFormattedCode())
    }

    @Test
    fun defaultMeetingConfig_handlesQueryParametersInCodeExtraction() {
        val config = DefaultMeetingConfig(
            title = "Client Sync",
            url = "https://meet.google.com/xyz-uvwx-rst?authuser=2&hs=179"
        )
        assertTrue(config.isConfigured())
        assertEquals("xyz-uvwx-rst", config.getFormattedCode())
    }

    @Test
    fun urlValidator_strictlyValidatesGoogleMeetLinks() {
        // Valid HTTPS Google Meet links
        val valid1 = UrlValidator.validate("https://meet.google.com/abc-defg-hij")
        assertTrue(valid1.isValid)
        assertEquals("https://meet.google.com/abc-defg-hij", valid1.normalizedUrl)

        val valid2 = UrlValidator.validate("meet.google.com/xyz-uvwx-rst")
        assertTrue(valid2.isValid)
        assertEquals("https://meet.google.com/xyz-uvwx-rst", valid2.normalizedUrl)

        // Invalid domains
        val invalidDomain = UrlValidator.validate("https://fake-meet.google.com.attacker.com/abc-defg-hij")
        assertFalse(invalidDomain.isValid)

        // Invalid format
        val invalidCode = UrlValidator.validate("https://meet.google.com/toolongorinvalidcode")
        assertFalse(invalidCode.isValid)

        // Empty URL
        val emptyUrl = UrlValidator.validate("")
        assertFalse(emptyUrl.isValid)
    }
}
