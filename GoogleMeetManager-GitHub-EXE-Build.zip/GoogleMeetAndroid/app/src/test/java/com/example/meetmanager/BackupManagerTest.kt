package com.example.meetmanager

import com.example.meetmanager.model.Meeting
import com.example.meetmanager.util.UrlValidator
import com.google.gson.Gson
import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class BackupManagerTest {

    private val gson = Gson()

    @Test
    fun serializeAndDeserialize_schemaV2Envelope() {
        val meeting = Meeting(
            id = "test-uuid-1",
            name = "Sprint Sync",
            url = "https://meet.google.com/abc-defg-hij",
            category = "Daily Standup",
            favorite = true,
            scheduledTime = "10:00 AM"
        )

        val json = """
            {
              "schemaVersion": 2,
              "exportTimestamp": 1729432000000,
              "appName": "Google Meet Desktop & Mobile Manager",
              "records": [
                {
                  "id": "test-uuid-1",
                  "name": "Sprint Sync",
                  "url": "https://meet.google.com/abc-defg-hij",
                  "category": "Daily Standup",
                  "favorite": true,
                  "scheduledTime": "10:00 AM"
                }
              ]
            }
        """.trimIndent()

        val root = JsonParser.parseString(json).asJsonObject
        assertEquals(2, root.get("schemaVersion").asInt)
        assertTrue(root.has("records"))

        val recordsArray = root.getAsJsonArray("records")
        assertEquals(1, recordsArray.size())

        val recordObj = recordsArray[0].asJsonObject
        val parsedUrl = recordObj.get("url").asString
        assertTrue(UrlValidator.validate(parsedUrl).isValid)
    }

    @Test
    fun malformedJson_safelyDetected() {
        val malformed = "{ invalid json data :: "
        assertThrows(Exception::class.java) {
            JsonParser.parseString(malformed)
        }
    }
}
