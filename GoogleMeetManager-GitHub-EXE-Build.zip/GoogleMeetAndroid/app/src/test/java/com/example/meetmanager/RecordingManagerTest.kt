package com.example.meetmanager

import com.example.meetmanager.model.RecordingMetadata
import org.junit.Assert.*
import org.junit.Test

class RecordingManagerTest {

    @Test
    fun recordingMetadata_durationFormatting() {
        val shortRec = RecordingMetadata(
            id = "rec-1",
            meetingTitle = "Standup",
            filename = "GoogleMeet_Standup.m4a",
            filePath = "/path/GoogleMeet_Standup.m4a",
            startTime = 1000L,
            durationMs = 65000L, // 1 min 5 secs
            sizeBytes = 204800L,
            isMicOnly = true,
            consentConfirmed = true
        )
        assertEquals("01:05", shortRec.getFormattedDuration())
        assertEquals("200.0 KB", shortRec.getFormattedSize())
        assertTrue(shortRec.isMicOnly)
        assertTrue(shortRec.consentConfirmed)

        val longRec = RecordingMetadata(
            id = "rec-2",
            meetingTitle = "Townhall",
            filename = "GoogleMeet_Townhall.m4a",
            filePath = "/path/GoogleMeet_Townhall.m4a",
            startTime = 1000L,
            durationMs = 3665000L, // 1 hr 1 min 5 secs
            sizeBytes = 15728640L, // ~15 MB
            isMicOnly = true,
            consentConfirmed = true
        )
        assertEquals("01:01:05", longRec.getFormattedDuration())
        assertEquals("15.00 MB", longRec.getFormattedSize())
    }

    @Test
    fun recordingMetadata_explicitConsentRequirement() {
        val rec = RecordingMetadata(
            id = "rec-3",
            meetingTitle = "Board Meeting",
            filename = "GoogleMeet_Board.m4a",
            filePath = "/path/GoogleMeet_Board.m4a",
            startTime = 5000L,
            durationMs = 120000L,
            sizeBytes = 1024000L,
            isMicOnly = true,
            consentConfirmed = true
        )
        assertTrue("Consent must be verified", rec.consentConfirmed)
        assertTrue("Android mobile recordings must be explicitly documented as 1-sided mic only", rec.isMicOnly)
    }

    @Test
    fun audioPlaybackCapture_limitationsDocumentation() {
        // Test that the audio limitation explanation properly clarifies VoIP limitations
        val explanation = "Under Android 10+ (API 29+), AudioPlaybackCapture is restricted by the OS. " +
                "Google Meet uses USAGE_VOICE_COMMUNICATION, which explicitly sets capture policy " +
                "to ALLOW_CAPTURE_BY_NONE or ALLOW_CAPTURE_BY_SYSTEM to protect participant confidentiality. " +
                "Therefore, third-party mobile apps are restricted to local microphone audio only (1-sided). " +
                "For full 2-sided meetings with all participant voices, use Google Meet's built-in cloud recording."

        assertTrue(explanation.contains("USAGE_VOICE_COMMUNICATION"))
        assertTrue(explanation.contains("1-sided"))
        assertTrue(explanation.contains("Google Meet's built-in cloud recording"))
    }
}
