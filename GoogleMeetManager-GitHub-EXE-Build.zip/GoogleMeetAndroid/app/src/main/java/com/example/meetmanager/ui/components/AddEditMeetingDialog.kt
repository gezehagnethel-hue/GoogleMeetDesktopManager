package com.example.meetmanager.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.meetmanager.model.Meeting
import com.example.meetmanager.util.UrlValidator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMeetingDialog(
    existingMeeting: Meeting?,
    onDismiss: () -> Unit,
    onSave: (name: String, url: String, category: String, desc: String, notes: String, schedule: String, fav: Boolean) -> Unit
) {
    var name by remember { mutableStateOf(existingMeeting?.name ?: "") }
    var url by remember { mutableStateOf(existingMeeting?.url ?: "https://meet.google.com/") }
    var category by remember { mutableStateOf(existingMeeting?.category ?: "General") }
    var description by remember { mutableStateOf(existingMeeting?.description ?: "") }
    var notes by remember { mutableStateOf(existingMeeting?.notes ?: "") }
    var scheduledTime by remember { mutableStateOf(existingMeeting?.scheduledTime ?: "") }
    var favorite by remember { mutableStateOf(existingMeeting?.favorite ?: false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = if (existingMeeting == null) "Add Meeting Button" else "Edit Meeting Button",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Permanent URLs are saved offline. An internet connection is required to join a call.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Button Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Google Meet URL *") },
                    singleLine = true,
                    placeholder = { Text("https://meet.google.com/xxx-yyyy-zzz") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = scheduledTime,
                    onValueChange = { scheduledTime = it },
                    label = { Text("Scheduled Time (Optional)") },
                    placeholder = { Text("e.g. Mon 09:30 AM") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = favorite,
                        onCheckedChange = { favorite = it }
                    )
                    Text(text = "★ Star as Favorite (Pin to Top)", fontSize = 12.sp)
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Agenda (Optional)") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = {
                        if (name.isBlank()) {
                            errorMessage = "Button name cannot be empty."
                            return@Button
                        }
                        val res = UrlValidator.validate(url)
                        if (!res.isValid) {
                            errorMessage = res.message
                            return@Button
                        }
                        onSave(name, res.normalizedUrl, category, description, notes, scheduledTime, favorite)
                    }) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
