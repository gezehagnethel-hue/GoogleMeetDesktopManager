package com.example.meetmanager.model

import java.io.Serializable

data class DefaultMeetingConfig(
    val title: String = "Primary Google Meet",
    val url: String = "",
    val lastJoinedAt: Long = 0L,
    val joinCount: Int = 0
) : Serializable {
    fun isConfigured(): Boolean = url.isNotBlank()

    fun getFormattedCode(): String {
        if (url.isBlank()) return ""
        return try {
            val clean = url.trim().removePrefix("https://").removePrefix("http://")
            val path = clean.substringAfter("meet.google.com/").substringBefore("?").removePrefix("/")
            if (path.isNotEmpty() && path != clean) path else url
        } catch (_: Exception) {
            url
        }
    }
}
