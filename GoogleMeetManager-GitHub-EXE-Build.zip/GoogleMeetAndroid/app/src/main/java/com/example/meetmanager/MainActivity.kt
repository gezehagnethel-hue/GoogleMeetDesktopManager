package com.example.meetmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.meetmanager.ui.screens.MainScreen
import com.example.meetmanager.ui.theme.GoogleMeetManagerTheme
import com.example.meetmanager.ui.viewmodel.MeetingViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MeetingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GoogleMeetManagerTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}
