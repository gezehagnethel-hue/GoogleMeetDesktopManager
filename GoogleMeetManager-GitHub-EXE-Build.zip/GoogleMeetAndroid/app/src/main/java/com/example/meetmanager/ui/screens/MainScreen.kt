package com.example.meetmanager.ui.screens

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.meetmanager.model.Meeting
import com.example.meetmanager.ui.components.AddEditMeetingDialog
import com.example.meetmanager.ui.components.BatchAddDialog
import com.example.meetmanager.ui.components.DefaultMeetingSettingsDialog
import com.example.meetmanager.ui.components.MeetingButtonTile
import com.example.meetmanager.ui.components.RecordingBottomSheet
import com.example.meetmanager.ui.theme.BrightBlue
import com.example.meetmanager.ui.theme.Navy800
import com.example.meetmanager.ui.theme.Navy900
import com.example.meetmanager.ui.viewmodel.MeetingViewModel
import com.example.meetmanager.ui.viewmodel.ViewMode
import com.example.meetmanager.util.UrlValidator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MeetingViewModel) {
    val context = LocalContext.current
    val meetings by viewModel.filteredMeetings.collectAsState()
    val defaultMeeting by viewModel.defaultMeeting.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val favoritesOnly by viewModel.favoritesOnly.collectAsState()
    val allCategories by viewModel.allCategories.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showBatchDialog by remember { mutableStateOf(false) }
    var showDefaultSettingsDialog by remember { mutableStateOf(false) }
    var showRecordingSheet by remember { mutableStateOf(false) }
    var editingMeeting by remember { mutableStateOf<Meeting?>(null) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf<Meeting?>(null) }

    // SAF Launchers for cross-platform backup & restore
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.exportBackup(uri) { success, msg ->
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importBackup(uri, replaceMode = false) { success, msg ->
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "My Meeting Center",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${meetings.size} buttons • Offline Ready",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavoritesFilter() }) {
                        Icon(
                            imageVector = if (favoritesOnly) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = "Filter Favorites",
                            tint = if (favoritesOnly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { showDefaultSettingsDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = "Meeting Settings",
                            tint = if (defaultMeeting.isConfigured()) BrightBlue else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { showBatchDialog = true }) {
                        Icon(imageVector = Icons.Filled.PlaylistAdd, contentDescription = "Batch Add Buttons")
                    }
                    IconButton(onClick = {
                        val nextMode = if (viewMode == ViewMode.MULTI_BUTTON_PAD) ViewMode.CARDS_VIEW else ViewMode.MULTI_BUTTON_PAD
                        viewModel.setViewMode(nextMode)
                    }) {
                        Icon(
                            imageVector = if (viewMode == ViewMode.MULTI_BUTTON_PAD) Icons.Filled.ViewAgenda else Icons.Filled.GridView,
                            contentDescription = "Switch View Mode"
                        )
                    }
                    IconButton(onClick = { showRecordingSheet = true }) {
                        Icon(
                            imageVector = Icons.Filled.Mic,
                            contentDescription = "Audio Recording Console",
                            tint = Color(0xFFEF4444)
                        )
                    }
                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(imageVector = Icons.Filled.Settings, contentDescription = "Settings & Backup")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingMeeting = null
                    showAddDialog = true
                },
                containerColor = BrightBlue,
                contentColor = Color.White
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Meeting Button")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // ==========================================
            // PROMINENT HERO "JOIN MEETING NOW" SECTION
            // ==========================================
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (defaultMeeting.isConfigured()) Navy900 else MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (defaultMeeting.isConfigured()) BrightBlue.copy(alpha = 0.5f) else Color(0xFFD97706)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Header Row: Status badge & Meeting Settings action
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (defaultMeeting.isConfigured()) Color(0xFF0F3E22) else Color(0xFF451A03)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (defaultMeeting.isConfigured()) Color(0xFF4ADE80) else Color(0xFFF59E0B))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (defaultMeeting.isConfigured()) "READY • 1-CLICK JOIN" else "LINK NOT CONFIGURED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (defaultMeeting.isConfigured()) Color(0xFF4ADE80) else Color(0xFFFBBF24)
                                )
                            }
                        }

                        // Smaller Meeting Settings Button
                        FilledTonalButton(
                            onClick = { showDefaultSettingsDialog = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "Meeting Settings",
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Meeting Settings", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Title & URL or Warning Prompt
                    if (defaultMeeting.isConfigured()) {
                        Text(
                            text = defaultMeeting.title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = defaultMeeting.url,
                            fontSize = 12.sp,
                            color = Color(0xFF93C5FD),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (defaultMeeting.joinCount > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Launched ${defaultMeeting.joinCount} times",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.WarningAmber,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Please configure your Google Meet link first.",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (defaultMeeting.isConfigured()) Color.White else Color(0xFFB45309)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Save your permanent HTTPS Google Meet link to launch it anytime with one tap.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // MOST PROMINENT HOME BUTTON: "JOIN MEETING NOW"
                    Button(
                        onClick = {
                            if (!defaultMeeting.isConfigured()) {
                                Toast.makeText(context, "Please configure your Google Meet link first.", Toast.LENGTH_LONG).show()
                                showDefaultSettingsDialog = true
                            } else {
                                launchMeetUrlSafely(context, defaultMeeting.url) { err ->
                                    Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                }
                                viewModel.recordDefaultMeetingJoined()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (defaultMeeting.isConfigured()) BrightBlue else Color(0xFF2563EB)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Videocam,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "JOIN MEETING NOW",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search buttons by name, URL, code...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            )

            // Meeting Content View (Multi-Button Pad or Cards View)
            if (meetings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.Videocam,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = BrightBlue
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Meeting Buttons Found",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Add your permanent Google Meet links to keep all your team, client, and standup rooms organized offline.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else if (viewMode == ViewMode.MULTI_BUTTON_PAD) {
                // Multi-Button Pad Grid
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 160.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(meetings, key = { _, m -> m.id }) { index, meeting ->
                        MeetingButtonTile(
                            meeting = meeting,
                            slotNumber = index + 1,
                            onJoin = {
                                launchMeetUrlSafely(context, meeting.url) { err ->
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                                viewModel.recordMeetingJoined(meeting)
                            },
                            onCopy = {
                                copyToClipboard(context, meeting.url)
                                Toast.makeText(context, "URL copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            onDuplicate = { viewModel.duplicateMeeting(meeting) },
                            onToggleFavorite = { viewModel.toggleFavorite(meeting) },
                            onEdit = {
                                editingMeeting = meeting
                                showAddDialog = true
                            },
                            onDelete = { showDeleteConfirm = meeting }
                        )
                    }
                }
            } else {
                // Cards View
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(meetings, key = { it.id }) { meeting ->
                        MeetingButtonTile(
                            meeting = meeting,
                            slotNumber = meetings.indexOf(meeting) + 1,
                            onJoin = {
                                launchMeetUrlSafely(context, meeting.url) { err ->
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                                viewModel.recordMeetingJoined(meeting)
                            },
                            onCopy = {
                                copyToClipboard(context, meeting.url)
                                Toast.makeText(context, "URL copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            onDuplicate = { viewModel.duplicateMeeting(meeting) },
                            onToggleFavorite = { viewModel.toggleFavorite(meeting) },
                            onEdit = {
                                editingMeeting = meeting
                                showAddDialog = true
                            },
                            onDelete = { showDeleteConfirm = meeting }
                        )
                    }
                }
            }
        }
    }

    // Default Meeting Settings Dialog
    if (showDefaultSettingsDialog) {
        DefaultMeetingSettingsDialog(
            currentConfig = defaultMeeting,
            existingMeetings = meetings,
            onDismiss = { showDefaultSettingsDialog = false },
            onSave = { title, url ->
                viewModel.saveDefaultMeeting(title, url) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Add / Edit Dialog
    if (showAddDialog) {
        AddEditMeetingDialog(
            existingMeeting = editingMeeting,
            onDismiss = { showAddDialog = false },
            onSave = { name, url, category, desc, notes, schedule, fav ->
                if (editingMeeting == null) {
                    viewModel.addMeeting(name, url, category, desc, notes, schedule, fav)
                } else {
                    viewModel.updateMeeting(
                        editingMeeting!!.copy(
                            name = name,
                            url = url,
                            category = category,
                            description = desc,
                            notes = notes,
                            scheduledTime = schedule,
                            favorite = fav
                        )
                    )
                }
                showAddDialog = false
            }
        )
    }

    // Batch Add Dialog
    if (showBatchDialog) {
        BatchAddDialog(
            onDismiss = { showBatchDialog = false },
            onBatchAdd = { text ->
                val count = viewModel.batchAdd(text)
                Toast.makeText(context, "Created $count meeting buttons", Toast.LENGTH_SHORT).show()
                showBatchDialog = false
            }
        )
    }

    // Delete Confirmation
    if (showDeleteConfirm != null) {
        val m = showDeleteConfirm!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = null },
            title = { Text("Delete Meeting Button?") },
            text = {
                Text("Are you sure you want to delete \"${m.name}\"? This removes the button from your local launcher. It does NOT delete any Google Meet room on Google's servers.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMeeting(m)
                        showDeleteConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Settings & Backup BottomSheet
    if (showSettingsSheet) {
        ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Local Storage & Cross-Platform Backup",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Room SQLite Database • Shared Schema v2 JSON",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
                )

                Button(
                    onClick = {
                        showSettingsSheet = false
                        showDefaultSettingsDialog = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Tune, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Configure Default \"JOIN MEETING NOW\" Link")
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        showSettingsSheet = false
                        exportLauncher.launch("google-meet-backup.json")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export Shared Backup (JSON)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        showSettingsSheet = false
                        importLauncher.launch(arrayOf("application/json"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restore Backup (JSON)...")
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Notice: All links and settings are kept securely on your device. Joining a Google Meet call opens your browser or the Google Meet app.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Audio Recording Console BottomSheet
    if (showRecordingSheet) {
        RecordingBottomSheet(
            viewModel = viewModel,
            onDismiss = { showRecordingSheet = false }
        )
    }
}

/**
 * Safely launches the Google Meet URL using ACTION_VIEW intent.
 * Allows Android to open the Google Meet app if installed; otherwise launches default browser.
 * Handles missing apps and ActivityNotFoundException safely.
 */
private fun launchMeetUrlSafely(context: Context, url: String, onError: (String) -> Unit) {
    if (url.isBlank()) {
        onError("Please configure your Google Meet link first.")
        return
    }
    val valResult = UrlValidator.validate(url)
    if (!valResult.isValid) {
        onError("Invalid Google Meet URL: ${valResult.message}")
        return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(valResult.normalizedUrl)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        onError("No web browser or Google Meet app installed to handle this link.")
    } catch (e: Exception) {
        onError("Could not open Google Meet: ${e.message}")
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Google Meet URL", text)
    clipboard.setPrimaryClip(clip)
}
