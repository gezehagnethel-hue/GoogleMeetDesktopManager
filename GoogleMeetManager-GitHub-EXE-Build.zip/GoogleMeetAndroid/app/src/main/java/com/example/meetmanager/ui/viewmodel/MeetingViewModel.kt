package com.example.meetmanager.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.meetmanager.data.backup.BackupManager
import com.example.meetmanager.data.local.MeetingDatabase
import com.example.meetmanager.data.repository.MeetingRepository
import com.example.meetmanager.model.Meeting
import com.example.meetmanager.util.UrlValidator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ViewMode {
    MULTI_BUTTON_PAD,
    CARDS_VIEW
}

class MeetingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MeetingRepository
    private val backupManager: BackupManager

    private val _defaultMeeting = MutableStateFlow(com.example.meetmanager.model.DefaultMeetingConfig())
    val defaultMeeting: StateFlow<com.example.meetmanager.model.DefaultMeetingConfig> = _defaultMeeting.asStateFlow()

    init {
        val db = MeetingDatabase.getDatabase(application)
        repository = MeetingRepository(db.meetingDao())
        backupManager = BackupManager(application)
        viewModelScope.launch {
            _defaultMeeting.value = repository.getDefaultMeeting()
        }
    }

    private val _viewMode = MutableStateFlow(ViewMode.MULTI_BUTTON_PAD)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _favoritesOnly = MutableStateFlow(false)
    val favoritesOnly: StateFlow<Boolean> = _favoritesOnly.asStateFlow()

    private val _statusMessage = MutableStateFlow("Ready. Offline local storage active.")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    val allCategories: StateFlow<List<String>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredMeetings: StateFlow<List<Meeting>> = combine(
        repository.allMeetings,
        _searchQuery,
        _selectedCategory,
        _favoritesOnly
    ) { meetings, query, category, favsOnly ->
        meetings.filter { m ->
            val matchesCategory = category == "All" || m.category.equals(category, ignoreCase = true)
            val matchesFav = !favsOnly || m.favorite
            val q = query.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                    m.name.lowercase().contains(q) ||
                    m.url.lowercase().contains(q) ||
                    m.category.lowercase().contains(q) ||
                    m.description.lowercase().contains(q) ||
                    m.scheduledTime.lowercase().contains(q) ||
                    m.notes.lowercase().contains(q)

            matchesCategory && matchesFav && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(cat: String) {
        _selectedCategory.value = cat
    }

    fun toggleFavoritesFilter() {
        _favoritesOnly.value = !_favoritesOnly.value
    }

    fun addMeeting(
        name: String,
        rawUrl: String,
        category: String,
        description: String = "",
        notes: String = "",
        scheduledTime: String = "",
        favorite: Boolean = false,
        color: String = "Google Blue"
    ): Boolean {
        val valResult = UrlValidator.validate(rawUrl)
        if (!valResult.isValid || name.isBlank()) {
            _statusMessage.value = valResult.message
            return false
        }

        viewModelScope.launch {
            val meeting = Meeting(
                name = name.trim(),
                url = valResult.normalizedUrl,
                category = if (category.isNotBlank()) category.trim() else "General",
                description = description.trim(),
                notes = notes.trim(),
                scheduledTime = scheduledTime.trim(),
                favorite = favorite,
                color = color
            )
            repository.insertMeeting(meeting)
            _statusMessage.value = "Created button: \"${meeting.name}\""
        }
        return true
    }

    fun updateMeeting(meeting: Meeting) {
        viewModelScope.launch {
            repository.updateMeeting(meeting.copy(updatedAt = System.currentTimeMillis()))
            _statusMessage.value = "Updated button: \"${meeting.name}\""
        }
    }

    fun duplicateMeeting(meeting: Meeting) {
        viewModelScope.launch {
            val copy = repository.duplicateMeeting(meeting)
            _statusMessage.value = "Duplicated button: \"${copy.name}\""
        }
    }

    fun toggleFavorite(meeting: Meeting) {
        viewModelScope.launch {
            repository.toggleFavorite(meeting)
            _statusMessage.value = if (!meeting.favorite) "Starred: ${meeting.name}" else "Unstarred: ${meeting.name}"
        }
    }

    fun deleteMeeting(meeting: Meeting) {
        viewModelScope.launch {
            repository.deleteMeeting(meeting)
            _statusMessage.value = "Deleted button: \"${meeting.name}\""
        }
    }

    fun recordMeetingJoined(meeting: Meeting) {
        viewModelScope.launch {
            repository.recordJoined(meeting)
            _statusMessage.value = "Launched: ${meeting.name}"
        }
    }

    fun saveDefaultMeeting(
        title: String,
        rawUrl: String,
        onResult: ((Boolean, String) -> Unit)? = null
    ): Boolean {
        val valResult = UrlValidator.validate(rawUrl)
        if (!valResult.isValid) {
            _statusMessage.value = valResult.message
            onResult?.invoke(false, valResult.message)
            return false
        }
        val cleanTitle = if (title.isNotBlank()) title.trim() else "Primary Google Meet"
        viewModelScope.launch {
            repository.saveDefaultMeeting(cleanTitle, valResult.normalizedUrl)
            val updated = repository.getDefaultMeeting()
            _defaultMeeting.value = updated
            _statusMessage.value = "Saved default meeting: $cleanTitle"
            onResult?.invoke(true, "Default meeting saved.")
        }
        return true
    }

    fun recordDefaultMeetingJoined() {
        viewModelScope.launch {
            val updated = repository.recordDefaultMeetingJoined()
            _defaultMeeting.value = updated
            _statusMessage.value = "Launched: ${updated.title}"
        }
    }

    fun batchAdd(linesText: String): Int {
        var count = 0
        val items = mutableListOf<Meeting>()
        val lines = linesText.lines()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank() || trimmed.startsWith("#")) continue
            val parts = if (trimmed.contains("|")) trimmed.split("|") else trimmed.split(",")
            if (parts.size >= 2) {
                val name = parts[0].trim()
                val url = parts[1].trim()
                val cat = if (parts.size >= 3) parts[2].trim() else "General"
                val res = UrlValidator.validate(url)
                if (res.isValid && name.isNotBlank()) {
                    items.add(
                        Meeting(
                            name = name,
                            url = res.normalizedUrl,
                            category = cat
                        )
                    )
                    count++
                }
            }
        }

        if (items.isNotEmpty()) {
            viewModelScope.launch {
                repository.insertAll(items)
                _statusMessage.value = "Added $count buttons in bulk."
            }
        }
        return count
    }

    fun exportBackup(uri: Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val currentList = filteredMeetings.value
            val res = backupManager.exportToFile(uri, currentList)
            res.onSuccess {
                _statusMessage.value = "Backup exported successfully."
                onResult(true, "Successfully exported ${currentList.size} meeting buttons.")
            }.onFailure { err ->
                _statusMessage.value = "Export failed: ${err.message}"
                onResult(false, err.message ?: "Export error")
            }
        }
    }

    fun importBackup(uri: Uri, replaceMode: Boolean, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = backupManager.importFromFile(uri)
            res.onSuccess { imported ->
                if (replaceMode) {
                    repository.replaceAll(imported)
                    _statusMessage.value = "Restored ${imported.size} buttons (Replaced all)."
                    onResult(true, "Successfully replaced local storage with ${imported.size} records.")
                } else {
                    val currentList = filteredMeetings.value
                    val addedCount = repository.mergeAll(imported, currentList)
                    _statusMessage.value = "Merged $addedCount new buttons from backup."
                    onResult(true, "Successfully merged $addedCount new records ($imported total in backup).")
                }
            }.onFailure { err ->
                _statusMessage.value = "Import failed: ${err.message}"
                onResult(false, err.message ?: "Failed to import backup")
            }
        }
    }

    // Consent-based Audio Recording Integration
    private val recordingManager = com.example.meetmanager.audio.AudioRecordingManager(application)
    val recordingState = recordingManager.recordingState
    val recordingElapsedMs = recordingManager.elapsedTimeMs

    val allRecordings: StateFlow<List<com.example.meetmanager.model.RecordingMetadata>> = repository.allRecordings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startAudioRecording(
        meetingTitle: String,
        consentConfirmed: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        val res = recordingManager.startRecording(meetingTitle, consentConfirmed)
        res.onSuccess {
            _statusMessage.value = "Audio recording started (Microphone Only)"
            onResult(true, "Recording started")
        }.onFailure { err ->
            _statusMessage.value = "Recording failed: ${err.message}"
            onResult(false, err.message ?: "Failed to start recording")
        }
    }

    fun pauseAudioRecording() {
        recordingManager.pauseRecording()
        _statusMessage.value = "Audio recording paused"
    }

    fun resumeAudioRecording() {
        recordingManager.resumeRecording()
        _statusMessage.value = "Audio recording resumed"
    }

    fun stopAudioRecording(onResult: (Boolean, String) -> Unit) {
        val res = recordingManager.stopRecording()
        res.onSuccess { metadata ->
            viewModelScope.launch {
                repository.saveRecording(metadata)
                _statusMessage.value = "Saved audio recording: ${metadata.filename}"
                onResult(true, "Recording saved: ${metadata.filename}")
            }
        }.onFailure { err ->
            _statusMessage.value = "Stop recording error: ${err.message}"
            onResult(false, err.message ?: "Error stopping recording")
        }
    }

    fun deleteAudioRecording(recording: com.example.meetmanager.model.RecordingMetadata) {
        viewModelScope.launch {
            val file = java.io.File(recording.filePath)
            if (file.exists()) {
                file.delete()
            }
            repository.deleteRecording(recording.id)
            _statusMessage.value = "Deleted recording: ${recording.filename}"
        }
    }
}
