package com.example.meetmanager.util

import java.net.URI

object UrlValidator {
    private const val ALLOWED_HOST = "meet.google.com"
    private val STANDARD_CODE_REGEX = Regex("^[a-zA-Z]{3}-[a-zA-Z]{4}-[a-zA-Z]{3}$")

    data class Result(
        val isValid: Boolean,
        val message: String,
        val normalizedUrl: String = "",
        val code: String = ""
    )

    fun validate(rawInput: String?): Result {
        if (rawInput.isNullOrBlank()) {
            return Result(false, "Meeting URL cannot be empty.")
        }

        var input = rawInput.trim()

        // Convenience support: raw 3-4-3 code like abc-defg-hij
        if (STANDARD_CODE_REGEX.matches(input)) {
            input = "https://$ALLOWED_HOST/${input.lowercase()}"
        }

        if (input.contains(" ") || input.contains("\"") || input.contains("'") ||
            input.contains("<") || input.contains(">") || input.contains("`")
        ) {
            return Result(false, "URL contains invalid or unsafe characters.")
        }

        return try {
            val uri = URI(input)
            val scheme = uri.scheme
            if (!"https".equals(scheme, ignoreCase = true)) {
                if ("http".equals(scheme, ignoreCase = true)) {
                    return Result(false, "Insecure HTTP protocol is not permitted. Only secure HTTPS is accepted.")
                }
                return Result(false, "Invalid protocol '$scheme'. Only https:// is allowed.")
            }

            val host = uri.host
            if (!ALLOWED_HOST.equals(host, ignoreCase = true)) {
                return Result(false, "Unrelated host '$host'. This app only supports Google Meet links (meet.google.com).")
            }

            val path = uri.path?.removePrefix("/") ?: ""
            if (path.isBlank()) {
                return Result(false, "URL is missing a meeting code. Expected: https://meet.google.com/xxx-yyyy-zzz")
            }

            val normalized = "https://$ALLOWED_HOST/$path" + if (uri.query != null) "?${uri.query}" else ""
            Result(true, "Valid Google Meet URL", normalized, path)
        } catch (e: Exception) {
            Result(false, "Malformed URL format: ${e.localizedMessage}")
        }
    }
}
