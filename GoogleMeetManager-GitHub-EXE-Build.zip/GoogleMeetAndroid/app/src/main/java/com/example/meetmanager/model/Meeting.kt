package com.example.meetmanager.model

import java.util.UUID

/**
 * Domain model representing a Google Meet permanent button.
 */
data class Meeting(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val url: String,
    val category: String = "General",
    val description: String = "",
    val notes: String = "",
    val scheduledTime: String = "",
    val favorite: Boolean = false,
    val color: String = "Google Blue",
    val joinCount: Int = 0,
    val lastJoinedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getDisplayCode(): String {
        return try {
            val stripped = url.substringAfter("meet.google.com/").substringBefore("?")
            if (stripped.isNotBlank()) stripped else url
        } catch (e: Exception) {
            url
        }
    }

    fun duplicate(): Meeting {
        return this.copy(
            id = UUID.randomUUID().toString(),
            name = "$name (Copy)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            joinCount = 0,
            lastJoinedAt = null
        )
    }
}
