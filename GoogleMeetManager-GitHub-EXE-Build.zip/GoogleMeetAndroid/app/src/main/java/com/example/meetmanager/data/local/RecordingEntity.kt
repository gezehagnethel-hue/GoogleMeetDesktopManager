package com.example.meetmanager.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.meetmanager.model.RecordingMetadata

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey
    val id: String,
    val meetingTitle: String,
    val filename: String,
    val filePath: String,
    val startTime: Long,
    val durationMs: Long,
    val sizeBytes: Long,
    val isMicOnly: Boolean,
    val consentConfirmed: Boolean
) {
    fun toDomain(): RecordingMetadata = RecordingMetadata(
        id = id,
        meetingTitle = meetingTitle,
        filename = filename,
        filePath = filePath,
        startTime = startTime,
        durationMs = durationMs,
        sizeBytes = sizeBytes,
        isMicOnly = isMicOnly,
        consentConfirmed = consentConfirmed
    )

    companion object {
        fun fromDomain(m: RecordingMetadata): RecordingEntity = RecordingEntity(
            id = m.id,
            meetingTitle = m.meetingTitle,
            filename = m.filename,
            filePath = m.filePath,
            startTime = m.startTime,
            durationMs = m.durationMs,
            sizeBytes = m.sizeBytes,
            isMicOnly = m.isMicOnly,
            consentConfirmed = m.consentConfirmed
        )
    }
}
