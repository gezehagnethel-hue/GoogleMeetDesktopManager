package com.example.meetmanager.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import com.example.meetmanager.model.RecordingMetadata
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class AndroidRecordingState {
    IDLE,
    RECORDING,
    PAUSED,
    FINALIZING,
    STOPPED
}

/**
 * Manages consent-based microphone audio recording on Android.
 * Securely saves authorized local audio notes and provides honest capability reporting
 * regarding Android OS AudioPlaybackCapture restrictions for remote Google Meet audio.
 */
class AudioRecordingManager(private val context: Context) {

    private val _recordingState = MutableStateFlow(AndroidRecordingState.IDLE)
    val recordingState: StateFlow<AndroidRecordingState> = _recordingState.asStateFlow()

    private val _elapsedTimeMs = MutableStateFlow(0L)
    val elapsedTimeMs: StateFlow<Long> = _elapsedTimeMs.asStateFlow()

    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var currentMeetingTitle: String = ""
    private var sessionStartTime: Long = 0L
    private var pauseStartTime: Long = 0L
    private var accumulatedElapsedMs: Long = 0L

    private var timerTimer: Timer? = null

    val recordingsDirectory: File
        get() {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_RECORDINGS)
                ?: File(context.filesDir, "recordings")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    /**
     * Technical limitation explanation regarding Android OS AudioPlaybackCapture policies.
     */
    fun getPlaybackCaptureLimitationMessage(): String {
        return "Under Android 10+ (API 29+), AudioPlaybackCapture is restricted by the OS. " +
                "Google Meet uses USAGE_VOICE_COMMUNICATION, which explicitly sets capture policy " +
                "to ALLOW_CAPTURE_BY_NONE or ALLOW_CAPTURE_BY_SYSTEM to protect participant confidentiality. " +
                "Therefore, third-party mobile apps are restricted to local microphone audio only (1-sided). " +
                "For full 2-sided meetings with all participant voices, use Google Meet's built-in cloud recording."
    }

    @Synchronized
    fun startRecording(meetingTitle: String, isConsentConfirmed: Boolean): Result<File> {
        if (!isConsentConfirmed) {
            return Result.failure(IllegalStateException("Recording requires explicit consent confirmation."))
        }
        if (_recordingState.value == AndroidRecordingState.RECORDING || _recordingState.value == AndroidRecordingState.PAUSED) {
            return Result.failure(IllegalStateException("A recording session is already active."))
        }

        // Check available disk space (require at least 20 MB)
        val freeBytes = recordingsDirectory.freeSpace
        if (freeBytes in 1 until 20 * 1024 * 1024) {
            return Result.failure(IllegalStateException("Insufficient storage space on device."))
        }

        val cleanTitle = sanitizeFilename(meetingTitle)
        val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val filename = "GoogleMeet_${cleanTitle}_$timestamp.m4a"
        val outputFile = File(recordingsDirectory, filename)

        try {
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioSamplingRate(44100)
            recorder.setAudioEncodingBitRate(128000)
            recorder.setOutputFile(outputFile.absolutePath)
            recorder.prepare()
            recorder.start()

            mediaRecorder = recorder
            currentOutputFile = outputFile
            currentMeetingTitle = meetingTitle.ifBlank { "Google Meet Session" }
            sessionStartTime = System.currentTimeMillis()
            accumulatedElapsedMs = 0L
            _elapsedTimeMs.value = 0L
            _recordingState.value = AndroidRecordingState.RECORDING

            startTimer()
            return Result.success(outputFile)
        } catch (e: Exception) {
            mediaRecorder?.release()
            mediaRecorder = null
            _recordingState.value = AndroidRecordingState.IDLE
            return Result.failure(e)
        }
    }

    @Synchronized
    fun pauseRecording() {
        if (_recordingState.value != AndroidRecordingState.RECORDING) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                mediaRecorder?.pause()
                pauseStartTime = System.currentTimeMillis()
                _recordingState.value = AndroidRecordingState.PAUSED
            } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun resumeRecording() {
        if (_recordingState.value != AndroidRecordingState.PAUSED) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                mediaRecorder?.resume()
                if (pauseStartTime > 0) {
                    pauseStartTime = 0L
                }
                _recordingState.value = AndroidRecordingState.RECORDING
            } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun stopRecording(): Result<RecordingMetadata> {
        stopTimer()
        val file = currentOutputFile
        val title = currentMeetingTitle
        val startTime = sessionStartTime
        val duration = _elapsedTimeMs.value

        return try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
            mediaRecorder = null
            _recordingState.value = AndroidRecordingState.STOPPED

            val size = file?.length() ?: 0L
            val metadata = RecordingMetadata(
                id = UUID.randomUUID().toString(),
                meetingTitle = title,
                filename = file?.name ?: "recording.m4a",
                filePath = file?.absolutePath ?: "",
                startTime = startTime,
                durationMs = duration,
                sizeBytes = size,
                isMicOnly = true, // Strictly documented 1-sided recording
                consentConfirmed = true
            )
            _recordingState.value = AndroidRecordingState.IDLE
            Result.success(metadata)
        } catch (e: Exception) {
            mediaRecorder?.release()
            mediaRecorder = null
            _recordingState.value = AndroidRecordingState.IDLE
            Result.failure(e)
        }
    }

    private fun startTimer() {
        timerTimer?.cancel()
        timerTimer = Timer("RecordingTimer", true)
        timerTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                if (_recordingState.value == AndroidRecordingState.RECORDING) {
                    accumulatedElapsedMs += 200L
                    _elapsedTimeMs.value = accumulatedElapsedMs
                }
            }
        }, 200L, 200L)
    }

    private fun stopTimer() {
        timerTimer?.cancel()
        timerTimer = null
    }

    private fun sanitizeFilename(input: String): String {
        return input.replace(Regex("[^a-zA-Z0-9_-]"), "_").replace(Regex("_+"), "_").take(30).ifBlank { "Meeting" }
    }
}
