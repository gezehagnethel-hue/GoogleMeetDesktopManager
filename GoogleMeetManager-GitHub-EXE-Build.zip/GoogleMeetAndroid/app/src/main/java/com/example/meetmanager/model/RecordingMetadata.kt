package com.example.meetmanager.model

import java.io.Serializable

data class RecordingMetadata(
    val id: String,
    val meetingTitle: String,
    val filename: String,
    val filePath: String,
    val startTime: Long,
    val durationMs: Long,
    val sizeBytes: Long,
    val isMicOnly: Boolean = true,
    val consentConfirmed: Boolean = true
) : Serializable {
    fun getFormattedDuration(): String {
        val totalSecs = durationMs / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        val hours = mins / 60
        val remMins = mins % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, remMins, secs)
        } else {
            String.format("%02d:%02d", remMins, secs)
        }
    }

    fun getFormattedSize(): String {
        return when {
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> String.format("%.1f KB", sizeBytes / 1024.0)
            else -> String.format("%.2f MB", sizeBytes / (1024.0 * 1024.0))
        }
    }
}
