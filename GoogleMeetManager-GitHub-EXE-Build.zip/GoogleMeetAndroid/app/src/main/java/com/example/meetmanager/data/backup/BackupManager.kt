package com.example.meetmanager.data.backup

import android.content.Context
import android.net.Uri
import com.example.meetmanager.model.Meeting
import com.example.meetmanager.util.UrlValidator
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

/**
 * Cross-Platform Backup & Restore Manager matching the Shared Schema v2 specification.
 */
class BackupManager(private val context: Context) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    data class BackupEnvelope(
        val schemaVersion: Int = 2,
        val exportTimestamp: Long = System.currentTimeMillis(),
        val appName: String = "Google Meet Desktop & Mobile Manager",
        val records: List<Meeting> = emptyList()
    )

    suspend fun exportToFile(uri: Uri, meetings: List<Meeting>): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val envelope = BackupEnvelope(
                schemaVersion = 2,
                exportTimestamp = System.currentTimeMillis(),
                records = meetings
            )
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    gson.toJson(envelope, writer)
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importFromFile(uri: Uri): Result<List<Meeting>> = withContext(Dispatchers.IO) {
        try {
            val content = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { it.readText() }
            } ?: return@withContext Result.failure(Exception("Could not read backup file."))

            val root: JsonElement = JsonParser.parseString(content)
            val rawMeetings: List<Meeting> = if (root.isJsonObject) {
                val obj = root.asJsonObject
                if (obj.has("records") && obj.get("records").isJsonArray) {
                    val listType = object : TypeToken<List<Meeting>>() {}.type
                    gson.fromJson(obj.get("records"), listType)
                } else {
                    emptyList()
                }
            } else if (root.isJsonArray) {
                val listType = object : TypeToken<List<Meeting>>() {}.type
                gson.fromJson(root, listType)
            } else {
                return@withContext Result.failure(Exception("Unsupported backup JSON format."))
            }

            val validated = rawMeetings.filter { meeting ->
                val res = UrlValidator.validate(meeting.url)
                meeting.name.isNotBlank() && res.isValid
            }.map { meeting ->
                val res = UrlValidator.validate(meeting.url)
                meeting.copy(
                    id = if (meeting.id.isNotBlank()) meeting.id else UUID.randomUUID().toString(),
                    url = res.normalizedUrl
                )
            }

            Result.success(validated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
