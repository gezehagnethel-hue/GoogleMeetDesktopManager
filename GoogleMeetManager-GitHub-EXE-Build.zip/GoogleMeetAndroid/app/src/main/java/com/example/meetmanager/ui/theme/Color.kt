package com.example.meetmanager.ui.theme

import androidx.compose.ui.graphics.Color

val Navy950 = Color(0xFF0A0F1D)
val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Navy700 = Color(0xFF334155)

val BrightBlue = Color(0xFF1A73E8)
val BrightBlueHover = Color(0xFF1558D6)
val BrightBlueLight = Color(0xFFE8F0FE)

val EmeraldGreen = Color(0xFF0F9D58)
val AmberStar = Color(0xFFF59E0B)
val RoseRed = Color(0xFFD93025)
val PurpleAccent = Color(0xFF8E24AA)
val TealAccent = Color(0xFF0097A7)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF1E293B)
val TextSecondaryLight = Color(0xFF64748B)
