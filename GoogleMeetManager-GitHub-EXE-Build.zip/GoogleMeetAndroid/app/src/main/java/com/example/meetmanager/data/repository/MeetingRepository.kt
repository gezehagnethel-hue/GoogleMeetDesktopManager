package com.example.meetmanager.data.repository

import com.example.meetmanager.data.local.MeetingDao
import com.example.meetmanager.data.local.MeetingEntity
import com.example.meetmanager.model.Meeting
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MeetingRepository(private val meetingDao: MeetingDao) {

    val allMeetings: Flow<List<Meeting>> = meetingDao.getAllMeetings().map { entities ->
        entities.map { it.toDomain() }
    }

    val allCategories: Flow<List<String>> = meetingDao.getAllCategories()

    suspend fun getMeetingById(id: String): Meeting? {
        return meetingDao.getMeetingById(id)?.toDomain()
    }

    suspend fun findByUrl(url: String): Meeting? {
        return meetingDao.findByUrl(url)?.toDomain()
    }

    suspend fun insertMeeting(meeting: Meeting) {
        meetingDao.insertMeeting(MeetingEntity.fromDomain(meeting))
    }

    suspend fun insertAll(meetings: List<Meeting>) {
        meetingDao.insertAll(meetings.map { MeetingEntity.fromDomain(it) })
    }

    suspend fun updateMeeting(meeting: Meeting) {
        meetingDao.updateMeeting(MeetingEntity.fromDomain(meeting))
    }

    suspend fun deleteMeeting(meeting: Meeting) {
        meetingDao.deleteMeeting(MeetingEntity.fromDomain(meeting))
    }

    suspend fun deleteById(id: String) {
        meetingDao.deleteById(id)
    }

    suspend fun toggleFavorite(meeting: Meeting) {
        val updated = meeting.copy(
            favorite = !meeting.favorite,
            updatedAt = System.currentTimeMillis()
        )
        meetingDao.updateMeeting(MeetingEntity.fromDomain(updated))
    }

    suspend fun recordJoined(meeting: Meeting) {
        val updated = meeting.copy(
            joinCount = meeting.joinCount + 1,
            lastJoinedAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        meetingDao.updateMeeting(MeetingEntity.fromDomain(updated))
    }

    suspend fun duplicateMeeting(meeting: Meeting): Meeting {
        val copy = meeting.duplicate()
        meetingDao.insertMeeting(MeetingEntity.fromDomain(copy))
        return copy
    }

    suspend fun replaceAll(meetings: List<Meeting>) {
        meetingDao.deleteAll()
        meetingDao.insertAll(meetings.map { MeetingEntity.fromDomain(it) })
    }

    suspend fun mergeAll(imported: List<Meeting>, existing: List<Meeting>): Int {
        val existingUrls = existing.map { it.url.lowercase() }.toSet()
        val existingIds = existing.map { it.id }.toSet()

        val newMeetings = imported.filter {
            !existingUrls.contains(it.url.lowercase()) && !existingIds.contains(it.id)
        }

        if (newMeetings.isNotEmpty()) {
            meetingDao.insertAll(newMeetings.map { MeetingEntity.fromDomain(it) })
        }
        return newMeetings.size
    }

    suspend fun getDefaultMeeting(): com.example.meetmanager.model.DefaultMeetingConfig {
        val title = meetingDao.getSetting(KEY_DEFAULT_MEETING_TITLE) ?: "Primary Google Meet"
        val url = meetingDao.getSetting(KEY_DEFAULT_MEETING_URL) ?: ""
        val lastJoined = meetingDao.getSetting(KEY_DEFAULT_MEETING_LAST_JOINED)?.toLongOrNull() ?: 0L
        val joinCount = meetingDao.getSetting(KEY_DEFAULT_MEETING_JOIN_COUNT)?.toIntOrNull() ?: 0
        return com.example.meetmanager.model.DefaultMeetingConfig(title, url, lastJoined, joinCount)
    }

    suspend fun saveDefaultMeeting(title: String, url: String) {
        val cleanTitle = if (title.isNotBlank()) title.trim() else "Primary Google Meet"
        meetingDao.setSetting(com.example.meetmanager.data.local.SettingEntity(KEY_DEFAULT_MEETING_TITLE, cleanTitle))
        meetingDao.setSetting(com.example.meetmanager.data.local.SettingEntity(KEY_DEFAULT_MEETING_URL, url.trim()))
    }

    suspend fun recordDefaultMeetingJoined(): com.example.meetmanager.model.DefaultMeetingConfig {
        val current = getDefaultMeeting()
        val updatedCount = current.joinCount + 1
        val now = System.currentTimeMillis()
        meetingDao.setSetting(com.example.meetmanager.data.local.SettingEntity(KEY_DEFAULT_MEETING_JOIN_COUNT, updatedCount.toString()))
        meetingDao.setSetting(com.example.meetmanager.data.local.SettingEntity(KEY_DEFAULT_MEETING_LAST_JOINED, now.toString()))
        return current.copy(joinCount = updatedCount, lastJoinedAt = now)
    }

    // Audio Recordings
    val allRecordings: Flow<List<com.example.meetmanager.model.RecordingMetadata>> =
        meetingDao.getAllRecordings().map { entities -> entities.map { it.toDomain() } }

    suspend fun saveRecording(rec: com.example.meetmanager.model.RecordingMetadata) {
        meetingDao.insertRecording(com.example.meetmanager.data.local.RecordingEntity.fromDomain(rec))
    }

    suspend fun deleteRecording(id: String) {
        meetingDao.deleteRecordingById(id)
    }

    companion object {
        const val KEY_DEFAULT_MEETING_TITLE = "default_meeting_title"
        const val KEY_DEFAULT_MEETING_URL = "default_meeting_url"
        const val KEY_DEFAULT_MEETING_LAST_JOINED = "default_meeting_last_joined"
        const val KEY_DEFAULT_MEETING_JOIN_COUNT = "default_meeting_join_count"
    }
}
