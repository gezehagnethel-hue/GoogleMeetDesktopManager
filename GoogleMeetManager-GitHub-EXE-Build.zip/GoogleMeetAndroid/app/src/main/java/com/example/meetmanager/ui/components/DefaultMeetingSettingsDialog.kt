package com.example.meetmanager.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.meetmanager.model.DefaultMeetingConfig
import com.example.meetmanager.model.Meeting
import com.example.meetmanager.ui.theme.BrightBlue
import com.example.meetmanager.ui.theme.DarkNavy
import com.example.meetmanager.util.UrlValidator

@Composable
fun DefaultMeetingSettingsDialog(
    currentConfig: DefaultMeetingConfig,
    existingMeetings: List<Meeting>,
    onDismiss: () -> Unit,
    onSave: (title: String, url: String) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(currentConfig.title) }
    var url by remember { mutableStateOf(currentConfig.url) }

    val valResult = remember(url) {
        if (url.isBlank()) {
            UrlValidator.ValidationResult(false, "", "Enter a valid Google Meet link (e.g. https://meet.google.com/abc-defg-hij)")
        } else {
            UrlValidator.validate(url)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = null,
                    tint = BrightBlue,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Meeting Settings",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Configure 1-Click \"JOIN MEETING NOW\" Link",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "When you tap JOIN MEETING NOW on the home screen, the app will instantly launch this permanent Google Meet room without asking for a link every time.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Meeting Title / Room Label") },
                    placeholder = { Text("e.g. Daily Standup Room") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Google Meet HTTPS URL *") },
                    placeholder = { Text("https://meet.google.com/abc-defg-hij") },
                    singleLine = true,
                    isError = url.isNotBlank() && !valResult.isValid,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        if (url.isNotBlank()) {
                            IconButton(onClick = { url = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear")
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Validation Status Banner
                if (url.isNotBlank()) {
                    Surface(
                        color = if (valResult.isValid) Color(0xFF0F3E22) else Color(0xFF4A1515),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (valResult.isValid) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = if (valResult.isValid) Color(0xFF4ADE80) else Color(0xFFF87171),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (valResult.isValid) "Valid Google Meet URL (${valResult.normalizedUrl})" else valResult.message,
                                fontSize = 11.sp,
                                color = if (valResult.isValid) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                            )
                        }
                    }
                }

                // Quick Select from existing buttons
                if (existingMeetings.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Or quick-select from your saved buttons:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(existingMeetings) { m ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        title = m.name
                                        url = m.url
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Link,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = BrightBlue
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = m.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // Test button
                if (valResult.isValid) {
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(valResult.normalizedUrl)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    addCategory(Intent.CATEGORY_BROWSABLE)
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Cannot open: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Link in Browser / Meet App")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (valResult.isValid) {
                        onSave(title.ifBlank { "Primary Google Meet" }, valResult.normalizedUrl)
                        onDismiss()
                    } else {
                        Toast.makeText(context, "Please enter a valid Google Meet link first.", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = valResult.isValid,
                colors = ButtonDefaults.buttonColors(containerColor = BrightBlue)
            ) {
                Text("Save Default Meeting")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
