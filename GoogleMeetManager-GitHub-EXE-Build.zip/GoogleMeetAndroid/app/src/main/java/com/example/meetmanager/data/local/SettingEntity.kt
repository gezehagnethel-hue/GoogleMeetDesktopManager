package com.example.meetmanager.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Key-value persistent app settings storage for offline preferences,
 * such as the default 1-click Google Meet URL and room title.
 */
@Entity(tableName = "app_settings")
data class SettingEntity(
    @PrimaryKey
    val key: String,
    val value: String
)
