package com.example.meetmanager.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.meetmanager.audio.AndroidRecordingState
import com.example.meetmanager.model.RecordingMetadata
import com.example.meetmanager.ui.theme.BrightBlue
import com.example.meetmanager.ui.theme.Navy900
import com.example.meetmanager.ui.viewmodel.MeetingViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingBottomSheet(
    viewModel: MeetingViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val recordingState by viewModel.recordingState.collectAsState()
    val elapsedMs by viewModel.recordingElapsedMs.collectAsState()
    val recordings by viewModel.allRecordings.collectAsState()

    var showConsentDialog by remember { mutableStateOf(false) }

    // Format timer
    val totalSecs = elapsedMs / 1000
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    val hours = mins / 60
    val remMins = mins % 60
    val timerText = if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, remMins, secs)
    } else {
        String.format("%02d:%02d", remMins, secs)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Mic,
                        contentDescription = null,
                        tint = if (recordingState == AndroidRecordingState.RECORDING) Color(0xFFEF4444) else BrightBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Meeting Audio Recording",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Status Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (recordingState) {
                        AndroidRecordingState.RECORDING -> Color(0xFF450A0A)
                        AndroidRecordingState.PAUSED -> Color(0xFF451A03)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = when (recordingState) {
                            AndroidRecordingState.RECORDING -> "● RECORDING"
                            AndroidRecordingState.PAUSED -> "❚❚ PAUSED"
                            else -> "● IDLE"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (recordingState) {
                            AndroidRecordingState.RECORDING -> Color(0xFFF87171)
                            AndroidRecordingState.PAUSED -> Color(0xFFFBBF24)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Timer & Controls Box
            Surface(
                color = Navy900,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = timerText,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (recordingState == AndroidRecordingState.IDLE || recordingState == AndroidRecordingState.STOPPED) {
                            Button(
                                onClick = { showConsentDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)) // Red
                            ) {
                                Icon(Icons.Filled.RadioButtonChecked, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Start Recording")
                            }
                        } else {
                            if (recordingState == AndroidRecordingState.RECORDING) {
                                Button(
                                    onClick = { viewModel.pauseAudioRecording() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)) // Amber
                                ) {
                                    Icon(Icons.Filled.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pause")
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.resumeAudioRecording() },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrightBlue)
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Resume")
                                }
                            }

                            Button(
                                onClick = {
                                    viewModel.stopAudioRecording { success, msg ->
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569)) // Slate
                            ) {
                                Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop & Save")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Honest Technical Limitations Notice
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Android Limitation: Microphone Only (1-Sided)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD97706)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Android OS prohibits 3rd-party apps from intercepting VoIP playback audio (AudioPlaybackCapture policy). Only your local voice is recorded. For full 2-sided meetings, use Google Meet's in-meeting recording.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Saved Recordings List
            Text(
                text = "Saved Audio Files (${recordings.size})",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (recordings.isEmpty()) {
                Text(
                    text = "No saved audio recordings on this device.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(recordings, key = { it.id }) { rec ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = rec.filename,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${rec.getFormattedDuration()} • ${rec.getFormattedSize()} • Mic Only",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            playRecording(context, rec.filePath)
                                        }
                                    ) {
                                        Icon(Icons.Filled.PlayCircle, contentDescription = "Play", tint = BrightBlue)
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteAudioRecording(rec)
                                            Toast.makeText(context, "Deleted recording", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showConsentDialog) {
        RecordingConsentDialog(
            meetingTitle = "Google Meet Session",
            onDismiss = { showConsentDialog = false },
            onConfirmConsent = {
                showConsentDialog = false
                viewModel.startAudioRecording("Meeting", true) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

private fun playRecording(context: Context, filePath: String) {
    try {
        val file = File(filePath)
        if (!file.exists()) {
            Toast.makeText(context, "Recording file not found on disk", Toast.LENGTH_SHORT).show()
            return
        }
        val uri: Uri = try {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open audio player: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
