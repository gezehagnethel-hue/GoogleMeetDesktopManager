package com.example.meetmanager.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.meetmanager.model.Meeting

@Entity(tableName = "meetings")
data class MeetingEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val url: String,
    val category: String,
    val description: String,
    val notes: String,
    val scheduledTime: String,
    val favorite: Boolean,
    val color: String,
    val joinCount: Int,
    val lastJoinedAt: Long?,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain(): Meeting = Meeting(
        id = id,
        name = name,
        url = url,
        category = category,
        description = description,
        notes = notes,
        scheduledTime = scheduledTime,
        favorite = favorite,
        color = color,
        joinCount = joinCount,
        lastJoinedAt = lastJoinedAt,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomain(m: Meeting): MeetingEntity = MeetingEntity(
            id = m.id,
            name = m.name,
            url = m.url,
            category = m.category,
            description = m.description,
            notes = m.notes,
            scheduledTime = m.scheduledTime,
            favorite = m.favorite,
            color = m.color,
            joinCount = m.joinCount,
            lastJoinedAt = m.lastJoinedAt,
            createdAt = m.createdAt,
            updatedAt = m.updatedAt
        )
    }
}
