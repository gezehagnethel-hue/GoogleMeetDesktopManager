# Google Meet Manager - Native Android Application

> **Framework:** Kotlin 1.9, Jetpack Compose, Material 3, AndroidX Room SQLite, Coroutines & Flow  
> **Target SDK:** 34 (Android 14) | **Min SDK:** 26 (Android 8.0 Oreo)  
> **Architecture:** MVVM (Model-View-ViewModel) + Repository Pattern + Offline-First Local Storage

---

## 1. Overview

**Google Meet Manager for Android** is the native mobile companion to the Windows Desktop Manager. It brings the **1-Interface Multi-Button Pad** and **Cards View** to Android phones and tablets, allowing users to bookmark and launch their permanent Google Meet conference links with a single tap.

### Key Mobile Capabilities:
- **Offline-First Room Database**: All meeting buttons, titles, notes, and schedules are stored locally on-device in a high-performance SQLite database via Room.
- **1-Tap Direct Launch**: Tapping any button launches `https://meet.google.com/xxx-yyyy-zzz` directly in the user's default browser or Google Meet app.
- **Cross-Platform Shared Schema v2**: Transfer backups between Windows and Android using standard `.json` files via Android's Storage Access Framework (file picker).
- **Favorites & Scheduling**: Star/pin buttons to the top and record meeting times.
- **Multi-Button Pad View**: Adaptive grid tile view (2 columns on mobile, 3-4 columns on tablets).

---

## 2. Prerequisites & Building

### Prerequisites:
1. **Android Studio Iguana | Hedgehog (2023.2+)** or **Android Studio Koala/Ladybug**
2. **JDK 17 LTS**
3. **Android SDK Platform 34** and build-tools installed via SDK Manager.

### Building with Android Studio:
1. Open Android Studio.
2. Select **File > Open** and select the `GoogleMeetAndroid` directory.
3. Allow Gradle to sync dependencies.
4. Select a connected physical device or Android Virtual Device (AVD) running Android 8.0+.
5. Click **Run > Run 'app'** (`Shift + F10`).

### Building via Command Line (Terminal / PowerShell):

```bash
cd GoogleMeetAndroid

# Linux / macOS
./gradlew assembleDebug

# Windows Command Prompt / PowerShell
.\gradlew.bat assembleDebug
```

The compiled APK will be created at:
`GoogleMeetAndroid/app/build/outputs/apk/debug/app-debug.apk`

To install directly to a USB-connected device:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 3. Running Automated Tests

Run the local JVM unit tests:
```bash
./gradlew testDebugUnitTest
```

---

## 4. Cross-Platform Backup & Restore with Windows

1. In the Android app, tap **Settings (gear icon)** at the top right.
2. Tap **Export Shared Backup (JSON)**.
3. Choose a folder (e.g. `Downloads` or Google Drive) using the system file picker.
4. Transfer this `.json` file to Windows (or vice versa).
5. On Windows, click **File > Settings & Storage > Restore from Backup**.
6. The app supports both **Merge** and **Replace** modes, checking for duplicates.
